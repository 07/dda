// 生成多答扩展图标 - 纯 Node.js 实现，无需外部依赖
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const outputDir = 'G:\\Practice\\VSCodeProjects\\duodaai\\shared\\res\\icons';
const sizes = [16, 32, 48, 128];

// CRC32 表
const crcTable = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[n] = c;
  }
  return table;
})();

function crc32(buf) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xFF] ^ (crc >>> 8);
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function createPNG(width, height, pixels) {
  // PNG signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 6;  // color type: RGBA
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const ihdrChunk = createChunk('IHDR', ihdr);

  // IDAT chunk - image data with filter bytes
  const rawData = Buffer.alloc(height * (1 + width * 4));
  for (let y = 0; y < height; y++) {
    rawData[y * (1 + width * 4)] = 0; // filter: None
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const rawIdx = y * (1 + width * 4) + 1 + x * 4;
      rawData[rawIdx] = pixels[idx];     // R
      rawData[rawIdx + 1] = pixels[idx + 1]; // G
      rawData[rawIdx + 2] = pixels[idx + 2]; // B
      rawData[rawIdx + 3] = pixels[idx + 3]; // A
    }
  }

  const compressed = zlib.deflateSync(rawData);
  const idatChunk = createChunk('IDAT', compressed);

  // IEND chunk
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const typeBuffer = Buffer.from(type, 'ascii');
  const crcData = Buffer.concat([typeBuffer, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(crcData), 0);
  return Buffer.concat([length, typeBuffer, data, crc]);
}

function lerp(a, b, t) {
  return Math.round(a + (b - a) * t);
}

function generateIcon(size) {
  const pixels = Buffer.alloc(size * size * 4);

  // 渐变色: #667eea -> #764ba2
  const c1 = { r: 102, g: 126, b: 234 };
  const c2 = { r: 118, g: 75, b: 162 };

  // 圆角半径
  const radius = Math.round(size * 0.22);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;

      // 圆角判断
      let inCorner = false;
      if (x < radius && y < radius) {
        const dx = radius - x;
        const dy = radius - y;
        if (dx * dx + dy * dy > radius * radius) inCorner = true;
      } else if (x >= size - radius && y < radius) {
        const dx = x - (size - radius - 1);
        const dy = radius - y;
        if (dx * dx + dy * dy > radius * radius) inCorner = true;
      } else if (x < radius && y >= size - radius) {
        const dx = radius - x;
        const dy = y - (size - radius - 1);
        if (dx * dx + dy * dy > radius * radius) inCorner = true;
      } else if (x >= size - radius && y >= size - radius) {
        const dx = x - (size - radius - 1);
        const dy = y - (size - radius - 1);
        if (dx * dx + dy * dy > radius * radius) inCorner = true;
      }

      if (inCorner) {
        pixels[idx] = 0;
        pixels[idx + 1] = 0;
        pixels[idx + 2] = 0;
        pixels[idx + 3] = 0;
      } else {
        // 对角线渐变
        const t = (x + y) / (2 * (size - 1));
        pixels[idx] = lerp(c1.r, c2.r, t);
        pixels[idx + 1] = lerp(c1.g, c2.g, t);
        pixels[idx + 2] = lerp(c1.b, c2.b, t);
        pixels[idx + 3] = 255;

        // 中心画一个白色圆形（模拟"群"的简化）
        const cx = size / 2;
        const cy = size / 2;
        const dist = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy));
        const circleRadius = size * 0.28;
        if (dist < circleRadius) {
          // 白色圆形内再画一个渐变圆
          const innerDist = dist / circleRadius;
          if (innerDist > 0.55) {
            // 圆环
            pixels[idx] = 255;
            pixels[idx + 1] = 255;
            pixels[idx + 2] = 255;
            pixels[idx + 3] = 255;
          }
        }
      }
    }
  }

  return createPNG(size, size, pixels);
}

// 生成所有尺寸
sizes.forEach(size => {
  const png = generateIcon(size);
  const filePath = path.join(outputDir, `icon${size}.png`);
  fs.writeFileSync(filePath, png);
  console.log(`Generated: icon${size}.png (${png.length} bytes)`);
});

console.log('All icons generated!');

# 多答AI Duoda v1.0.0

多 AI 平台聚合 Chrome 扩展 —— 一次提问，多平台同时回答。

## 核心功能

- **多平台并排聚合**：侧边栏内同时嵌入多个 AI 平台 iframe
- **一键多投**：输入一次，自动注入到所有平台并发送
- **智能注入引擎**：支持 insertText / paste / slate / draft 多种注入方式
- **手动添加平台**：设置面板中可自定义添加任意 AI 平台
- **快捷键**：
  - `Alt+Q`：打开/关闭侧边栏
  - `Alt+V`：将页面选中文本发送到多答AI
- **右键菜单**：选中文本后右键"添加到多答AI对话"
- **平台切换**：全部 / 单平台视图切换
- **深色模式**：支持侧边栏深色主题

## 内置平台（共19个）

**国内（11个）**：DeepSeek、豆包、Kimi、通义千问、文心一言、智谱清言、腾讯元宝、讯飞星火、百川智能、天工AI、商量

**国际（8个）**：ChatGPT、Claude、Gemini、Copilot、Perplexity、Grok、Mistral、Meta AI

> 默认启用前5个（DeepSeek、豆包、Kimi、通义千问、文心一言），可在设置中自由开关。国际平台需确保网络可访问。

## 手动添加平台

1. 打开侧边栏，点击右上角设置按钮
2. 在「平台管理」中点击「+ 添加平台」
3. 填写：
   - **平台名称**：如 Kimi
   - **平台网址**：如 https://www.kimi.com/
   - **输入框选择器**：CSS 选择器，如 `textarea, div[contenteditable='true']`
   - **文本注入方式**：insertText（推荐）/ paste / slate / draft
   - **发送方式**：enter（回车）/ click（点击按钮）
   - **发送按钮选择器**：发送方式为 click 时填写
4. 点击保存，新平台会自动出现在侧边栏中

自定义平台支持编辑和删除，配置保存在浏览器本地存储中。

## 安装方法

1. 打开 Chrome，地址栏输入 `chrome://extensions/`
2. 右上角开启「开发者模式」
3. 点击「加载已解压的扩展程序」
4. 选择本项目根目录 `duodaai`
5. 扩展加载成功后，点击工具栏图标或按 `Alt+Q` 打开侧边栏

## 使用方法

1. 侧边栏打开后，各 AI 平台 iframe 自动加载
2. 首次使用需要在各自 iframe 内登录账号
3. 在底部输入框输入问题，按 `Enter` 发送（`Shift+Enter` 换行）
4. 问题会自动注入到每个平台的输入框并发送
5. 各平台独立生成回答，在 iframe 内并排展示

## 项目结构

```
duodaai/
├── manifest.json              # 扩展配置清单 (Manifest V3)
├── chrome/                    # Chrome 平台专属代码
│   ├── res/
│   │   └── rules.json         # DNR 网络请求修改规则
│   └── src/
│       ├── html/
│       │   └── sidepanel.html # 侧边栏页面
│       └── js/
│           ├── background.js  # Service Worker
│           ├── content.js     # 内容脚本（运行在 AI 平台页面）
│           └── sidepanel.js   # 侧边栏主逻辑
├── shared/                    # 跨平台共享代码
│   ├── res/
│   │   ├── domestic.json      # 国内平台配置
│   │   ├── global.json        # 国际平台配置
│   │   ├── default.json       # 默认设置
│   │   └── icons/             # 扩展图标
│   └── src/
│       ├── css/
│       │   └── index.css      # 主样式
│       ├── html/
│       │   └── index.html     # 独立聚合页面
│       └── js/
│           ├── util/
│           │   ├── utils.js          # 通用工具函数
│           │   └── configs-loader.js # 配置加载器（支持自定义平台）
│           └── inject/
│               └── injector.js       # 核心注入引擎
└── _locales/                  # 国际化（8种语言）
    ├── zh_CN/
    ├── en/
    └── ...
```

## 技术架构

### 通信机制
- **sidepanel ↔ iframe (content.js)**：`window.postMessage` 跨域通信
- **background ↔ content/sidepanel**：`chrome.runtime.sendMessage`
- **状态持久化**：`chrome.storage.local`（设置、自定义平台）

### 注入引擎
配置驱动，每个平台声明：
- `findInput`：输入框定位选择器
- `addText`：文本注入方式（insertText/paste/slate/draft）
- `addFile`：文件上传方式（fileInput/paste/drop）
- `send`：发送触发方式（enter/click）

注入引擎具备多层 fallback：
- 配置选择器失败 → 通用选择器探测
- 注入方式失败 → 自动尝试其他方式
- 注入后验证 → 确认文本真的被设置
- 发送方式失败 → 自动尝试其他方式 + 通用按钮查找

### DNR 规则
移除 iframe 嵌入限制：
- X-Frame-Options
- Content-Security-Policy
- Cross-Origin-Opener-Policy
- Cross-Origin-Embedder-Policy

## 注意事项

- 扩展会修改被嵌入 AI 平台页面的部分安全响应头（X-Frame-Options/CSP），这是 iframe 嵌入的必要手段
- 所有登录态保存在浏览器原生 Cookie 中，扩展不收集或上传任何用户数据
- 平台页面改版可能导致注入选择器失效，可通过编辑平台配置更新选择器
- 自定义平台的配置保存在浏览器本地，清除扩展数据会丢失

# 生成多答扩展图标
Add-Type -AssemblyName System.Drawing

$outputDir = "G:\Practice\VSCodeProjects\duodaai\shared\res\icons"
$sizes = @(16, 32, 48, 128)

foreach ($size in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias

    # 渐变背景
    $rect = New-Object System.Drawing.Rectangle(0, 0, $size, $size)
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        $rect,
        [System.Drawing.Color]::FromArgb(102, 126, 234),
        [System.Drawing.Color]::FromArgb(118, 75, 162),
        [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
    )
    $g.FillRectangle($brush, $rect)

    # 圆角裁剪（模拟圆角）
    $radius = [int]($size * 0.2)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc(0, 0, $radius, $radius, 180, 90)
    $path.AddArc($size - $radius, 0, $radius, $radius, 270, 90)
    $path.AddArc($size - $radius, $size - $radius, $radius, $radius, 0, 90)
    $path.AddArc(0, $size - $radius, $radius, $radius, 90, 90)
    $path.CloseFigure()

    # 用白色背景先填充，然后用圆角路径裁剪
    $finalBmp = New-Object System.Drawing.Bitmap($size, $size)
    $fg = [System.Drawing.Graphics]::FromImage($finalBmp)
    $fg.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $fg.Clear([System.Drawing.Color]::Transparent)
    $fg.SetClip($path)
    $fg.DrawImage($bmp, 0, 0)

    # 画"群"字
    $fontSize = [int]($size * 0.55)
    $font = New-Object System.Drawing.Font("Microsoft YaHei", $fontSize, [System.Drawing.FontStyle]::Bold)
    $textBrush = [System.Drawing.Brushes]::White
    $stringFormat = New-Object System.Drawing.StringFormat
    $stringFormat.Alignment = [System.Drawing.StringAlignment]::Center
    $stringFormat.LineAlignment = [System.Drawing.StringAlignment]::Center
    $textRect = New-Object System.Drawing.RectangleF(0, 0, $size, $size)
    $fg.DrawString("群", $font, $textBrush, $textRect, $stringFormat)

    # 保存
    $fileName = "icon" + $size + ".png"
    $outputPath = Join-Path $outputDir $fileName
    $finalBmp.Save($outputPath, [System.Drawing.Imaging.ImageFormat]::Png)

    $g.Dispose()
    $fg.Dispose()
    $bmp.Dispose()
    $finalBmp.Dispose()
    $brush.Dispose()
    $font.Dispose()

    Write-Output ("Generated: icon" + $size + ".png")
}

Write-Output "All icons generated!"

// 全局重命名脚本：DuoDa -> duoda
const fs = require('fs');
const path = require('path');

const base = 'G:\\Practice\\VSCodeProjects\\duodaai';

const files = [
  'chrome\\src\\js\\background.js',
  'chrome\\src\\js\\content.js',
  'chrome\\src\\js\\sidepanel.js',
  'shared\\src\\js\\util\\utils.js',
  'shared\\src\\js\\util\\configs-loader.js',
  'shared\\src\\js\\inject\\injector.js',
  'shared\\src\\css\\index.css',
  'chrome\\src\\html\\sidepanel.html',
  'shared\\src\\html\\index.html'
];

const replacements = [
  // 标识符
  ['DuoDaUtils', 'DuodaUtils'],
  ['DuoDaConfigs', 'DuodaConfigs'],
  ['DuoDaInjector', 'DuodaInjector'],
  // 消息 source
  ['DuoDa-extension', 'duoda-extension'],
  ['DuoDa-content', 'duoda-content'],
  // CSS 类名
  ['DuoDa-dark', 'duoda-dark'],
  ['DuoDa-sidepanel', 'duoda-sidepanel'],
  ['DuoDa-index-page', 'duoda-index-page'],
  ['DuoDa-theme-filter', 'duoda-theme-filter'],
  // 右键菜单 ID
  ['DuoDa-add-to-chat', 'duoda-add-to-chat'],
  // 日志前缀
  ['[DuoDa Sidepanel]', '[Duoda Sidepanel]'],
  ['[DuoDa Content]', '[Duoda Content]'],
  ['[DuoDa Background]', '[Duoda Background]'],
  ['[DuoDa]', '[Duoda]'],
  // 显示文字
  ['多答 DuoDa', '多答AI'],
  ['多答', '多答AI'],
  ['DuoDa', 'Duoda']
];

let totalChanges = 0;

files.forEach(relativePath => {
  const filePath = path.join(base, relativePath);
  if (!fs.existsSync(filePath)) {
    console.log('SKIP (not found):', relativePath);
    return;
  }

  let content = fs.readFileSync(filePath, 'utf8');
  let changed = false;

  replacements.forEach(([from, to]) => {
    if (content.includes(from)) {
      const count = (content.match(new RegExp(from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
      content = content.split(from).join(to);
      console.log(`  ${relativePath}: ${from} -> ${to} (${count}x)`);
      changed = true;
      totalChanges += count;
    }
  });

  if (changed) {
    fs.writeFileSync(filePath, content, 'utf8');
    console.log('UPDATED:', relativePath);
  } else {
    console.log('OK:', relativePath);
  }
});

console.log(`\nTotal replacements: ${totalChanges}`);

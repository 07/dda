/**
 * 多答AI - Background Service Worker
 * 职责: 右键菜单、快捷键、消息中转、侧边栏管理
 */

'use strict';

// ========== 常量 ==========
const CONTEXT_MENU_ID = 'duoda-add-to-chat';
const SEND_SELECTION_CMD = 'send-selection';
const OPEN_DUODA_CMD = 'open-duoda';

/**
 * 打开多答AI独立页面
 */
function openDuodaPage() {
  const url = chrome.runtime.getURL('shared/src/html/index.html');
  chrome.tabs.create({ url }, (tab) => {
    console.log('[Duoda] Opened in tab:', tab.id);
  });
}

// ========== 平台配置（从 JSON 加载） ==========
let loadedPlatforms = [];
let platformsLoaded = false;

async function loadPlatformConfigs() {
  if (platformsLoaded) return loadedPlatforms;
  try {
    const [domesticRes, globalRes] = await Promise.all([
      fetch(chrome.runtime.getURL('shared/res/domestic.json')),
      fetch(chrome.runtime.getURL('shared/res/global.json'))
    ]);
    const domesticData = await domesticRes.json();
    const globalData = await globalRes.json();
    loadedPlatforms = [...(domesticData.platforms || []), ...(globalData.platforms || [])];
    platformsLoaded = true;
    console.log('[Duoda] Platform configs loaded:', loadedPlatforms.length);
  } catch (e) {
    console.error('[Duoda] Failed to load platform configs:', e);
    loadedPlatforms = [];
  }
  return loadedPlatforms;
}

function getPlatformConfigByDomain(domain) {
  return loadedPlatforms.find(p => p.domain === domain) || null;
}

// 深度合并：对象递归合并，数组/基本类型以覆盖值为准；返回新对象，不污染内置缓存
function deepMergePlatform(base, over) {
  const isPlain = v => v && typeof v === 'object' && !Array.isArray(v);
  if (!isPlain(over)) return over;
  const out = isPlain(base) ? JSON.parse(JSON.stringify(base)) : {};
  Object.keys(over).forEach(k => {
    const bv = out[k], ov = over[k];
    if (isPlain(ov) && isPlain(bv)) out[k] = deepMergePlatform(bv, ov);
    else out[k] = ov;
  });
  return out;
}

// ========== 安装初始化 ==========
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[Duoda] Extension installed:', details.reason);

  // 加载平台配置
  loadPlatformConfigs();

  // 创建右键菜单
  try {
    chrome.contextMenus.create({
      id: CONTEXT_MENU_ID,
      title: '添加到多答AI对话',
      contexts: ['selection']
    });
    console.log('[Duoda] Context menu created');
  } catch (e) {
    console.warn('[Duoda] Context menu create error:', e);
  }

  // 初始化默认设置
  const defaults = {
    userSettings: {
      theme: 'light',
      autoSend: true,
      sendDelay: 500,
      enabledPlatforms: ['deepseek', 'doubao'],
      layout: 'grid',
      columns: 2
    },
    pendingMessage: null,
    sessions: {}
  };

  chrome.storage.local.get(null, (result) => {
    const toSet = {};
    for (const key in defaults) {
      if (result[key] === undefined) {
        toSet[key] = defaults[key];
      }
    }
    if (Object.keys(toSet).length > 0) {
      chrome.storage.local.set(toSet);
    }
  });
});

// ========== 点击扩展图标打开独立页面 ==========
chrome.action.onClicked.addListener(() => {
  openDuodaPage();
});

// ========== 快捷键命令 ==========
chrome.commands.onCommand.addListener(async (command) => {
  console.log('[Duoda] Command received:', command);

  if (command === OPEN_DUODA_CMD) {
    openDuodaPage();
  }

  if (command === SEND_SELECTION_CMD) {
    // 获取当前页面选中文本并发送
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) return;

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => window.getSelection().toString()
      });

      const selectedText = results && results[0] && results[0].result;
      if (selectedText && selectedText.trim()) {
        // 保存待发送消息
        await chrome.storage.local.set({
          pendingMessage: {
            text: selectedText.trim(),
            timestamp: Date.now(),
            source: 'selection'
          }
        });

        // 打开独立页面
        openDuodaPage();
      }
    } catch (e) {
      console.error('[Duoda] Send selection error:', e);
    }
  }
});

// ========== 右键菜单 ==========
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== CONTEXT_MENU_ID) return;

  const selectedText = info.selectionText;
  if (!selectedText || !selectedText.trim()) return;

  console.log('[Duoda] Context menu triggered, text length:', selectedText.length);

  try {
    // 保存待发送消息
    await chrome.storage.local.set({
      pendingMessage: {
        text: selectedText.trim(),
        timestamp: Date.now(),
        source: 'contextmenu'
      }
    });

    // 打开独立页面
    openDuodaPage();

    // 通知页面有新消息
    chrome.runtime.sendMessage({
      type: 'PENDING_MESSAGE',
      text: selectedText.trim()
    }).catch(() => {});
  } catch (e) {
    console.error('[Duoda] Context menu handler error:', e);
  }
});

// ========== 消息中转 ==========
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Duoda] BG message:', message.type, 'from:', sender.frameId === 0 ? 'top' : 'frame');

  switch (message.type) {
    // 来自侧边栏: 广播注入指令到所有匹配的 content script
    case 'BROADCAST_INJECT': {
      const { text, sendId, platformId } = message;
      // 向所有标签页的 content script 发送
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, {
            type: 'INJECT_AND_SEND',
            text,
            sendId,
            platformId
          }).catch(() => {
            // 标签页可能没有 content script，忽略
          });
        });
      });
      sendResponse({ success: true });
      return true; // 异步
    }

    // 来自 content script: 注入结果回传
    case 'INJECT_RESULT': {
      // 转发给侧边栏
      chrome.runtime.sendMessage({
        type: 'INJECT_RESULT',
        result: message.result
      }).catch(() => {});
      sendResponse({ success: true });
      return true;
    }

    // 来自 content script: 请求平台配置
    case 'GET_PLATFORM_CONFIG': {
      const { domain } = message;
      // 先确保平台配置已加载
      loadPlatformConfigs().then(() => {
        // 从 storage 读取自定义平台 + 选择器覆盖层，逐层合并
        chrome.storage.local.get(['customPlatforms', 'duodaSelectorOverrides'], (result) => {
          const customPlatforms = result.customPlatforms || [];
          const selectorOverrides = result.duodaSelectorOverrides || {};
          const builtin = getPlatformConfigByDomain(domain);
          const custom = customPlatforms.find(p => p.domain === domain);
          let config = custom ? JSON.parse(JSON.stringify(custom)) : (builtin ? JSON.parse(JSON.stringify(builtin)) : null);
          // 选择器覆盖层优先级最高，深度合并
          if (config && selectorOverrides[config.id]) {
            config = deepMergePlatform(config, selectorOverrides[config.id]);
          }
          sendResponse({ success: true, config });
        });
      });
      return true; // 异步
    }

    // 来自侧边栏: 获取当前状态
    case 'GET_STATUS': {
      chrome.storage.local.get(['pendingMessage', 'userSettings'], (result) => {
        sendResponse({
          success: true,
          pendingMessage: result.pendingMessage,
          userSettings: result.userSettings
        });
      });
      return true; // 异步
    }

    // 来自侧边栏: 清除待发送消息
    case 'CLEAR_PENDING': {
      chrome.storage.local.set({ pendingMessage: null });
      sendResponse({ success: true });
      return true;
    }

    // 来自 content script: 登录状态变化
    case 'LOGIN_STATUS': {
      chrome.runtime.sendMessage({
        type: 'LOGIN_STATUS',
        platformId: message.platformId,
        loggedIn: message.loggedIn
      }).catch(() => {});
      sendResponse({ success: true });
      return true;
    }

    default:
      sendResponse({ success: false, error: 'Unknown message type' });
      return true;
  }
});

// ========== 标签页更新监听（用于 URL 变化通知） ==========
chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId !== 0) return; // 只处理主框架
  console.log('[Duoda] Navigation completed:', details.url);
});

console.log('[Duoda] Background service worker initialized');

/**
 * DuodaMembership —— 多答AI 会员授权（本地激活码 + Ed25519 验签，零后端）
 *
 * 激活码格式（JWT-like）：headerB64.payloadB64.signatureB64
 *   header  = {"alg":"EdDSA","typ":"duoda-license"}
 *   payload = {"v":1,"lic":"uuid","name":"用户名","level":"pro","exp":到期ms(0=永久),"iat":签发ms,"dev"?:"设备指纹"}
 *   signature = Ed25519.sign(headerB64 + "." + payloadB64, 作者私钥)
 *
 * 公钥硬编码于此；私钥仅作者持有（keys/ed25519-private.key，不入扩展）。
 * 会员状态存 chrome.storage.local: duodaMembership = {raw, payload, activatedAt, deviceId}
 * 每日提问配额存 duodaUsage = {date:"YYYY-MM-DD", askCount:number}
 */
(function (global) {
  // ===== 公钥（spki base64，由 scripts/gen-keys.js 生成）=====
  const PUBLIC_KEY = 'MCowBQYDK2VwAyEAG7tQwENLLnZdzrt7/W9IAC7b7oPwOkHNzM/5eW3po28=';
  // qa const PUBLIC_KEY = 'MCowBQYDK2VwAyEAmLV70iKsHt2xuPygUs5CRfSrO0+h9DbpXsHZD972ZRM=';


  const META_KEY = 'duodaMembership';
  const USAGE_KEY = 'duodaUsage';
  const DEVICE_KEY = 'duodaDeviceId';

  // ===== 激活服务器地址（开发者配置，部署后修改此处即可）=====
  // 配置后激活时走后端一码一设备校验；留空字符串 '' 则纯本地验签
  //const LICENSE_SERVER_URL = 'http://localhost:8080/api/activation/activate';
  const LICENSE_SERVER_URL = 'https://duoda.itjun.com/api/activation/activate';

  // 免费版限制
  const FREE_LIMITS = {
    dailyQuestions: 30, // 每天最多发送多少个问题（一次发送算1次，不管选了几个AI）
    dailySummary: 5,    // 每天最多使用一键总结的次数
    maxConcurrent: 3,   // 一次最多同时向多少个 AI 提问
    groups: 2,          // 最多保存分组数
    customPlatforms: 2, // 最多自定义平台数
    customPrompts: 3,   // 最多自定义提示词数
    history: 10         // 历史对话保留条数
  };
  const PRO_LIMITS = {
    customPrompts: 200  // 会员最多自定义提示词数
  };

  let _cachedKey = null;
  let _usePureJS = false;       // Web Crypto 不支持 Ed25519 时启用纯 JS 验签
  let _purePublicKey = null;    // 纯 JS 模式下的 raw 公钥（32字节）
  let _status = { active: false, level: 'free', name: '', exp: 0, lic: '', raw: '' };

  // 从 SPKI DER 中提取 Ed25519 raw 公钥（最后32字节）
  function spkiToRaw(spkiBuf) {
    const u8 = new Uint8Array(spkiBuf);
    return u8.slice(u8.length - 32);
  }

  // ---------- 工具 ----------
  function b64urlToBuf(s) {
    s = s.replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    const bin = atob(s);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return buf.buffer;
  }
  function b64ToBuf(s) {
    const bin = atob(s);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return buf.buffer;
  }
  function storageGet(keys) {
    return new Promise((resolve) => {
      try { chrome.storage.local.get(keys, resolve); } catch (e) { resolve({}); }
    });
  }
  function storageSet(obj) {
    return new Promise((resolve) => {
      try { chrome.storage.local.set(obj, resolve); } catch (e) { resolve(); }
    });
  }

  // ---------- 公钥导入（缓存，自动降级纯 JS）----------
  async function getPublicKey() {
    if (_cachedKey) return _cachedKey;
    try {
      _cachedKey = await crypto.subtle.importKey(
        'spki', b64ToBuf(PUBLIC_KEY), { name: 'Ed25519' }, false, ['verify']
      );
      _usePureJS = false;
    } catch (e) {
      // 浏览器不支持 Ed25519（如旧版 Edge），降级为纯 JS 验签
      _usePureJS = true;
      _purePublicKey = spkiToRaw(b64ToBuf(PUBLIC_KEY));
      _cachedKey = { pure: true };
    }
    return _cachedKey;
  }

  // ---------- 验签 ----------
  async function verifyLicense(raw) {
    if (!raw || typeof raw !== 'string') return { ok: false, error: '激活码为空' };
    const parts = raw.trim().split('.');
    if (parts.length !== 3) return { ok: false, error: '激活码格式不正确' };
    const [hB64, pB64, sB64] = parts;
    let header, payload;
    try {
      header = JSON.parse(new TextDecoder().decode(b64urlToBuf(hB64)));
      payload = JSON.parse(new TextDecoder().decode(b64urlToBuf(pB64)));
    } catch (e) {
      return { ok: false, error: '激活码无法解析' };
    }
    if (header.typ !== 'duoda-license' || header.alg !== 'EdDSA') {
      return { ok: false, error: '不是有效的多答AI激活码' };
    }
    try {
      await getPublicKey();
      const data = new TextEncoder().encode(hB64 + '.' + pB64);
      const sig = new Uint8Array(b64urlToBuf(sB64));
      let valid;
      if (_usePureJS) {
        if (typeof NobleEd25519 === 'undefined' || !NobleEd25519.verifyAsync) {
          return { ok: false, error: '验签组件未加载，请重新加载扩展' };
        }
        valid = await NobleEd25519.verifyAsync(sig, data, _purePublicKey);
      } else {
        valid = await crypto.subtle.verify('Ed25519', _cachedKey, sig, data);
      }
      if (!valid) return { ok: false, error: '激活码签名校验失败' };
    } catch (e) {
      return { ok: false, error: '验签失败：' + (e.message || e) };
    }
    if (payload.exp && payload.exp > 0 && Date.now() > payload.exp) {
      return { ok: false, error: '激活码已过期', expired: true };
    }
    return { ok: true, header, payload };
  }

  // ---------- 设备指纹 ----------
  async function getDeviceId() {
    const r = await storageGet([DEVICE_KEY]);
    if (r[DEVICE_KEY]) return r[DEVICE_KEY];
    const id = 'dev_' + (crypto.randomUUID ? crypto.randomUUID() : (Date.now() + '_' + Math.random().toString(36).slice(2)));
    await storageSet({ [DEVICE_KEY]: id });
    return id;
  }

  function getLicenseServer() { return LICENSE_SERVER_URL; }

  // ---------- 状态 ----------
  async function init() {
    const r = await storageGet([META_KEY]);
    const saved = r[META_KEY];
    if (saved && saved.raw) {
      const v = await verifyLicense(saved.raw);
      if (v.ok) {
        // 优先用存储时累计后的到期时间（saved.payload.exp），
        // 而不是原始激活码的 v.payload.exp，否则多次激活的累计有效期会丢失
        const storedExp = (saved.payload && saved.payload.exp != null) ? saved.payload.exp : (v.payload.exp || 0);
        _status = {
          active: true,
          level: v.payload.level || 'pro',
          name: v.payload.name || '',
          exp: storedExp,
          lic: v.payload.lic || '',
          raw: saved.raw
        };
        return _status;
      }
      // 过期/无效：清除
      await storageSet({ [META_KEY]: null });
    }
    _status = { active: false, level: 'free', name: '', exp: 0, lic: '', raw: '' };
    return _status;
  }

  function getStatus() {
    // 运行时再判一次过期（避免跨天后状态陈旧）
    if (_status.active && _status.exp && _status.exp > 0 && Date.now() > _status.exp) {
      _status.active = false;
      _status.level = 'free';
    }
    return _status;
  }

  function isPro() {
    const s = getStatus();
    // 只要已激活且等级不是免费版，就算会员（兼容 pro/vip/premium 等不同等级命名）
    return s.active && !!s.level && s.level !== 'free';
  }

  function daysLeft() {
    const s = getStatus();
    if (!s.active) return 0;
    if (!s.exp || s.exp === 0) return Infinity;
    return Math.max(0, Math.ceil((s.exp - Date.now()) / 86400000));
  }

  // ---------- 激活 / 取消 ----------
  async function activate(raw) {
    const v = await verifyLicense(raw);
    if (!v.ok) return { success: false, message: v.error };
    const deviceId = await getDeviceId();
    // 若激活码绑定了设备，校验匹配
    if (v.payload.dev && v.payload.dev !== deviceId) {
      return { success: false, message: '该激活码已绑定其他设备' };
    }

    // ===== 后端校验（如果配置了激活服务器地址）=====
    const serverUrl = getLicenseServer();
    if (serverUrl) {
      try {
        const resp = await fetch(serverUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code: raw.trim(), dev: deviceId })
        });
        const data = await resp.json();
        if (!data || data.success === false) {
          return { success: false, message: (data && data.message) || '服务器校验失败' };
        }
        // 后端校验通过，继续本地保存
      } catch (e) {
        return { success: false, message: '无法连接激活服务器：' + (e.message || e) };
      }
    }

    // 同一个激活码重复激活检测
    const trimmed = raw.trim();
    if (_status && _status.active && _status.raw === trimmed) {
      return { success: false, message: '该激活码已使用' };
    }

    const now = Date.now();
    const isPermanent = v.payload.exp === 0;
    const currentlyPermanent = _status && _status.active && _status.exp === 0;

    // 已是永久会员，再激活任何卡都无意义
    if (currentlyPermanent) {
      return { success: false, message: '已是永久会员，无需重复激活' };
    }

    let newExp;
    if (isPermanent) {
      // 永久激活码：直接变永久
      newExp = 0;
    } else {
      // 临时卡：计算时长 = exp - iat，累加到当前到期时间
      const duration = Math.max(0, (v.payload.exp || 0) - (v.payload.iat || 0));
      const currentExp = (_status && _status.active && _status.exp > now) ? _status.exp : now;
      newExp = currentExp + duration;
    }

    // 保存时 payload.exp 更新为累计后的到期时间
    const storedPayload = { ...v.payload, exp: newExp };
    await storageSet({
      [META_KEY]: { raw: trimmed, payload: storedPayload, activatedAt: now, deviceId }
    });
    _status = {
      active: true, level: v.payload.level || 'pro', name: v.payload.name || '',
      exp: newExp, lic: v.payload.lic || '', raw: trimmed
    };
    return { success: true, status: _status };
  }

  async function deactivate() {
    await storageSet({ [META_KEY]: null });
    _status = { active: false, level: 'free', name: '', exp: 0, lic: '', raw: '' };
    return true;
  }

  // ---------- 单次同时回答 AI 数量限制 ----------
  // 免费版一次最多 FREE_LIMITS.maxConcurrent 个 AI 同时回答；会员无限制
  function getMaxConcurrent() {
    return isPro() ? Infinity : FREE_LIMITS.maxConcurrent;
  }

  // 自定义提示词数量上限（免费3，会员200）
  function getMaxCustomPrompts() {
    return isPro() ? PRO_LIMITS.customPrompts : FREE_LIMITS.customPrompts;
  }

  // ---------- 每日提问次数限制 ----------
  // 免费版每天最多 FREE_LIMITS.dailyQuestions 次提问（一次发送算1次，不管选了几个AI）；会员无限制
  function todayStr() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  async function getUsage() {
    const r = await storageGet([USAGE_KEY]);
    let u = r[USAGE_KEY] || {};
    // 跨天重置，且兼容旧数据缺少字段的情况
    if (u.date !== todayStr()) { u = { date: todayStr(), questionCount: 0, summaryCount: 0 }; }
    u.questionCount = u.questionCount || 0;
    u.summaryCount = u.summaryCount || 0;
    return u;
  }
  async function getDailyQuestionsUsed() { return (await getUsage()).questionCount || 0; }
  async function getDailyQuestionsRemaining() {
    if (isPro()) return Infinity;
    const u = await getUsage();
    return Math.max(0, FREE_LIMITS.dailyQuestions - u.questionCount);
  }
  async function recordQuestion() {
    if (isPro()) return;
    const u = await getUsage();
    u.questionCount += 1;
    await storageSet({ [USAGE_KEY]: u });
    return u;
  }

  // ---------- 每日一键总结次数限制 ----------
  // 免费版每天最多 FREE_LIMITS.dailySummary 次；会员无限制
  async function getDailySummaryUsed() { return (await getUsage()).summaryCount || 0; }
  async function getDailySummaryRemaining() {
    if (isPro()) return Infinity;
    const u = await getUsage();
    return Math.max(0, FREE_LIMITS.dailySummary - u.summaryCount);
  }
  async function recordSummary() {
    if (isPro()) return;
    const u = await getUsage();
    u.summaryCount += 1;
    await storageSet({ [USAGE_KEY]: u });
    return u;
  }

  // ---------- 功能权限（集中判断）----------
  // feature: 'unlimitedConcurrent' | 'exportChat' | 'historyUnlimited'
  //          | 'customPlatform' | 'groupsUnlimited' | 'voice' | 'fileUpload' | 'selectorOverride'
  // 注意：summary（一键总结）免费版每天5次，次数限制在调用处用 getDailySummaryRemaining 检查，不在此拦截
  function can(feature) {
    if (isPro()) return true;
    // 免费版：以下功能全部锁定
    const proOnly = ['exportChat', 'historyUnlimited', 'customPlatform',
      'groupsUnlimited', 'voice', 'fileUpload', 'selectorOverride', 'unlimitedConcurrent'];
    return !proOnly.includes(feature);
  }

  function getFreeLimits() { return { ...FREE_LIMITS }; }

  global.DuodaMembership = {
    init, getStatus, isPro, daysLeft,
    activate, deactivate, verifyLicense,
    getDeviceId, getLicenseServer,
    getMaxConcurrent,
    getMaxCustomPrompts,
    getDailyQuestionsUsed, getDailyQuestionsRemaining, recordQuestion,
    getDailySummaryUsed, getDailySummaryRemaining, recordSummary,
    can, getFreeLimits
  };
})(typeof window !== 'undefined' ? window : globalThis);

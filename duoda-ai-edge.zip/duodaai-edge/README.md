# 多答AI Duoda v1.0.0

多 AI 平台聚合浏览器扩展 —— 一次提问，多平台同时回答。

支持 Chrome 和 Edge 浏览器。

## 核心功能

- **多平台并排聚合**：页面内同时嵌入多个 AI 平台 iframe
- **一键多投**：输入一次，自动注入到所有平台并发送
- **智能注入引擎**：支持 insertText / paste / slate / draft 多种注入方式
- **手动添加平台**：设置面板中可自定义添加任意 AI 平台
- **快捷键**：
  - `Alt+Q`：打开多答AI页面
  - `Alt+V`：将页面选中文本发送到多答AI
- **右键菜单**：选中文本后右键"添加到多答AI对话"
- **平台切换**：全部 / 单平台视图切换
- **深色模式**：支持深色主题
- **账号保险库**：AES-GCM 256 加密存储 AI 平台账号密码，支持自动登录
- **一键总结**：汇总多个 AI 的回答（会员功能）
- **对话导出**：导出对话为 Markdown（会员功能）

## 内置平台（共20个）

**国内（12个）**：DeepSeek、豆包、Kimi、通义千问、文心一言、智谱清言、腾讯元宝、讯飞星火、百川智能、天工AI、商量、秘塔AI搜索

**国际（8个）**：ChatGPT、Claude、Gemini、Copilot、Perplexity、Grok、Mistral、Meta AI

> 默认启用 DeepSeek 和豆包 2 个平台，可在设置中自由开关。国际平台需确保网络可访问。

## 免费版与会员版

| 功能 | 免费版 | 会员版 |
|------|--------|--------|
| 每日提问次数 | 30 次 | 无限制 |
| 同时回答 AI 数量 | 最多 3 个 | 无限制 |
| 一键总结 | 每天 5 次 | 无限制 |
| 对话导出 Markdown | - | ✓ |
| 自定义平台数量 | 2 个 | 无限制 |
| 自定义提示词 | 3 个 | 200 个 |
| 语音输入 / 文件上传 | - | ✓ |
| 分组数量 | 2 个 | 无限制 |
| 历史记录 | 10 条 | 无限制 |
| 高级选择器热修 | - | ✓ |

会员通过激活码授权，Ed25519 数字签名验签，支持本地离线验签。

## 手动添加平台

1. 打开多答AI页面，点击右上角设置按钮
2. 在「平台管理」中点击「+ 添加平台」
3. 填写：
   - **平台名称**：如 Kimi
   - **平台网址**：如 https://www.kimi.com/
   - **输入框选择器**：CSS 选择器，如 `textarea, div[contenteditable='true']`
   - **文本注入方式**：insertText（推荐）/ paste / slate / draft
   - **发送方式**：enter（回车）/ click（点击按钮）
   - **发送按钮选择器**：发送方式为 click 时填写
4. 点击保存，新平台会自动出现在页面中

自定义平台支持编辑和删除，配置保存在浏览器本地存储中。

## 安装方法

### 开发者模式加载

1. 打开浏览器扩展管理页面（Chrome: `chrome://extensions/`，Edge: `edge://extensions/`）
2. 开启「开发者模式」
3. 点击「加载已解压的扩展程序」
4. 选择本项目根目录（`duodaai-chrome` 或 `duodaai-edge`）
5. 扩展加载成功后，点击工具栏图标或按 `Alt+Q` 打开

### 商店安装

待上架 Chrome Web Store / Microsoft Edge Add-ons 后，可直接从商店安装。

## 使用方法

1. 打开多答AI页面后，各 AI 平台 iframe 自动加载
2. 首次使用需要在各自 iframe 内登录账号
3. 在底部输入框输入问题，按 `Enter` 发送（`Shift+Enter` 换行）
4. 问题会自动注入到每个平台的输入框并发送
5. 各平台独立生成回答，在 iframe 内并排展示

## 项目结构

```
duodaai-chrome/  (或 duodaai-edge/)
├── manifest.json              # 扩展配置清单 (Manifest V3)
├── privacy.html               # 隐私政策页面
├── CHANGELOG.md               # 版本更新日志
├── chrome/                    # 浏览器平台专属代码
│   ├── res/
│   │   └── rules.json         # DNR 网络请求修改规则
│   └── src/
│       └── js/
│           ├── background.js  # Service Worker
│           ├── content.js     # 内容脚本（运行在 AI 平台页面）
│           ├── sidepanel.js   # 主页面逻辑
│           └── sw-killer.js   # iframe 内 Service Worker 禁用
├── shared/                    # 跨平台共享代码
│   ├── res/
│   │   ├── domestic.json      # 国内平台配置
│   │   ├── global.json        # 国际平台配置
│   │   ├── default.json       # 默认设置
│   │   ├── icons/             # 扩展图标
│   │   └── images/            # 图片资源
│   └── src/
│       ├── css/
│       │   └── index.css      # 主样式
│       ├── html/
│       │   └── index.html     # 主页面
│       └── js/
│           ├── util/
│           │   ├── utils.js          # 通用工具函数
│           │   ├── configs-loader.js # 配置加载器（支持自定义平台）
│           │   ├── membership.js     # 会员授权系统
│           │   ├── crypto-vault.js   # 账号密码加密保险库
│           │   └── ed25519-pure.js   # Ed25519 纯 JS 验签
│           └── inject/
│               └── injector.js       # 核心注入引擎
├── scripts/                   # 开发工具脚本
│   ├── gen-keys.js            # 生成 Ed25519 密钥对
│   └── gen-license.js         # 生成激活码
└── _locales/                  # 国际化（8种语言）
    ├── zh_CN/
    ├── en/
    └── ...
```

## 技术架构

### 通信机制
- **主页面 ↔ iframe (content.js)**：`window.postMessage` 跨域通信，双向来源校验
- **background ↔ content/主页面**：`chrome.runtime.sendMessage`
- **状态持久化**：`chrome.storage.local`（设置、自定义平台、使用统计）

### 注入引擎
配置驱动，每个平台声明：
- `findInput`：输入框定位选择器
- `addText`：文本注入方式（insertText/paste/slate/draft）
- `addFile`：文件上传方式（fileInput/paste/drop）
- `send`：发送触发方式（enter/click）

注入引擎具备多层 fallback：
- 配置选择器失败 → 通用选择器探测
- 注入方式失败 → 自动尝试其他方式
- 注入后验证 → 确认文本真的被设置
- 发送方式失败 → 自动尝试其他方式 + 通用按钮查找

### DNR 规则
移除 iframe 嵌入限制：
- X-Frame-Options
- Content-Security-Policy
- Cross-Origin-Opener-Policy
- Cross-Origin-Embedder-Policy

### 会员授权系统
- 激活码格式：JWT-like（header.payload.signature）
- 签名算法：Ed25519
- 公钥硬编码在扩展中，私钥仅开发者持有
- 支持本地离线验签，可选后端一码一设备校验
- 设备指纹：随机 UUID，本地存储

### 账号保险库
- 主密码经 PBKDF2（SHA-256，15万次迭代）派生 AES-GCM 256 密钥
- 密钥仅存在于内存，锁定/关闭页面后清空
- 加密后的账号密码存储在 `chrome.storage.local`

## 隐私政策

本扩展重视用户隐私，核心原则是：数据尽量本地存储，最小化上传，绝不出售。

详细隐私政策请参见 [privacy.html](./privacy.html)。

简要说明：
- 所有设置、配置、使用统计均存储在本地
- 账号密码使用 AES-GCM 256 加密存储
- 不收集浏览历史、不收集 Cookie、不进行行为追踪
- 仅在会员激活时将激活码和设备标识发送至激活服务器

## 注意事项

- 扩展会修改被嵌入 AI 平台页面的部分安全响应头（X-Frame-Options/CSP），这是 iframe 嵌入的必要手段
- 所有登录态保存在浏览器原生 Cookie 中，扩展不收集或上传任何用户数据
- 平台页面改版可能导致注入选择器失效，可通过编辑平台配置更新选择器
- 自定义平台的配置保存在浏览器本地，清除扩展数据会丢失
- 国际 AI 平台需确保网络可访问

## 许可证

详见 [LICENSE](./LICENSE) 文件。

## 更新日志

详见 [CHANGELOG.md](./CHANGELOG.md)。

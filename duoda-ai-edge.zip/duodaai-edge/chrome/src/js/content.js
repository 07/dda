/**
 * 多答AI Duoda - Content Script
 * 运行在 AI 平台页面内（iframe 中）
 * 职责: 接收注入指令、调用注入引擎、回传结果、登录状态检测
 *
 * 依赖: DuodaUtils, DuodaInjector (通过 content_scripts 加载)
 */

'use strict';

(function () {
  const Utils = window.DuodaUtils;
  const Injector = window.DuodaInjector;

  if (!Utils || !Injector) {
    console.error('[Duoda Content] Dependencies not loaded');
    return;
  }

  // ========== 当前平台识别 ==========
  const currentDomain = window.location.hostname;
  let currentPlatform = null;
  let isInIframe = window.self !== window.top;
  let isReady = false;
  const messageQueue = [];
  const processedSendIds = new Set(); // 防重复：已处理的 sendId
  const recentSents = []; // 双保险：最近发送的文本指纹（文本+时间戳），拦截任何重复路径

  console.log('[Duoda Content] Loaded on:', currentDomain, 'inIframe:', isInIframe);

  // 通用配置模板
  function makePlatformConfig(id, name, url, domain, overrides) {
    return Object.assign({
      id, name, url, domain,
      findInput: {
        selector: "textarea, div[contenteditable='true'], div[contenteditable=''], [role='textbox'], input[type='text'], .ProseMirror, [data-testid*='input' i]",
        waitTimeout: 5000,
        pollInterval: 150
      },
      addText: { method: 'insertText', focusFirst: true, clearBefore: true },
      addFile: { method: 'fileInput', fileInputSelector: "input[type='file']" },
      send: {
        method: 'enter',
        buttonSelector: "button[aria-label='发送'], button[aria-label='Send'], button[class*='send'], button[type='submit'], div[class*='send'] button",
        fallbackMethod: 'click',
        delay: 200
      },
      theme: { mode: null },
      login: {
        detectSelector: "a[href*='login'], button[class*='login'], div[class*='login']",
        loggedInIndicator: "textarea, div[contenteditable='true'], [role='textbox']"
      },
      answer: {
        containerSelector: "div[class*='message'], div[class*='response'], div[class*='chat-message']",
        contentSelector: "div[class*='markdown'], div[class*='message-content'], div[class*='response-content']",
        streamingIndicator: "div[class*='cursor'], span[class*='typing'], div[class*='loading']"
      }
    }, overrides || {});
  }

  // 内置所有平台配置（不依赖 background，确保可靠）
  const BUILTIN_CONFIGS = {
    'chat.deepseek.com': makePlatformConfig('deepseek', 'DeepSeek', 'https://chat.deepseek.com/', 'chat.deepseek.com', {
      findInput: { selector: "textarea#chat-input, textarea[class*='input'], div[contenteditable='true'], div[role='textbox']", waitTimeout: 15000, pollInterval: 200 }
    }),
    'www.doubao.com': makePlatformConfig('doubao', '豆包', 'https://www.doubao.com/', 'www.doubao.com', {
      findInput: { selector: "div[contenteditable='true'][data-testid='chat_input'], div.ProseMirror, textarea", waitTimeout: 15000, pollInterval: 200 },
      send: { method: 'enter', buttonSelector: "button[data-testid='send_button'], button[aria-label='发送'], button[class*='send']", fallbackMethod: 'click' }
    }),
    'www.kimi.com': makePlatformConfig('kimi', 'Kimi', 'https://www.kimi.com/', 'www.kimi.com', {
      findInput: { selector: "[data-testid='msh-chatinput-editor'], [data-testid*='chatinput'], div[contenteditable='true'], textarea, div[role='textbox']", waitTimeout: 15000, pollInterval: 200 }
    }),
    'kimi.moonshot.cn': makePlatformConfig('kimi', 'Kimi', 'https://kimi.moonshot.cn/', 'kimi.moonshot.cn', {
      findInput: { selector: "[data-testid='msh-chatinput-editor'], [data-testid*='chatinput'], div[contenteditable='true'], textarea, div[role='textbox']", waitTimeout: 15000, pollInterval: 200 }
    }),
    'www.qianwen.com': makePlatformConfig('tongyi', '通义千问', 'https://www.qianwen.com/qianwen/', 'www.qianwen.com', {
      findInput: { selector: "div[data-slate-editor='true'], div[contenteditable='true'], textarea", waitTimeout: 15000, pollInterval: 150 },
      addText: { method: 'paste', focusFirst: true, clearBefore: true },
      addFile: { method: 'drop', dropTargetSelector: "div[data-slate-editor='true'], div[contenteditable='true']" }
    }),
    'tongyi.aliyun.com': makePlatformConfig('tongyi', '通义千问', 'https://www.qianwen.com/qianwen/', 'tongyi.aliyun.com', {
      findInput: { selector: "div[data-slate-editor='true'], div[contenteditable='true'], textarea", waitTimeout: 15000, pollInterval: 150 },
      addText: { method: 'paste', focusFirst: true, clearBefore: true },
      addFile: { method: 'drop', dropTargetSelector: "div[data-slate-editor='true'], div[contenteditable='true']" }
    }),
    'wenxin.baidu.com': makePlatformConfig('wenxin', '文心一言', 'https://wenxin.baidu.com/', 'wenxin.baidu.com', {
      findInput: { selector: "textarea.ci-textarea, textarea, div[contenteditable='true']", waitTimeout: 15000, pollInterval: 150 },
      addFile: {
        method: 'fileInput',
        fileInputSelector: "input[type='file']",
        preClick: [
          {
            selector: "button[class*='upload'], button[class*='image'], [class*='upload'] button, [class*='image-upload'], button[aria-label*='图片'], button[aria-label*='上传'], [class*='ci-upload']",
            waitFor: "input[type='file']",
            waitForTimeout: 3000,
            suppressFilePicker: true
          }
        ]
      }
    }),
    'yiyan.baidu.com': makePlatformConfig('wenxin', '文心一言', 'https://yiyan.baidu.com/', 'yiyan.baidu.com', {
      findInput: { selector: "textarea.ci-textarea, textarea, div[contenteditable='true']", waitTimeout: 15000, pollInterval: 150 },
      addFile: {
        method: 'fileInput',
        fileInputSelector: "input[type='file']",
        preClick: [
          {
            selector: "button[class*='upload'], button[class*='image'], [class*='upload'] button, [class*='image-upload'], button[aria-label*='图片'], button[aria-label*='上传'], [class*='ci-upload']",
            waitFor: "input[type='file']",
            waitForTimeout: 3000,
            suppressFilePicker: true
          }
        ]
      }
    }),
    'chatglm.cn': makePlatformConfig('zhipu', '智谱清言', 'https://chatglm.cn/', 'chatglm.cn', {
      findInput: { selector: "textarea.scroll-display-none, textarea, div[contenteditable='true']", waitTimeout: 15000, pollInterval: 150 },
      addFile: { method: 'fileInput', fileInputSelector: ".el-upload__input, input[type='file'][name='file']" }
    }),
    'yuanbao.tencent.com': makePlatformConfig('yuanbao', '腾讯元宝', 'https://yuanbao.tencent.com/', 'yuanbao.tencent.com', {
      findInput: { selector: ".ql-editor[contenteditable='true'], div[contenteditable='true'], .ProseMirror, textarea", waitTimeout: 15000, pollInterval: 150 },
      addFile: {
        method: 'fileInput',
        // 图片/文件是不同的 file input，按本次类型分别匹配
        fileInputSelector: {
          image: "input[type='file'][accept*='jpg'], input[type='file'][accept*='png'], input[type='file'][accept*='jpeg'], input[type='file'][accept*='image']",
          file: "input[type='file'][accept*='pdf'], input[type='file'][accept*='doc'], input[type='file'][accept*='txt'], input[type='file']:not([accept*='jpg']):not([accept*='png']):not([accept*='jpeg'])"
        },
        // 元宝需先点“+”展开工具菜单，再点“上传图片/上传文件”菜单项，对应文件框才挂载
        preClick: [
          {
            selectors: {
              image: "[data-new-input-control='add-tools-trigger'][aria-expanded='false']",
              file: "[data-new-input-control='add-tools-trigger'][aria-expanded='false']"
            },
            waitFor: "[data-new-input-control='add-tools-trigger'][aria-expanded='true']",
            waitForTimeout: 4000
          },
          {
            selectors: {
              image: "[data-new-input-control='add-tools'] [role='menu'] > div[class*='bg-border-secondary'] + button[role='menuitem'], [data-new-input-control='add-tools'] [role='menu'] button[role='menuitem']:nth-of-type(2)",
              file: "[data-new-input-control='add-tools'] [role='menu'] > div[class*='bg-border-secondary'] + button[role='menuitem'] + button[role='menuitem'], [data-new-input-control='add-tools'] [role='menu'] button[role='menuitem']:nth-of-type(3)"
            },
            waitForTimeout: 4000,
            suppressFilePicker: true
          }
        ]
      }
    }),
    'xinghuo.xfyun.cn': makePlatformConfig('xinghuo', '讯飞星火', 'https://xinghuo.xfyun.cn/', 'xinghuo.xfyun.cn'),
    'chat.baichuan-ai.com': makePlatformConfig('baichuan', '百川智能', 'https://chat.baichuan-ai.com/', 'chat.baichuan-ai.com'),
    'www.tiangong.cn': makePlatformConfig('tiangong', '天工AI', 'https://www.tiangong.cn/', 'www.tiangong.cn'),
    'chat.sensetime.com': makePlatformConfig('shangliang', '商量', 'https://chat.sensetime.com/', 'chat.sensetime.com'),
    'chat.openai.com': makePlatformConfig('chatgpt', 'ChatGPT', 'https://chat.openai.com/', 'chat.openai.com', {
      send: { method: 'enter', buttonSelector: "button[aria-label='Send'], button[data-testid*='send'], button[class*='send']", fallbackMethod: 'click' }
    }),
    'claude.ai': makePlatformConfig('claude', 'Claude', 'https://claude.ai/', 'claude.ai'),
    'gemini.google.com': makePlatformConfig('gemini', 'Gemini', 'https://gemini.google.com/', 'gemini.google.com', {
      findInput: { selector: "div[contenteditable='true'][role='textbox'], div.ql-editor, rich-textarea div[contenteditable='true'], textarea", waitTimeout: 15000, pollInterval: 150 },
      addFile: { method: 'paste' }
    }),
    'copilot.microsoft.com': makePlatformConfig('copilot', 'Copilot', 'https://copilot.microsoft.com/', 'copilot.microsoft.com'),
    'www.perplexity.ai': makePlatformConfig('perplexity', 'Perplexity', 'https://www.perplexity.ai/', 'www.perplexity.ai'),
    'grok.com': makePlatformConfig('grok', 'Grok', 'https://grok.com/', 'grok.com'),
    'chat.mistral.ai': makePlatformConfig('mistral', 'Mistral', 'https://chat.mistral.ai/', 'chat.mistral.ai'),
    'www.meta.ai': makePlatformConfig('metaai', 'Meta AI', 'https://www.meta.ai/', 'www.meta.ai'),
    'metaso.cn': makePlatformConfig('metaso', '秘塔AI搜索', 'https://metaso.cn/', 'metaso.cn', {
      findInput: { selector: "input[type='text'], input[type='search'], textarea, div[contenteditable='true']", waitTimeout: 15000, pollInterval: 200 },
      send: { method: 'enter', buttonSelector: "button[type='submit'], button[class*='search'], button[aria-label*='搜索']", fallbackMethod: 'click' },
      answer: {
        containerSelector: "div[class*='result'], div[class*='answer'], div[class*='summary'], div[class*='message']",
        contentSelector: "div[class*='markdown'], div[class*='content'], div[class*='text'], div[class*='summary']",
        streamingIndicator: "div[class*='loading'], div[class*='cursor'], span[class*='typing']"
      }
    })
  };

  // 优先使用内置配置（可靠），同时尝试从 background 获取自定义平台
  async function loadPlatformConfig() {
    // 先使用内置配置
    currentPlatform = BUILTIN_CONFIGS[currentDomain];
    if (currentPlatform) {
      console.log('[Duoda Content] Using builtin config:', currentPlatform.id);
    }

    // 尝试从 background 获取（可能包含用户自定义平台）
    try {
      const response = await chrome.runtime.sendMessage({
        type: 'GET_PLATFORM_CONFIG',
        domain: currentDomain
      });
      if (response && response.success && response.config) {
        currentPlatform = response.config;
        console.log('[Duoda Content] Updated config from BG:', currentPlatform.id);
      }
    } catch (e) {
      console.warn('[Duoda Content] BG config fetch failed, using builtin:', e.message);
    }

    return !!currentPlatform;
  }

  // 设置注入引擎的平台配置
  function setupInjector() {
    if (currentPlatform) {
      Injector.setPlatform(currentPlatform);
    }
  }

  // 选择器覆盖层 / 自定义平台变化时，热更新当前平台配置（不必刷新 iframe）
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes.duodaSelectorOverrides || changes.customPlatforms) {
        loadPlatformConfig().then(ok => {
          if (ok) {
            setupInjector();
            console.log('[Duoda Content] Platform config hot-reloaded');
          }
        });
      }
    });
  } catch (e) {}

  // ========== 消息来源验证 ==========
  function isFromParent(data) {
    return data && data.source === 'duoda-extension';
  }

  // ========== 向父页面发送消息 ==========
  function postToParent(type, payload) {
    if (!isInIframe) return;
    try {
      window.parent.postMessage({
        source: 'duoda-content',
        type,
        payload,
        platformId: currentPlatform ? currentPlatform.id : null,
        domain: currentDomain
      }, '*');
    } catch (e) {
      console.error('[Duoda Content] postToParent error:', e);
    }
  }

  // ========== 向 background 发送消息 ==========
  function sendToBackground(type, data) {
    try {
      chrome.runtime.sendMessage({ type, ...data });
    } catch (e) {
      console.error('[Duoda Content] sendToBackground error:', e);
    }
  }

  // ========== 同步检查输入框是否就绪 ==========
  function isInputReady() {
    if (!currentPlatform || !currentPlatform.findInput) return false;
    const selectors = currentPlatform.findInput.selector.split(',').map(s => s.trim());
    for (const sel of selectors) {
      try {
        if (document.querySelector(sel)) return true;
      } catch (e) {}
    }
    // 通用选择器兜底（自定义平台可能只配了 textarea，但实际页面用 input）
    const genericSelectors = [
      'textarea', 'div[contenteditable="true"]', 'div[contenteditable=""]',
      '[role="textbox"]', 'input[type="text"]', 'input[type="search"]',
      '.ProseMirror', '[data-testid*="input" i]'
    ];
    for (const sel of genericSelectors) {
      try {
        const el = document.querySelector(sel);
        if (el && el.offsetParent !== null) return true;
      } catch (e) {}
    }
    return false;
  }

  // ========== 核心: 执行注入并发送（快速轮询模式） ==========
  async function handleInjectAndSend(text, sendId, files) {
    // 防重复：同一个 sendId 只处理一次
    if (sendId && processedSendIds.has(sendId)) {
      console.log('[Duoda Content] Duplicate sendId, skipping:', sendId);
      return;
    }

    // 双保险：4秒内相同文本视为重复（拦截 sendId 不同但内容重复的情况；
    // 首次加载页面响应慢、内部轮询耗时长，窗口需足够覆盖一次完整发送）
    const now = Date.now();
    const fingerprint = (text || '').trim();
    while (recentSents.length && now - recentSents[0].time > 4000) recentSents.shift();
    if (fingerprint && recentSents.some(s => s.text === fingerprint)) {
      console.log('[Duoda Content] Duplicate text within 1.5s, skipping:', fingerprint.slice(0, 20));
      return;
    }
    if (fingerprint) recentSents.push({ text: fingerprint, time: now });

    if (sendId) processedSendIds.add(sendId);

    // 每次发送前都重新拉取配置，使“选择器覆盖层”改动即时生效（无需刷新 iframe）
    await loadPlatformConfig();
    setupInjector();

    if (!currentPlatform) {
      const result = { success: false, error: 'No platform config for domain: ' + currentDomain, sendId };
      postToParent('INJECT_RESULT', result);
      return;
    }

    console.log('[Duoda Content] Inject request, platform:', currentPlatform.id, 'text length:', text ? text.length : 0);

    // 快速轮询等待输入框就绪（最多5秒，每200ms检查一次）
    let attempts = 0;
    const maxAttempts = 25;
    const tryInject = async () => {
      attempts++;

      // 同步检查输入框是否就绪
      if (!isInputReady()) {
        if (attempts < maxAttempts) {
          setTimeout(tryInject, 200);
          return;
        }
        // 超时，直接尝试注入（可能通用选择器能找到）
        console.warn('[Duoda Content] Input not ready after', maxAttempts, 'attempts, trying anyway');
      }

      // 输入框就绪，立即注入
      const result = await Injector.injectAndSend({
        text,
        files: files || [],
        sendId,
        platform: currentPlatform
      });

      // 仅当失败发生在“发送之前”（没找到输入框 / 文本未注入，即根本没派发发送动作）才重试，
      // 发送阶段失败绝不重试，避免同一问题被多次发出
      const retryable = result.success === false &&
        (result.error === 'Input not found' || result.error === 'Text inject failed');
      if (retryable && attempts < 2) {
        console.warn('[Duoda Content] Pre-send failure, retry once', attempts, result.error);
        setTimeout(tryInject, 250);
        return;
      }

      console.log('[Duoda Content] Inject result:', result.success ? 'SUCCESS' : result.error);

      // 回传给父页面
      postToParent('INJECT_RESULT', result);

      // 如果成功，开始监听回答
      if (result.success) {
        startAnswerMonitoring(sendId);
      }
    };

    tryInject();
  }

  // ========== 仅注入文本（不发送） ==========
  async function handleInjectOnly(text) {
    if (!currentPlatform) return;
    const result = await Injector.injectTextOnly(text);
    postToParent('INJECT_ONLY_RESULT', result);
  }

  // ========== 一键登录：自动填充账号密码 ==========
  // 用原生 setter 设值并派发 input 事件，兼容 React/Vue 受控组件
  function setNativeValue(el, value) {
    try {
      const proto = el.tagName === 'TEXTAREA'
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value');
      if (setter && setter.set) setter.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
    } catch (e) {
      el.value = value;
    }
  }

  function visibleInputs() {
    return Array.from(document.querySelectorAll('input')).filter(el => {
      if (el.type === 'hidden' || el.disabled || el.readOnly) return false;
      return el.offsetParent !== null;
    });
  }

  // 找账号输入框：优先手机号/邮箱/用户名语义，其次可见文本框
  function findAccountInput() {
    const inputs = visibleInputs();
    const semanticKeywords = /(phone|mobile|tel|account|user|name|email|login|账号|手机|邮箱|用户|账户)/i;
    // 1. name/id/autocomplete/placeholder 语义匹配
    for (const el of inputs) {
      const sig = [el.name, el.id, el.autocomplete, el.placeholder].join(' ');
      if (semanticKeywords.test(sig) && el.type !== 'password') return el;
    }
    // 2. tel/email 类型
    const byType = inputs.find(el => el.type === 'tel' || el.type === 'email');
    if (byType) return byType;
    // 3. 第一个可见的文本类输入框（排除验证码框）
    return inputs.find(el =>
      ['text', 'tel', 'email', ''].includes(el.type) &&
      !/(验证码|code|captcha|verify)/i.test([el.name, el.id, el.placeholder].join(' '))
    );
  }

  function findPasswordInput() {
    return visibleInputs().find(el => el.type === 'password');
  }

  function findSmsCodeInput() {
    const inputs = visibleInputs();
    return inputs.find(el => /(验证码|sms|code|captcha|verify)/i.test([el.name, el.id, el.placeholder].join(' ')));
  }

  // 找登录按钮
  function findLoginButton() {
    const candidates = Array.from(document.querySelectorAll('button, [role="button"], a, input[type="submit"], div[class*="login"], span[class*="login"]'));
    const loginText = /(登\s*录|登\s*陸|log\s*in|sign\s*in|立即登录|下一步|next)/i;
    // 可见且文字匹配
    for (const el of candidates) {
      if (el.offsetParent === null && el.type !== 'submit') continue;
      const text = (el.innerText || el.value || el.textContent || '').trim();
      if (text && loginText.test(text) && text.length <= 12) return el;
    }
    // submit 类型兜底
    return document.querySelector('button[type="submit"], input[type="submit"]');
  }

  // 切换到“账号密码登录”方式：很多平台默认是扫码/短信验证码，密码框需先切换才出现
  async function switchToPasswordLogin() {
    const re = /(密码登录|账号密码登录|账号登录|账户登录|用户名登录|密码登|password\s*login|log\s*in\s*with\s*password|use\s*password)/i;
    // 先找语义明确的可点/tab 元素，再退而找 span/div/li，避免点到外层大容器
    const groups = [
      "button,a,[role='tab'],[role='button'],input[type='button']",
      'span,div,li,label'
    ];
    for (const sel of groups) {
      const els = Array.from(document.querySelectorAll(sel));
      for (const el of els) {
        if (el.offsetParent === null) continue;
        const t = (el.innerText || el.textContent || el.value || '').trim().replace(/\s+/g, '');
        if (t && t.length <= 10 && re.test(t)) {
          try {
            el.click();
            await new Promise(r => setTimeout(r, 350));
            console.log('[Duoda] Switched to password login via:', t);
            return true;
          } catch (e) {}
        }
      }
    }
    return false;
  }

  async function handleAutoLogin(account) {
    if (!account || !account.username) {
      postToParent('LOGIN_RESULT', { success: false, stage: 'no-account', message: '缺少账号' });
      return;
    }

    console.log('[Duoda Content] Auto login for', currentDomain);

    // 轮询等待登录表单出现（最多6秒）
    let accountInput = null;
    for (let i = 0; i < 30; i++) {
      accountInput = findAccountInput();
      if (accountInput) break;
      await new Promise(r => setTimeout(r, 200));
    }

    if (!accountInput) {
      // 没有账号输入框，可能已经登录
      postToParent('LOGIN_RESULT', { success: true, stage: 'already', message: '可能已登录，未发现登录表单' });
      return;
    }

    // 填充账号
    accountInput.focus();
    setNativeValue(accountInput, account.username);
    await new Promise(r => setTimeout(r, 150));

    let pwdInput = findPasswordInput();

    // 配置了密码但当前没有密码框：多半默认是扫码/短信登录，先切换到“账号密码登录”再找
    if (account.password && !pwdInput) {
      console.log('[Duoda] Password input missing, try switch to password login');
      await switchToPasswordLogin();
      for (let i = 0; i < 20 && !pwdInput; i++) {
        pwdInput = findPasswordInput();
        if (!pwdInput) {
          if (i === 3) await switchToPasswordLogin(); // 再尝试切换一次
          await new Promise(r => setTimeout(r, 200));
        }
      }
    }

    if (pwdInput && account.password) {
      // ===== 账号密码登录 =====
      // 切换登录方式可能重渲染了账号框，若已填值丢失则补填一次
      const accNow = findAccountInput();
      if (accNow && !(accNow.value || '').includes(account.username.trim())) {
        accNow.focus();
        setNativeValue(accNow, account.username);
        await new Promise(r => setTimeout(r, 120));
      }
      pwdInput.focus();
      setNativeValue(pwdInput, account.password);
      await new Promise(r => setTimeout(r, 200));

      // 勾选"同意协议"复选框（部分平台需要）
      document.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        const sig = [cb.name, cb.id, cb.className, cb.parentElement?.innerText || ''].join(' ');
        if (/(同意|协议|agree|protocol)/i.test(sig) && !cb.checked) {
          try { cb.click(); } catch (e) {}
        }
      });

      await new Promise(r => setTimeout(r, 200));
      const btn = findLoginButton();
      if (btn) {
        btn.click();
        postToParent('LOGIN_RESULT', { success: true, stage: 'password', message: '已填充账号密码并提交' });
      } else {
        postToParent('LOGIN_RESULT', { success: true, stage: 'filled', message: '已填充账号密码，请手动点击登录' });
      }
    } else {
      // ===== 短信验证码登录：只填手机号，验证码需人工输入 =====
      // 尝试点击"获取验证码"按钮（仅聚焦手机号后，不自动发送，避免频繁触发）
      postToParent('LOGIN_RESULT', {
        success: true,
        stage: 'sms',
        needSmsCode: true,
        message: '已填手机号，请点击获取验证码并手动输入'
      });
    }
  }

  // ========== 提取当前 AI 回答文本（用于一键总结） ==========
  function extractAnswerText() {
    // 1. 优先用平台配置的回答容器
    const cfg = currentPlatform && currentPlatform.answer;
    let candidates = [];

    if (cfg && cfg.containerSelector) {
      cfg.containerSelector.split(',').map(s => s.trim()).forEach(sel => {
        try { candidates.push(...document.querySelectorAll(sel)); } catch (e) {}
      });
    }

    // 2. 通用：常见的 AI 回答/消息内容容器
    const genericSels = [
      '[class*="markdown" i]', '[class*="message-content" i]', '[class*="answer" i]',
      '[class*="response" i]', '[class*="bubble" i]', '[class*="chat-content" i]',
      '[class*="assistant" i]', '[class*="bot-message" i]', '[data-role="assistant"]',
      'article', 'main [class*="content" i]'
    ];
    if (candidates.length === 0) {
      genericSels.forEach(sel => {
        try { candidates.push(...document.querySelectorAll(sel)); } catch (e) {}
      });
    }

    // 3. 取可见、文本最长的元素作为最新回答（通常最后一条 AI 回答内容最多）
    let best = '';
    for (const el of candidates) {
      if (el.offsetParent === null) continue;
      // 跳过输入框区域
      if (el.closest && el.closest('footer, .qw, [contenteditable="true"], textarea')) continue;
      const text = (el.innerText || el.textContent || '').trim();
      if (text.length > best.length) best = text;
    }

    // 4. 兜底：直接取 body 中最长的 markdown 块
    if (best.length < 20) {
      document.querySelectorAll('[class*="markdown" i], [class*="message" i]').forEach(el => {
        if (el.offsetParent === null) return;
        const t = (el.innerText || '').trim();
        if (t.length > best.length) best = t;
      });
    }

    // 清理多余空行
    return best.replace(/\n{3,}/g, '\n\n').trim();
  }

  function handleGetAnswerText() {
    const text = extractAnswerText();
    postToParent('ANSWER_TEXT', {
      text: text,
      length: text.length,
      url: window.location.href
    });
  }

  // ========== 提取完整多轮对话（用于导出 Markdown） ==========
  function classifyRole(el) {
    const sig = ((el.className || '') + ' ' + (el.getAttribute && (el.getAttribute('data-role') || '') || '') + ' ' + (el.getAttribute && (el.getAttribute('role') || '') || '')).toLowerCase();
    if (/(^|[\s_-])(user|human|question|self|right|me|customer|提问|我)([\s_-]|$)/.test(sig) || /data-role=.user/.test(sig)) return 'user';
    if (/(assistant|bot|answer|response|ai|agent|model|gpt|left|markdown|回复)/.test(sig)) return 'assistant';
    return null;
  }

  function extractConversation() {
    // 收集候选消息块：优先平台配置容器，再用通用选择器
    let blocks = [];
    const cfg = currentPlatform && currentPlatform.answer;
    const containerSels = [];
    if (cfg && cfg.containerSelector) containerSels.push(...cfg.containerSelector.split(',').map(s => s.trim()));
    containerSels.push(
      '[class*="message" i]', '[class*="chat-item" i]', '[class*="turn" i]',
      '[data-role="user"]', '[data-role="assistant"]', '[class*="conversation" i] > *'
    );
    const seen = new Set();
    for (const sel of containerSels) {
      try {
        document.querySelectorAll(sel).forEach(el => {
          if (el.offsetParent === null) return;
          if (el.closest('footer, [contenteditable="true"], textarea, .qw')) return;
          if (seen.has(el)) return;
          // 只保留有一定文本长度的叶子消息块
          const t = (el.innerText || '').trim();
          if (t.length < 2) return;
          seen.add(el);
          blocks.push(el);
        });
      } catch (e) {}
      if (blocks.length >= 2) break;
    }

    // 去重嵌套：若一个块包含另一个，保留更小的
    blocks = blocks.filter(el => !blocks.some(other => other !== el && el.contains(other) && (other.innerText || '').trim().length >= 2));

    const turns = [];
    blocks.forEach(el => {
      const role = classifyRole(el) || 'assistant';
      // 优先取内部 markdown/正文
      let bodyEl = el.querySelector('[class*="markdown" i], [class*="content" i], [class*="text" i]');
      let content = (bodyEl ? bodyEl.innerText : el.innerText) || '';
      content = content.replace(/\n{3,}/g, '\n\n').trim();
      if (!content) return;
      // 与上一条同角色且文本被包含则跳过
      const last = turns[turns.length - 1];
      if (last && last.role === role && (last.content.includes(content) || content.includes(last.content))) {
        if (content.length > last.content.length) last.content = content;
        return;
      }
      turns.push({ role, content });
    });

    return turns;
  }

  function handleGetConversation() {
    const turns = extractConversation();
    // 兜底：若无法分轮，至少返回最后一条回答
    if (turns.length === 0) {
      const t = extractAnswerText();
      if (t) turns.push({ role: 'assistant', content: t });
    }
    postToParent('CONVERSATION_DATA', { turns, url: window.location.href });
  }

  // ========== 开始新对话（尝试点击平台“新对话”按钮） ==========
  function handleNewChat() {
    try {
      // 常见“新对话”入口：按文字匹配按钮/链接，也兼容常见 testid/class
      const textRe = /^(新建对话|新对话|开启新对话|新的对话|新建聊天|新聊天|new\s*chat|start\s*new|create\s*new|new\s*conversation)$/i;
      const candidates = Array.from(document.querySelectorAll(
        "button, a, [role='button'], [class*='new-chat' i], [class*='create' i], [data-testid*='new' i], [data-testid*='create' i]"
      ));
      let clicked = false;
      for (const el of candidates) {
        if (el.offsetParent === null) continue;
        const txt = (el.innerText || el.textContent || el.getAttribute('aria-label') || el.title || '').trim();
        if (txt && txt.length <= 12 && textRe.test(txt.replace(/\s+/g, ' '))) {
          try { el.click(); clicked = true; Utils.log && console.log('[Duoda] New chat clicked:', txt); break; } catch (e) {}
        }
      }
      postToParent('NEW_CHAT_RESULT', { clicked, url: window.location.href });
    } catch (e) {
      postToParent('NEW_CHAT_RESULT', { clicked: false, error: e.message, url: window.location.href });
    }
  }

  // ========== 回答监听（MVP 基础版） ==========
  let answerObserver = null;
  let answerTimeoutTimer = null;
  let currentAnswerSendId = null;

  function startAnswerMonitoring(sendId) {
    currentAnswerSendId = sendId;

    // 先停止之前的监听（包括清除旧的超时 timer）
    stopAnswerMonitoring();

    if (!currentPlatform || !currentPlatform.answer) return;

    const config = currentPlatform.answer;
    const containerSelector = config.containerSelector;
    if (!containerSelector) return;

    // 记录当前已有回答数量
    const existingCount = document.querySelectorAll(containerSelector).length;
    console.log('[Duoda Content] Starting answer monitoring, existing messages:', existingCount);

    // 使用 MutationObserver 监听新回答
    answerObserver = new MutationObserver((mutations) => {
      const currentCount = document.querySelectorAll(containerSelector).length;
      if (currentCount > existingCount) {
        // 有新回答
        const newMessages = document.querySelectorAll(containerSelector);
        const latest = newMessages[newMessages.length - 1];

        // 检查是否还在流式输出
        const isStreaming = checkStreaming(latest, config.streamingIndicator);

        const answerData = {
          sendId: currentAnswerSendId,
          platformId: currentPlatform.id,
          content: extractAnswerContent(latest, config.contentSelector),
          isStreaming,
          timestamp: Date.now()
        };

        postToParent('ANSWER_UPDATE', answerData);

        if (!isStreaming) {
          // 回答完成
          postToParent('ANSWER_COMPLETE', answerData);
          stopAnswerMonitoring();
        }
      }
    });

    answerObserver.observe(document.body, {
      childList: true,
      subtree: true
    });

    // 超时保护：60秒后自动停止（保存 timer 以便清除，并用 sendId 校验防止误杀）
    answerTimeoutTimer = setTimeout(() => {
      // 只有当前 sendId 匹配且 observer 仍在运行时才判定超时
      if (answerObserver && currentAnswerSendId === sendId) {
        console.warn('[Duoda Content] Answer timeout for sendId:', sendId);
        stopAnswerMonitoring();
        postToParent('ANSWER_TIMEOUT', { sendId });
      }
    }, 60000);
  }

  function stopAnswerMonitoring() {
    if (answerObserver) {
      answerObserver.disconnect();
      answerObserver = null;
    }
    if (answerTimeoutTimer) {
      clearTimeout(answerTimeoutTimer);
      answerTimeoutTimer = null;
    }
  }

  function checkStreaming(element, indicatorSelector) {
    if (!indicatorSelector) return false;
    const indicators = indicatorSelector.split(',').map(s => s.trim());
    for (const sel of indicators) {
      if (element.querySelector(sel)) return true;
    }
    return false;
  }

  function extractAnswerContent(element, contentSelector) {
    if (!contentSelector) return element ? element.innerText : '';
    const selectors = contentSelector.split(',').map(s => s.trim());
    for (const sel of selectors) {
      const contentEl = element.querySelector(sel);
      if (contentEl) return contentEl.innerText || contentEl.textContent;
    }
    return element ? element.innerText : '';
  }

  // ========== 登录状态检测 ==========
  function checkAndReportLogin() {
    if (!currentPlatform) return;

    setTimeout(() => {
      const status = Injector.checkLoginStatus();
      console.log('[Duoda Content] Login status:', status);
      postToParent('LOGIN_STATUS', {
        platformId: currentPlatform.id,
        loggedIn: status.loggedIn,
        needLogin: status.needLogin
      });
      sendToBackground('LOGIN_STATUS', {
        platformId: currentPlatform.id,
        loggedIn: status.loggedIn
      });
    }, 2000); // 延迟2秒等页面加载
  }

  // ========== 主题应用 ==========
  function applyTheme(themeMode) {
    if (currentPlatform) {
      Injector.applyTheme(themeMode);
    }
  }

  // ========== 页面就绪通知 ==========
  function notifyReady() {
    postToParent('CONTENT_READY', {
      platformId: currentPlatform ? currentPlatform.id : null,
      domain: currentDomain,
      url: window.location.href,
      inIframe: isInIframe
    });
  }

  // ========== 监听父页面 postMessage ==========
  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!isFromParent(data)) return;

    console.log('[Duoda Content] Received from parent:', data.type, 'ready:', isReady);

    // PING 立即响应，不排队
    if (data.type === 'PING') {
      postToParent('PONG', { timestamp: Date.now() });
      return;
    }

    // 如果未就绪，加入队列
    if (!isReady) {
      console.log('[Duoda Content] Not ready, queuing message:', data.type);
      messageQueue.push(data);
      return;
    }

    processParentMessage(data);
  });

  function processParentMessage(data) {
    switch (data.type) {
      case 'INJECT_AND_SEND':
        handleInjectAndSend(data.text, data.sendId, data.files);
        break;

      case 'INJECT_ONLY':
        handleInjectOnly(data.text);
        break;

      case 'AUTO_LOGIN':
        handleAutoLogin(data.account);
        break;

      case 'GET_ANSWER_TEXT':
        handleGetAnswerText();
        break;

      case 'GET_CONVERSATION':
        handleGetConversation();
        break;

      case 'NEW_CHAT':
        handleNewChat();
        break;

      case 'APPLY_THEME':
        applyTheme(data.theme);
        break;

      case 'CHECK_LOGIN':
        checkAndReportLogin();
        break;

      case 'RELOAD':
        window.location.reload();
        break;

      default:
        console.warn('[Duoda Content] Unknown message type:', data.type);
    }
  }

  function flushMessageQueue() {
    console.log('[Duoda Content] Flushing message queue, count:', messageQueue.length);
    while (messageQueue.length > 0) {
      const data = messageQueue.shift();
      try {
        processParentMessage(data);
      } catch (e) {
        console.error('[Duoda Content] Error processing queued message:', e);
      }
    }
  }

  // ========== 监听 background 消息 ==========
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('[Duoda Content] Received from BG:', message.type);

    switch (message.type) {
      case 'INJECT_AND_SEND':
        if (currentPlatform && (!message.platformId || message.platformId === currentPlatform.id)) {
          handleInjectAndSend(message.text, message.sendId, message.files);
          sendResponse({ accepted: true });
        } else {
          sendResponse({ accepted: false, reason: 'platform mismatch' });
        }
        return true;

      case 'GET_PLATFORM_INFO':
        sendResponse({
          platformId: currentPlatform ? currentPlatform.id : null,
          domain: currentDomain,
          url: window.location.href,
          inIframe: isInIframe
        });
        return true;

      case 'CHECK_LOGIN':
        const status = Injector.checkLoginStatus();
        sendResponse(status);
        return true;

      default:
        sendResponse({ accepted: false });
        return true;
    }
  });

  // ========== 初始化 ==========
  async function init() {
    console.log('[Duoda Content] Initializing...');

    // 先用内置配置快速设置注入引擎
    currentPlatform = BUILTIN_CONFIGS[currentDomain] || null;
    setupInjector();

    // 立即标记就绪并处理消息队列（不等待配置加载）
    isReady = true;
    flushMessageQueue();

    // 通知父页面已就绪
    if (isInIframe) {
      setTimeout(notifyReady, 200);
    }

    // 异步加载完整平台配置（含自定义平台），加载后更新
    loadPlatformConfig().then(() => {
      setupInjector();
      console.log('[Duoda Content] Platform config updated, ready for injection');
      // 重新处理可能因配置缺失而失败的消息
      flushMessageQueue();
    });

    // 检测登录状态
    checkAndReportLogin();

    // 监听 URL 变化（SPA 路由）
    let lastUrl = window.location.href;
    setInterval(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        postToParent('URL_CHANGED', { url: lastUrl });
      }
    }, 1000);
  }

  // 页面加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  console.log('[Duoda Content] Script loaded on', currentDomain);
})();

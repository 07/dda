/**
 * 多答AI - Service Worker 杀手
 * 在 iframe 嵌入时禁用目标网站的 service worker 和 cache
 * 这是快速注入和实时显示回答的关键
 *
 * 原理：
 * 1. 重写 navigator.serviceWorker.register 为拒绝
 * 2. 取消所有已注册的 service worker
 * 3. 清除所有 cache storage
 */
(function () {
  'use strict';

  try {
    // 只在 iframe 中运行
    if (window.top === window.self) return;

    const sw = navigator.serviceWorker;
    if (!sw) return;

    // 1. 禁用 register
    try {
      Object.defineProperty(sw, 'register', {
        configurable: true,
        writable: true,
        value: function () {
          return Promise.reject(new DOMException('ServiceWorker disabled in Duoda embed', 'SecurityError'));
        }
      });
    } catch (e) {}

    // 2. 取消所有已注册的 service worker
    if (sw.getRegistrations) {
      sw.getRegistrations().then(function (registrations) {
        registrations.forEach(function (reg) {
          try {
            reg.unregister();
          } catch (e) {}
        });
      }).catch(function () {});
    }

    // 3. 清除所有 cache
    if (window.caches && caches.keys) {
      caches.keys().then(function (keys) {
        keys.forEach(function (key) {
          try {
            caches.delete(key);
          } catch (e) {}
        });
      }).catch(function () {});
    }

    console.log('[Duoda] ServiceWorker killed in embed');
  } catch (e) {
    console.warn('[Duoda] sw-killer error:', e);
  }
})();

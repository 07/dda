/**
 * 多答AI - 侧边栏主逻辑
 * 职责: 渲染平台 iframe、处理用户输入、广播注入指令、接收回答
 *
 * 依赖: DuodaUtils, DuodaConfigs
 */

'use strict';

(function () {
  const Utils = window.DuodaUtils;
  const Configs = window.DuodaConfigs;

  // ========== 状态 ==========
  const state = {
    platforms: [],
    enabledPlatforms: [],
    visiblePlatforms: new Set(), // 当前可见的平台 id（多选）
    iframes: {}, // platformId -> iframe element
    iframeReady: {}, // platformId -> boolean
    pendingMessages: {}, // platformId -> 待发送消息缓存
    platformStatus: {}, // platformId -> { ready, loggedIn, injecting, lastResult }
    currentSendId: null,
    attachments: [], // 已选择的文件列表
    groups: [], // 保存的分组列表
    accounts: {}, // platformId -> { username, password, autoLogin }
    autoLoginTried: {}, // 记录已尝试自动登录的平台+URL，避免重复
    collectedAnswers: {}, // 一键总结：platformId -> 回答文本
    summarySelection: new Set(), // 一键总结选中的目标AI
    collectedConversations: {}, // 导出：platformId -> turns[]
    exportSelection: new Set(), // 导出选中的AI
    iframeUrls: {}, // platformId -> iframe 内当前真实 URL（含会话ID，用于新标签定位到当前会话）
    history: [], // 历史对话记录
    historySearch: '', // 历史对话搜索关键词
    prompts: [], // 提示词列表（内置+自定义）
    currentConversation: null, // 当前正在进行的对话记录（发送时创建，用于补全会话URL）
    recognition: null, // Web Speech 语音识别实例
    voiceListening: false, // 是否正在语音输入
    voiceBaseText: '', // 开始录音时输入框已有文本
    voiceFinalText: '', // 本次录音已确定的识别文本
    lastQuestions: {}, // 诊断/单侧重试：platformId -> 上一条发送的问题
    dragIndex: null, // 设置中拖拽中的元素索引
    cardDragId: null, // 主界面卡片拖拽中的平台ID
    settings: {
      autoSend: true,
      darkMode: false,
      sendDelay: 300
    }
  };

  // ========== DOM 引用 ==========
  const dom = {
    tabs: document.getElementById('platform-tabs'),
    grid: document.getElementById('iframe-grid'),
    empty: document.getElementById('empty-state'),
    input: document.getElementById('input-text'),
    btnSend: document.getElementById('btn-send'),
    btnAttach: document.getElementById('btn-attach'),
    btnVoice: document.getElementById('btn-voice'),
    btnPrompts: document.getElementById('btn-prompts'),
    promptsPanel: document.getElementById('prompts-panel'),
    promptsList: document.getElementById('prompts-list'),
    promptsSearchInput: document.getElementById('prompts-search-input'),
    btnSettings: document.getElementById('btn-settings'),
    btnTheme: document.getElementById('btn-theme'),
    btnExpand: document.getElementById('btn-expand'),
    btnCloseSettings: document.getElementById('btn-close-settings'),
    settingsDrawer: document.getElementById('settings-drawer'),
    settingsOverlay: document.getElementById('settings-overlay'),
    settingsPlatforms: document.getElementById('settings-platforms'),
    settingAutoSend: document.getElementById('setting-auto-send'),
    settingDarkMode: document.getElementById('setting-dark-mode'),
    statusBar: document.getElementById('status-bar'),
    fileInput: document.getElementById('file-input'),
    attachmentsPreview: document.getElementById('attachments-preview'),
    // 分组管理
    groupsList: document.getElementById('groups-list'),
    btnSaveGroup: document.getElementById('btn-save-group'),
    // 导入导出
    btnExportConfig: document.getElementById('btn-export-config'),
    btnImportConfig: document.getElementById('btn-import-config'),
    importFileInput: document.getElementById('import-file-input'),
    btnResetConfig: document.getElementById('btn-reset-config'),
    settingSendDelay: document.getElementById('setting-send-delay'),
    // 账号管理
    accountsList: document.getElementById('accounts-list'),
    vaultPanel: document.getElementById('vault-panel'),
    btnLoginAll: document.getElementById('btn-login-all'),
    // 会员中心
    msBadge: document.getElementById('ms-badge'),
    msName: document.getElementById('ms-name'),
    msMeta: document.getElementById('ms-meta'),
    membershipInput: document.getElementById('membership-license-input'),
    btnMembershipActivate: document.getElementById('btn-membership-activate'),
    btnMembershipDeactivate: document.getElementById('btn-membership-deactivate'),
    membershipMsg: document.getElementById('membership-msg'),
    // 运行诊断
    btnDiagnose: document.getElementById('btn-diagnose'),
    diagnoseOverlay: document.getElementById('diagnose-overlay'),
    diagnoseList: document.getElementById('diagnose-list'),
    btnDiagnoseClose: document.getElementById('btn-diagnose-close'),
    btnDiagnoseCancel: document.getElementById('btn-diagnose-cancel'),
    btnDiagnoseRetryAll: document.getElementById('btn-diagnose-retry-all'),
    // 一键总结
    btnSummary: document.getElementById('btn-summary'),
    summaryOverlay: document.getElementById('summary-overlay'),
    summaryPlatforms: document.getElementById('summary-platforms'),
    summaryTip: document.getElementById('summary-tip'),
    summarySelectAll: document.getElementById('summary-select-all'),
    btnSummaryClose: document.getElementById('btn-summary-close'),
    btnSummaryCancel: document.getElementById('btn-summary-cancel'),
    btnSummaryConfirm: document.getElementById('btn-summary-confirm'),
    // 导出对话
    btnExport: document.getElementById('btn-export'),
    exportOverlay: document.getElementById('export-overlay'),
    exportPlatforms: document.getElementById('export-platforms'),
    exportTip: document.getElementById('export-tip'),
    exportSelectAll: document.getElementById('export-select-all'),
    btnExportClose: document.getElementById('btn-export-close'),
    btnExportCancel: document.getElementById('btn-export-cancel'),
    btnExportConfirm: document.getElementById('btn-export-confirm'),
    // 新建对话 / 历史对话
    btnNewChat: document.getElementById('btn-new-chat'),
    btnHistory: document.getElementById('btn-history'),
    historyOverlay: document.getElementById('history-overlay'),
    historyList: document.getElementById('history-list'),
    historySearchInput: document.getElementById('history-search-input'),
    btnHistoryClose: document.getElementById('btn-history-close'),
    btnHistoryCancel: document.getElementById('btn-history-cancel'),
    btnHistoryClear: document.getElementById('btn-history-clear'),
    // 平台表单
    btnAddPlatform: document.getElementById('btn-add-platform'),
    platformForm: document.getElementById('platform-form'),
    formTitle: document.getElementById('form-title'),
    formName: document.getElementById('form-name'),
    formUrl: document.getElementById('form-url'),
    formCategory: document.getElementById('form-category'),
    formInputSelector: document.getElementById('form-input-selector'),
    formTextMethod: document.getElementById('form-text-method'),
    formSendMethod: document.getElementById('form-send-method'),
    formSendSelector: document.getElementById('form-send-selector'),
    formSelectorsJson: document.getElementById('form-selectors-json'),
    btnFillDefault: document.getElementById('btn-fill-default'),
    // 提示词管理
    btnAddPrompt: document.getElementById('btn-add-prompt'),
    promptForm: document.getElementById('prompt-form'),
    promptFormTitle: document.getElementById('prompt-form-title'),
    promptCategory: document.getElementById('prompt-category'),
    promptTitleInput: document.getElementById('prompt-title-input'),
    promptContentInput: document.getElementById('prompt-content-input'),
    btnPromptCancel: document.getElementById('btn-prompt-cancel'),
    btnPromptSave: document.getElementById('btn-prompt-save'),
    promptsManageList: document.getElementById('prompts-manage-list'),
    promptsLimitHint: document.getElementById('prompts-limit-hint'),
    btnFormCancel: document.getElementById('btn-form-cancel'),
    btnFormSave: document.getElementById('btn-form-save')
  };

  // 表单编辑状态
  let editingPlatformId = null;

  // ========== 初始化 ==========
  async function init() {
    console.log('[Duoda Sidepanel] Initializing...');

    try {
      // 加载配置
      await Configs.init();
      state.platforms = Configs.getAllPlatforms();

      // 加载用户设置
      const userSettings = await Configs.getUserSettings();
      if (userSettings) {
        state.settings = { ...state.settings, ...userSettings };
      }

      // 确定启用的平台：用户设置优先，否则用默认列表
      const defaultSettings = Configs.getDefaultSettings() || {};
      const defaultEnabled = defaultSettings.defaultEnabled || [];
      if (userSettings && userSettings.enabledPlatforms) {
        state.enabledPlatforms = state.platforms.filter(p =>
          userSettings.enabledPlatforms.includes(p.id)
        );
      } else if (defaultEnabled.length > 0) {
        state.enabledPlatforms = state.platforms.filter(p =>
          defaultEnabled.includes(p.id)
        );
      } else {
        state.enabledPlatforms = Configs.getEnabledPlatforms();
      }

      console.log('[Duoda Sidepanel] Platforms:', state.platforms.length, 'Enabled:', state.enabledPlatforms.length);

      // 默认显示所有启用的平台
      state.enabledPlatforms.forEach(p => state.visiblePlatforms.add(p.id));

      // 初始化平台状态
      state.enabledPlatforms.forEach(p => {
        state.platformStatus[p.id] = {
          ready: false,
          loggedIn: null,
          injecting: false,
          lastResult: null
        };
      });

      // 渲染 UI
      renderTabs();
      renderIframes();
      renderSettingsPlatforms();
      applySettings();
      loadGroups();
      await loadAccounts();
      renderAccounts();
      renderVault();
      // 初始化会员状态（本地验签）
      if (typeof DuodaMembership !== 'undefined') {
        await DuodaMembership.init();
        renderMembership();
        updateUsageHint();
      }
      await loadHistory();
      await loadPrompts();

      // 绑定事件
      bindEvents();

      // 检查待发送消息（来自右键菜单/快捷键）
      checkPendingMessage();

      console.log('[Duoda Sidepanel] Initialized');
    } catch (e) {
      console.error('[Duoda Sidepanel] Init error:', e);
      setStatus('初始化失败: ' + e.message);
    }
  }

  // ========== 渲染平台标签 ==========
  function renderTabs() {
    dom.tabs.innerHTML = '';

    // "全部" 标签（所有平台都可见时高亮）
    const allVisible = state.enabledPlatforms.every(p => state.visiblePlatforms.has(p.id));
    const allTab = createTab('all', '全部', allVisible);
    dom.tabs.appendChild(allTab);

    // 各平台标签
    state.enabledPlatforms.forEach(platform => {
      const isVisible = state.visiblePlatforms.has(platform.id);
      const tab = createTab(platform.id, platform.name, isVisible);
      dom.tabs.appendChild(tab);
    });

    // 标签过多时启用鼠标拖拽划动
    requestAnimationFrame(updateTabsDragState);
  }

  // 判断标签栏是否溢出，溢出才显示抓手并允许拖拽
  function updateTabsDragState() {
    if (!dom.tabs) return;
    const overflow = dom.tabs.scrollWidth > dom.tabs.clientWidth + 2;
    dom.tabs.classList.toggle('can-drag', overflow);
  }

  // 为标签栏绑定一次鼠标按住左右拖拽滚动
  function initTabsDragScroll() {
    const el = dom.tabs;
    if (!el) return;
    let isDown = false, startX = 0, startScroll = 0, moved = false;

    el.addEventListener('mousedown', (e) => {
      // 只响应主键
      if (e.button !== 0) return;
      isDown = true;
      moved = false;
      startX = e.pageX;
      startScroll = el.scrollLeft;
    });

    el.addEventListener('mousemove', (e) => {
      if (!isDown) return;
      const dx = e.pageX - startX;
      if (Math.abs(dx) > 5) {
        moved = true;
        el.classList.add('dragging');
        el.scrollLeft = startScroll - dx;
      }
    });

    const endDrag = () => {
      if (!isDown) return;
      isDown = false;
      if (moved) {
        // 刚结束拖拽，阻止本次松手产生的 click（避免误选中标签）
        const block = (ev) => { ev.preventDefault(); ev.stopPropagation(); };
        el.addEventListener('click', block, true);
        setTimeout(() => el.removeEventListener('click', block, true), 0);
      }
      el.classList.remove('dragging');
    };
    el.addEventListener('mouseup', endDrag);
    el.addEventListener('mouseleave', endDrag);

    // 鼠标滚轮在标签栏上时转为横向滚动
    el.addEventListener('wheel', (e) => {
      if (el.scrollWidth <= el.clientWidth) return;
      if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
        el.scrollLeft += e.deltaY;
        e.preventDefault();
      }
    }, { passive: false });
  }

  function createTab(id, name, active) {
    const tab = document.createElement('div');
    tab.className = 'qw-tab' + (active ? ' active' : '');
    tab.dataset.platformId = id;

    const label = document.createElement('span');
    label.textContent = name;
    label.style.flex = '1';
    tab.appendChild(label);

    // 关闭按钮（"全部"标签不需要关闭按钮）
    if (id !== 'all') {
      const closeBtn = document.createElement('span');
      closeBtn.className = 'qw-tab-close';
      closeBtn.textContent = '✕';
      closeBtn.title = '关闭';
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        hidePlatform(id);
      });
      tab.appendChild(closeBtn);
    }

    tab.addEventListener('click', () => {
      if (id === 'all') {
        // 点击"全部"：显示所有平台
        showAllPlatforms();
      } else {
        // 点击平台标签：切换可见性
        togglePlatformVisibility(id);
      }
    });
    return tab;
  }

  // 显示所有平台
  function showAllPlatforms() {
    state.enabledPlatforms.forEach(p => state.visiblePlatforms.add(p.id));
    renderTabs();
    updateIframeVisibility();
  }

  // 切换平台可见性
  function togglePlatformVisibility(id) {
    if (state.visiblePlatforms.has(id)) {
      state.visiblePlatforms.delete(id);
    } else {
      state.visiblePlatforms.add(id);
    }
    renderTabs();
    updateIframeVisibility();
  }

  // 隐藏单个平台
  function hidePlatform(id) {
    state.visiblePlatforms.delete(id);
    renderTabs();
    updateIframeVisibility();
  }

  // ========== 渲染 iframe ==========
  function renderIframes() {
    dom.grid.innerHTML = '';

    if (state.enabledPlatforms.length === 0) {
      dom.empty.style.display = 'flex';
      dom.grid.style.display = 'none';
      return;
    }

    dom.empty.style.display = 'none';
    dom.grid.style.display = 'flex';

    state.enabledPlatforms.forEach(platform => {
      const card = createIframeCard(platform);
      dom.grid.appendChild(card);
      state.iframes[platform.id] = card.querySelector('iframe');
    });

    updateGridLayout();
    updateIframeVisibility();
  }

  // 根据容器实际宽度动态决定：放得下就平分占满，放不下才固定宽度+横向滚动
  function updateGridLayout() {
    if (!dom.grid) return;
    // 只统计当前可见的卡片（隐藏的卡片 display:none，不参与宽度计算）
    const cards = Array.from(dom.grid.querySelectorAll('.qw-iframe-card'))
      .filter(c => c.style.display !== 'none');
    const count = cards.length;
    if (count === 0) return;

    const MAX_PER_ROW = 5; // 一行最多平分 5 个，超过则固定卡片宽度并出横向滚动条
    const GAP = 8;
    const PADDING = 16; // grid 左右 padding 合计（padding:8px × 2）
    // 用父容器宽度计算：grid 在 scroll 态会被内容撑大，其 clientWidth 不可靠
    const parentW = (dom.grid.parentElement && dom.grid.parentElement.clientWidth) || dom.grid.clientWidth;
    const available = parentW - PADDING;
    const widthFor = n => (available - (n - 1) * GAP) / n;

    dom.grid.classList.remove('grid-fit', 'grid-scroll');
    if (count <= MAX_PER_ROW) {
      // 5 个以内：平分占满，右边不留空白
      dom.grid.classList.add('grid-fit');
      dom.grid.style.removeProperty('--duoda-card-w');
    } else {
      // 超过 5 个：卡片固定为“5 等分”宽度（设下限保证可读），多出的横向滚动，不再继续压缩
      dom.grid.classList.add('grid-scroll');
      const cardW = Math.max(260, widthFor(MAX_PER_ROW));
      dom.grid.style.setProperty('--duoda-card-w', cardW + 'px');
    }
  }

  function createIframeCard(platform) {
    const card = document.createElement('div');
    card.className = 'qw-iframe-card';
    card.dataset.platformId = platform.id;
    // 记录在 state.platforms 中的索引，用于拖拽排序
    const platformIndex = state.platforms.findIndex(p => p.id === platform.id);
    card.dataset.platformIndex = platformIndex;

    const header = document.createElement('div');
    header.className = 'qw-iframe-header';
    header.draggable = true;
    header.title = '拖动可排序';
    header.style.cursor = 'grab';

    // ===== 拖拽排序 =====
    header.addEventListener('dragstart', (e) => {
      state.cardDragId = platform.id;
      card.classList.add('qw-card-dragging');
      header.style.cursor = 'grabbing';
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', platform.id);
      // 关键：拖拽时禁用所有 iframe 的 pointer-events，否则 iframe 会吞掉鼠标事件
      document.querySelectorAll('.qw-iframe').forEach(f => f.style.pointerEvents = 'none');
    });

    header.addEventListener('dragend', () => {
      state.cardDragId = null;
      card.classList.remove('qw-card-dragging');
      header.style.cursor = 'grab';
      document.querySelectorAll('.qw-iframe').forEach(f => f.style.pointerEvents = '');
      // 清除所有拖拽指示器
      document.querySelectorAll('.qw-iframe-card').forEach(c => c.classList.remove('qw-card-drag-over'));
    });

    card.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      if (state.cardDragId && state.cardDragId !== platform.id) {
        card.classList.add('qw-card-drag-over');
      }
    });

    card.addEventListener('dragleave', () => {
      card.classList.remove('qw-card-drag-over');
    });

    card.addEventListener('drop', (e) => {
      e.preventDefault();
      card.classList.remove('qw-card-drag-over');
      const draggedId = state.cardDragId || e.dataTransfer.getData('text/plain');
      if (!draggedId || draggedId === platform.id) return;
      // 轻量排序：只重排 DOM，不刷新 iframe
      reorderCardsLightweight(draggedId, platform.id);
    });

    const title = document.createElement('div');
    title.className = 'qw-iframe-title';
    title.textContent = platform.name;

    const status = document.createElement('div');
    status.className = 'qw-iframe-status';
    status.id = `status-${platform.id}`;
    status.innerHTML = '<span class="qw-dot qw-dot-loading"></span>加载中';
    // 点击状态条：若上次发送失败则重发上一条
    status.addEventListener('click', () => {
      const st = state.platformStatus[platform.id];
      if (st && st.lastError) retryPlatform(platform.id);
    });

    const actions = document.createElement('div');
    actions.className = 'qw-iframe-actions';

    const closeBtn = document.createElement('button');
    closeBtn.className = 'qw-icon-btn qw-btn-small';
    closeBtn.title = '关闭';
    closeBtn.innerHTML = '✕';
    closeBtn.addEventListener('click', () => hidePlatform(platform.id));

    const reloadBtn = document.createElement('button');
    reloadBtn.className = 'qw-icon-btn qw-btn-small';
    reloadBtn.title = '刷新页面';
    reloadBtn.innerHTML = '↻';
    reloadBtn.addEventListener('click', () => reloadIframe(platform.id));

    const retryBtn = document.createElement('button');
    retryBtn.className = 'qw-icon-btn qw-btn-small qw-btn-retry';
    retryBtn.title = '向该 AI 重发上一条问题';
    retryBtn.innerHTML = '↺';
    retryBtn.addEventListener('click', () => retryPlatform(platform.id));

    const openBtn = document.createElement('button');
    openBtn.className = 'qw-icon-btn qw-btn-small';
    openBtn.title = '新标签页打开（定位到当前会话）';
    openBtn.innerHTML = '↗';
    openBtn.addEventListener('click', () => {
      // 优先打开 iframe 内当前真实地址（带会话ID，定位到正在进行的对话），否则回退到平台首页
      const currentUrl = state.iframeUrls[platform.id] || platform.url;
      chrome.tabs.create({ url: currentUrl });
    });

    actions.appendChild(closeBtn);
    actions.appendChild(retryBtn);
    actions.appendChild(reloadBtn);
    actions.appendChild(openBtn);

    header.appendChild(title);
    header.appendChild(status);
    header.appendChild(actions);

    const iframeWrapper = document.createElement('div');
    iframeWrapper.className = 'qw-iframe-wrapper';

    const iframe = document.createElement('iframe');
    iframe.src = platform.url;
    iframe.className = 'qw-iframe';
    iframe.dataset.platformId = platform.id;
    iframe.setAttribute('allow', 'clipboard-read; clipboard-write');
    iframe.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');

    iframeWrapper.appendChild(iframe);
    card.appendChild(header);
    card.appendChild(iframeWrapper);

    return card;
  }

  function updateIframeVisibility() {
    const cards = dom.grid.querySelectorAll('.qw-iframe-card');
    let visibleCount = 0;
    cards.forEach(card => {
      const pid = card.dataset.platformId;
      if (state.visiblePlatforms.has(pid)) {
        card.style.display = 'flex';
        visibleCount++;
      } else {
        card.style.display = 'none';
      }
    });

    // 根据可见平台数量动态调整布局（平分占满 / 横向滚动）
    updateGridLayout();

    // 如果没有可见平台，显示空状态
    if (visibleCount === 0 && state.enabledPlatforms.length > 0) {
      dom.empty.style.display = 'flex';
      dom.empty.querySelector('.qw-empty-text').textContent = '所有平台已关闭';
      dom.empty.querySelector('.qw-empty-hint').textContent = '点击上方"全部"显示所有平台';
    } else {
      dom.empty.style.display = 'none';
    }
  }

  function reloadIframe(platformId) {
    const iframe = state.iframes[platformId];
    if (iframe) {
      setPlatformStatus(platformId, 'loading', '加载中...');
      iframe.src = iframe.src; // 重新加载
    }
  }

  // ========== 发送消息 ==========
  async function handleSend() {
    const text = dom.input.value.trim();
    if (!text) {
      setStatus('请输入内容');
      return;
    }

    if (state.enabledPlatforms.length === 0) {
      setStatus('没有启用的平台');
      return;
    }

    // 生成发送 ID
    const sendId = Utils.generateId('send');
    state.currentSendId = sendId;

    console.log('[Duoda Sidepanel] Sending to all platforms, sendId:', sendId, 'text length:', text.length);

    // 重置状态
    state.enabledPlatforms.forEach(p => {
      state.platformStatus[p.id].injecting = true;
      state.platformStatus[p.id].lastResult = null;
      setPlatformStatus(p.id, 'injecting', '正在问...');
    });

    // 并行发送到所有可见的平台（无延迟，同时发送）
    const targetPlatforms = state.enabledPlatforms.filter(p => state.visiblePlatforms.has(p.id));

    if (targetPlatforms.length === 0) {
      setStatus('没有可见的平台，请先显示平台');
      return;
    }

    // 免费版限制1：一次最多同时回答 N 个 AI（会员无限制）
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.isPro()) {
      const max = DuodaMembership.getMaxConcurrent();
      if (targetPlatforms.length > max) {
        setStatus(`免费版一次最多选 ${max} 个 AI 同时回答（当前 ${targetPlatforms.length} 个），会员无限制`);
        showProGate('无限制同时回答 AI 数量');
        return;
      }
      // 免费版限制2：每天最多 N 次提问（一次发送算1次，不管选了几个AI）
      const remaining = await DuodaMembership.getDailyQuestionsRemaining();
      if (remaining < 1) {
        const used = await DuodaMembership.getDailyQuestionsUsed();
        const limit = DuodaMembership.getFreeLimits().dailyQuestions;
        setStatus(`今日免费提问次数已用完（${used}/${limit} 次），会员无限制`);
        showProGate('无限制每日提问次数');
        return;
      }
    }

    // 记录每个平台本次问题，供诊断/单侧重试使用；并初始化健康统计
    targetPlatforms.forEach(p => {
      state.lastQuestions[p.id] = text;
      const st = state.platformStatus[p.id] || {};
      st.sendCount = (st.sendCount || 0) + 1;
      st.lastQuestion = text;
      state.platformStatus[p.id] = st;
    });

    setStatus(`发送中 (0/${targetPlatforms.length})`);

    const sendPromises = targetPlatforms.map(platform =>
      sendToIframe(platform.id, {
        type: 'INJECT_AND_SEND',
        text,
        sendId,
        files: state.attachments
      })
    );

    Promise.all(sendPromises).then(() => {
      console.log('[Duoda Sidepanel] All send requests dispatched');
    });

    // 记录历史对话：先建记录，稍后补全各平台会话 URL
    const record = {
      id: Utils.generateId('conv'),
      title: text.length > 40 ? text.slice(0, 40) + '…' : text,
      question: text,
      createdAt: Date.now(),
      platformIds: targetPlatforms.map(p => p.id),
      platformNames: targetPlatforms.map(p => p.name),
      urls: {} // platformId -> 会话 URL，延迟补全
    };
    state.currentConversation = record;
    // 6 秒后各平台应已跳转到带会话ID的地址，收集并落盘
    setTimeout(() => finalizeConversationRecord(record), 6000);

    // 清空输入框和附件
    dom.input.value = '';
    state.attachments = [];
    renderAttachments();
    autoResizeInput();
    // 免费版：本次发送计入每日提问次数（一次发送算1次，不管选了几个AI）
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.isPro()) {
      await DuodaMembership.recordQuestion();
    }
    updateUsageHint();
  }

  // 补全一条对话记录里各平台的会话 URL，并写入历史
  function finalizeConversationRecord(record) {
    if (!record) return;
    record.platformIds.forEach(id => {
      const u = state.iframeUrls[id];
      if (u) record.urls[id] = u;
    });
    // 移除同 id 旧记录，置顶保存（会员 200 条，免费 10 条）
    state.history = state.history.filter(r => r.id !== record.id);
    state.history.unshift(record);
    const maxHistory = (DuodaMembership && DuodaMembership.isPro()) ? 200 : 10;
    if (state.history.length > maxHistory) state.history = state.history.slice(0, maxHistory);
    saveHistory();
  }

  // ========== 文件上传 ==========
  function handleFileSelect(e) {
    const files = Array.from(e.target.files || []);
    addFiles(files);
    e.target.value = '';
  }

  // 通用：添加文件（来自选择、粘贴、拖拽）
  function addFiles(files) {
    if (!files || files.length === 0) return;

    // 免费版仅支持图片上传；文档/PDF 等为会员功能
    let accepted = Array.from(files);
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.isPro()) {
      const images = accepted.filter(f => f.type && f.type.startsWith('image/'));
      const docs = accepted.filter(f => !(f.type && f.type.startsWith('image/')));
      if (docs.length > 0) {
        if (images.length === 0) {
          showProGate('文档文件上传（PDF/Word/TXT 等）');
          return;
        }
        setStatus(`已跳过 ${docs.length} 个文档文件（免费版仅支持图片，会员可上传文档）`);
        accepted = images;
      }
    }

    accepted.forEach(file => {
      // 限制文件大小 10MB
      if (file.size > 10 * 1024 * 1024) {
        setStatus(`文件 ${file.name || '剪贴板图片'} 超过10MB，已跳过`);
        return;
      }

      const reader = new FileReader();
      reader.onload = (ev) => {
        // 粘贴的图片没有文件名，自动生成
        let fileName = file.name;
        if (!fileName) {
          const ext = (file.type && file.type.split('/')[1]) || 'png';
          fileName = `粘贴图片-${Date.now()}.${ext === 'jpeg' ? 'jpg' : ext}`;
        }
        const attachment = {
          name: fileName,
          type: file.type || 'image/png',
          size: file.size,
          dataUrl: ev.target.result
        };
        state.attachments.push(attachment);
        renderAttachments();
      };
      reader.readAsDataURL(file);
    });
  }

  // 粘贴图片/文件
  function handlePaste(e) {
    const items = e.clipboardData && e.clipboardData.items;
    if (!items) return;

    const files = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      // 粘贴的文件或图片
      if (item.kind === 'file') {
        const file = item.getAsFile();
        if (file) files.push(file);
      }
    }

    if (files.length > 0) {
      e.preventDefault();
      addFiles(files);
      setStatus(`已粘贴 ${files.length} 个文件`);
    }
  }

  // 拖拽文件到输入区
  function handleDrop(e) {
    const files = Array.from(e.dataTransfer && e.dataTransfer.files || []);
    if (files.length > 0) {
      e.preventDefault();
      addFiles(files);
      setStatus(`已添加 ${files.length} 个文件`);
    }
  }

  function renderAttachments() {
    if (!dom.attachmentsPreview) return;

    if (state.attachments.length === 0) {
      dom.attachmentsPreview.style.display = 'none';
      dom.attachmentsPreview.innerHTML = '';
      return;
    }

    dom.attachmentsPreview.style.display = 'flex';
    dom.attachmentsPreview.innerHTML = '';

    state.attachments.forEach((att, index) => {
      const item = document.createElement('div');
      item.className = 'qw-attachment-item';

      // 图片显示缩略图
      if (att.type && att.type.startsWith('image/')) {
        const img = document.createElement('img');
        img.src = att.dataUrl;
        item.appendChild(img);
      } else {
        const icon = document.createElement('span');
        icon.textContent = '📄';
        icon.style.fontSize = '14px';
        item.appendChild(icon);
      }

      const name = document.createElement('span');
      name.className = 'qw-attachment-name';
      name.textContent = att.name;
      name.title = att.name;
      item.appendChild(name);

      const remove = document.createElement('span');
      remove.className = 'qw-attachment-remove';
      remove.textContent = '✕';
      remove.onclick = () => removeAttachment(index);
      item.appendChild(remove);

      dom.attachmentsPreview.appendChild(item);
    });
  }

  function removeAttachment(index) {
    state.attachments.splice(index, 1);
    renderAttachments();
  }

  /**
   * 等待 iframe 就绪（通过 ping/pong）
   */
  async function waitForIframeReady(platformId, timeout = 3000) {
    if (state.iframeReady[platformId]) return true;

    const iframe = state.iframes[platformId];
    if (!iframe || !iframe.contentWindow) return false;

    const startTime = Date.now();
    const interval = 200;

    while (Date.now() - startTime < timeout) {
      // 发送 ping
      try {
        iframe.contentWindow.postMessage({
          source: 'duoda-extension',
          type: 'PING'
        }, '*');
      } catch (e) {
        // ignore
      }

      await Utils.sleep(interval);

      if (state.iframeReady[platformId]) {
        return true;
      }
    }

    console.warn('[Duoda Sidepanel] Iframe ready timeout:', platformId);
    return false;
  }

  /**
   * 发送消息到 iframe，带重试和缓存
   */
  async function sendToIframe(platformId, message, retries = 1) {
    const iframe = state.iframes[platformId];
    if (!iframe || !iframe.contentWindow) {
      console.warn('[Duoda Sidepanel] Iframe not found:', platformId);
      return false;
    }

    // 如果 iframe 未就绪，缓存消息，等就绪后自动发送
    if (!state.iframeReady[platformId]) {
      console.log('[Duoda Sidepanel] Iframe not ready, caching message for:', platformId);
      state.pendingMessages[platformId] = message;
      return false;
    }

    // 直接发送
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const payload = { source: 'duoda-extension', ...message };
        iframe.contentWindow.postMessage(payload, '*');
        console.log('[Duoda Sidepanel] Sent to', platformId, ':', message.type, '(attempt', attempt + 1, ')');
        return true;
      } catch (e) {
        console.error('[Duoda Sidepanel] sendToIframe error:', e, 'attempt', attempt + 1);
        if (attempt < retries) {
          await Utils.sleep(300);
        }
      }
    }
    return false;
  }

  // ========== 监听 iframe 消息 ==========
  function isMessageFromOurIframe(event) {
    // 校验消息来源：必须是我们创建的 iframe 的 contentWindow
    if (!event.source || typeof event.source !== 'object') return false;
    const iframes = document.querySelectorAll('.qw-iframe');
    for (const f of iframes) {
      if (f.contentWindow === event.source) return true;
    }
    return false;
  }

  function listenIframeMessages() {
    window.addEventListener('message', (event) => {
      const data = event.data;
      if (!data || data.source !== 'duoda-content') return;
      // 安全校验：消息必须来自我们创建的 iframe，防止恶意页面伪造
      if (!isMessageFromOurIframe(event)) {
        console.warn('[Duoda] Rejected message from unknown source:', event.origin);
        return;
      }

      const platformId = data.platformId;
      console.log('[Duoda Sidepanel] Received from', platformId, ':', data.type);

      switch (data.type) {
        case 'CONTENT_READY':
          handleContentReady(platformId, data.payload);
          break;

        case 'INJECT_RESULT':
          handleInjectResult(platformId, data.payload);
          break;

        case 'ANSWER_UPDATE':
          handleAnswerUpdate(platformId, data.payload);
          break;

        case 'ANSWER_COMPLETE':
          handleAnswerComplete(platformId, data.payload);
          break;

        case 'ANSWER_TIMEOUT':
          // 若该平台已回答完成，忽略迟到的超时信号（防止旧 timer 误杀）
          if (state.platformStatus[platformId] && state.platformStatus[platformId].statusType === 'success') {
            console.log('[Duoda] Ignore stale timeout for completed platform:', platformId);
          } else {
            setPlatformStatus(platformId, 'warning', '回答超时');
          }
          break;

        case 'LOGIN_STATUS':
          handleLoginStatus(platformId, data.payload);
          break;

        case 'LOGIN_RESULT':
          handleLoginResult(platformId, data.payload);
          break;

        case 'ANSWER_TEXT':
          if (data.payload && data.payload.text) {
            state.collectedAnswers[platformId] = data.payload.text;
          }
          break;

        case 'CONVERSATION_DATA':
          if (data.payload && Array.isArray(data.payload.turns)) {
            state.collectedConversations[platformId] = data.payload.turns;
          }
          break;

        case 'URL_CHANGED':
          if (data.payload && data.payload.url) {
            state.iframeUrls[platformId] = data.payload.url;
            // 实时补全当前对话记录里该平台的会话 URL
            if (state.currentConversation && state.currentConversation.platformIds.includes(platformId)) {
              state.currentConversation.urls[platformId] = data.payload.url;
            }
          }
          console.log('[Duoda Sidepanel] URL changed for', platformId, ':', data.payload.url);
          break;

        case 'PONG':
          state.iframeReady[platformId] = true;
          break;

        default:
          break;
      }
    });
  }

  function handleContentReady(platformId, payload) {
    if (state.platformStatus[platformId]) {
      state.platformStatus[platformId].ready = true;
    }
    state.iframeReady[platformId] = true;
    if (payload && payload.url) state.iframeUrls[platformId] = payload.url;
    setPlatformStatus(platformId, 'ready', '就绪');
    console.log('[Duoda Sidepanel] Iframe ready:', platformId);

    // 检查是否有缓存的待发送消息
    if (state.pendingMessages[platformId]) {
      const pendingMsg = state.pendingMessages[platformId];
      delete state.pendingMessages[platformId];
      console.log('[Duoda Sidepanel] Sending cached message to:', platformId);
      sendToIframe(platformId, pendingMsg);
    }

    // 若该平台保存了账号且开启自动登录，则在页面就绪后自动填充登录（每个页面会话只触发一次）
    const acc = state.accounts[platformId];
    if (acc && acc.username && acc.autoLogin !== false) {
      const key = platformId + ':' + (payload && payload.url);
      if (!state.autoLoginTried[key]) {
        state.autoLoginTried[key] = true;
        // 延迟一点，等登录页渲染；auto=true 表示自动登录，保险库锁定时不弹窗、只填账号
        setTimeout(() => loginPlatform(platformId, true), 800);
      }
    }
  }

  function handleInjectResult(platformId, result) {
    if (!state.platformStatus[platformId]) return;

    const st = state.platformStatus[platformId];
    st.injecting = false;
    st.lastResult = result;

    if (result.success) {
      st.lastSuccessAt = Date.now();
      st.lastError = null;
      setPlatformStatus(platformId, 'success', '已发送');
    } else {
      st.lastErrorAt = Date.now();
      st.lastError = result.error || '发送失败';
      st.failCount = (st.failCount || 0) + 1;
      setPlatformStatus(platformId, 'error', st.lastError + '（点击重发）');
    }

    // 更新全局状态
    const total = state.enabledPlatforms.filter(p => state.visiblePlatforms.has(p.id)).length;
    const done = Object.values(state.platformStatus).filter(s => !s.injecting).length;
    const allDone = done >= total;

    if (allDone) {
      const successCount = Object.values(state.platformStatus).filter(s => s.lastResult && s.lastResult.success).length;
      setStatus(`发送完成: ${successCount}/${total} 成功`);
    } else {
      setStatus(`发送中 (${done}/${total})`);
    }
  }

  function handleAnswerUpdate(platformId, payload) {
    if (payload.isStreaming) {
      setPlatformStatus(platformId, 'answering', '回答中...');
    }
  }

  function handleAnswerComplete(platformId, payload) {
    setPlatformStatus(platformId, 'success', '回答完成');
  }

  function handleLoginStatus(platformId, payload) {
    if (state.platformStatus[platformId]) {
      state.platformStatus[platformId].loggedIn = payload.loggedIn;
      if (!payload.loggedIn) {
        setPlatformStatus(platformId, 'warning', '需登录');
      }
    }
  }

  function handleLoginResult(platformId, payload) {
    const platform = state.platforms.find(p => p.id === platformId);
    const name = platform ? platform.name : platformId;
    if (!payload) return;

    if (payload.needSmsCode) {
      setPlatformStatus(platformId, 'warning', '需输验证码');
      setStatus(`${name}：已填手机号，请在卡片中输入短信验证码`);
    } else if (payload.success) {
      setStatus(`${name}：${payload.message || '登录中...'}`);
    } else {
      setPlatformStatus(platformId, 'warning', '登录需手动');
      setStatus(`${name} 自动登录未完成：${payload.message || '请手动登录'}`);
    }
  }

  // ========== 状态显示 ==========
  function setPlatformStatus(platformId, type, text) {
    const el = document.getElementById(`status-${platformId}`);
    if (!el) return;

    // 记录当前显示状态，供超时等后续信号判断
    if (state.platformStatus[platformId]) {
      state.platformStatus[platformId].statusType = type;
    }

    const dotClass = {
      loading: 'qw-dot-loading',
      ready: 'qw-dot-ready',
      injecting: 'qw-dot-injecting',
      success: 'qw-dot-success',
      error: 'qw-dot-error',
      warning: 'qw-dot-warning',
      answering: 'qw-dot-answering'
    }[type] || 'qw-dot-loading';

    el.innerHTML = `<span class="qw-dot ${dotClass}"></span>${escapeHtml(text)}`;
    // 错误状态下，点击状态条可快速重发上一条
    el.classList.toggle('error-clickable', type === 'error');
  }

  function setStatus(text) {
    const statusText = dom.statusBar.querySelector('.qw-status-text');
    if (statusText) statusText.textContent = text;
  }

  function escapeHtml(s) {
    const div = document.createElement('div');
    div.textContent = String(s == null ? '' : s);
    return div.innerHTML;
  }

  // ========== 设置面板 ==========
  function renderSettingsPlatforms() {
    dom.settingsPlatforms.innerHTML = '';

    // 全选/取消全选
    const selectAllRow = document.createElement('label');
    selectAllRow.className = 'qw-select-all-row';
    const selectAllCheckbox = document.createElement('input');
    selectAllCheckbox.type = 'checkbox';
    selectAllCheckbox.checked = state.enabledPlatforms.length === state.platforms.length;
    selectAllCheckbox.indeterminate = state.enabledPlatforms.length > 0 && state.enabledPlatforms.length < state.platforms.length;
    selectAllCheckbox.addEventListener('change', (e) => {
      if (e.target.checked) {
        state.platforms.forEach(p => {
          if (!state.enabledPlatforms.some(ep => ep.id === p.id)) {
            state.enabledPlatforms.push(p);
          }
        });
      } else {
        state.enabledPlatforms = [];
      }
      state.visiblePlatforms.clear();
      state.enabledPlatforms.forEach(p => state.visiblePlatforms.add(p.id));
      renderTabs();
      renderIframes();
      renderSettingsPlatforms();
      saveSettings();
    });
    const selectAllLabel = document.createElement('span');
    selectAllLabel.textContent = '全选/取消全选';
    selectAllRow.appendChild(selectAllCheckbox);
    selectAllRow.appendChild(selectAllLabel);
    dom.settingsPlatforms.appendChild(selectAllRow);

    // 按分类分组（兜底：非国际的一律归国内，保证自定义平台一定能显示）
    const global = state.platforms.filter(p => p.category === 'global');
    const globalIds = new Set(global.map(p => p.id));
    const domestic = state.platforms.filter(p => !globalIds.has(p.id));

    // 渲染分组（国内/国际）
    if (domestic.length > 0) {
      dom.settingsPlatforms.appendChild(createCategoryHeader('国内平台', domestic));
    }
    domestic.forEach((platform) => {
      const globalIndex = state.platforms.indexOf(platform);
      dom.settingsPlatforms.appendChild(createPlatformItem(platform, globalIndex));
    });

    if (global.length > 0) {
      dom.settingsPlatforms.appendChild(createCategoryHeader('国际平台', global));
    }
    global.forEach((platform) => {
      const globalIndex = state.platforms.indexOf(platform);
      dom.settingsPlatforms.appendChild(createPlatformItem(platform, globalIndex));
    });
  }

  // 创建分类标题
  function createCategoryHeader(title, platforms) {
    const header = document.createElement('div');
    header.className = 'qw-category-header';
    header.style.gridColumn = '1 / -1';

    const titleSpan = document.createElement('span');
    titleSpan.textContent = title;

    const countSpan = document.createElement('span');
    countSpan.className = 'qw-category-count';
    const enabledCount = platforms.filter(p => state.enabledPlatforms.some(ep => ep.id === p.id)).length;
    countSpan.textContent = `${enabledCount}/${platforms.length}`;

    // 分类全选
    const catCheckbox = document.createElement('input');
    catCheckbox.type = 'checkbox';
    catCheckbox.checked = enabledCount === platforms.length;
    catCheckbox.indeterminate = enabledCount > 0 && enabledCount < platforms.length;
    catCheckbox.title = '全选/取消此分类';
    catCheckbox.addEventListener('change', (e) => {
      if (e.target.checked) {
        platforms.forEach(p => {
          if (!state.enabledPlatforms.some(ep => ep.id === p.id)) state.enabledPlatforms.push(p);
        });
      } else {
        const ids = platforms.map(p => p.id);
        state.enabledPlatforms = state.enabledPlatforms.filter(p => !ids.includes(p.id));
      }
      state.visiblePlatforms.clear();
      state.enabledPlatforms.forEach(p => state.visiblePlatforms.add(p.id));
      renderTabs();
      renderIframes();
      renderSettingsPlatforms();
      saveSettings();
    });

    header.appendChild(titleSpan);
    header.appendChild(countSpan);
    header.appendChild(catCheckbox);
    return header;
  }

  // 创建单个平台项
  function createPlatformItem(platform, index) {
    const isCustom = Configs.isCustomPlatform(platform.id);
    const isBuiltin = Configs.isBuiltinPlatform ? Configs.isBuiltinPlatform(platform.id) : !isCustom;
    const isOverridden = isCustom && isBuiltin; // 编辑过的内置平台
    const item = document.createElement('div');
    item.className = 'qw-platform-item';
    item.draggable = true;
    item.dataset.index = index;
    item.title = platform.name + (isOverridden ? '（已自定义覆盖，可恢复默认）' : isBuiltin ? '（内置，可编辑覆盖）' : '（自定义，可拖拽排序）');

    const info = document.createElement('div');
    info.className = 'qw-platform-item-info';

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = state.enabledPlatforms.some(p => p.id === platform.id);
    checkbox.dataset.platformId = platform.id;
    checkbox.addEventListener('change', (e) => togglePlatform(platform.id, e.target.checked));

    const name = document.createElement('span');
    name.className = 'qw-platform-item-name';
    name.textContent = platform.name;

    info.appendChild(checkbox);
    info.appendChild(name);

    const dragHandle = document.createElement('div');
    dragHandle.className = 'qw-drag-handle';
    dragHandle.innerHTML = '⋮';
    dragHandle.title = '拖拽排序';
    dragHandle.style.fontSize = '12px';
    dragHandle.style.padding = '0';

    const actions = document.createElement('div');
    actions.className = 'qw-platform-item-actions';

    // 所有平台都可编辑（内置平台编辑后变为自定义覆盖）
    const editBtn = document.createElement('button');
    editBtn.className = 'qw-platform-item-btn';
    editBtn.title = '编辑';
    editBtn.innerHTML = '✎';
    editBtn.addEventListener('click', (e) => { e.stopPropagation(); openEditForm(platform.id); });
    actions.appendChild(editBtn);

    if (isOverridden) {
      // 编辑过的内置平台：提供"恢复默认"
      const resetBtn = document.createElement('button');
      resetBtn.className = 'qw-platform-item-btn reset';
      resetBtn.title = '恢复内置默认配置';
      resetBtn.innerHTML = '↺';
      resetBtn.addEventListener('click', (e) => { e.stopPropagation(); resetPlatform(platform.id); });
      actions.appendChild(resetBtn);
    } else if (!isBuiltin) {
      // 纯新增自定义平台：可彻底删除
      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'qw-platform-item-btn delete';
      deleteBtn.title = '删除';
      deleteBtn.innerHTML = '✕';
      deleteBtn.addEventListener('click', (e) => { e.stopPropagation(); deletePlatform(platform.id); });
      actions.appendChild(deleteBtn);
    }

    item.appendChild(info);
    item.appendChild(dragHandle);
    item.appendChild(actions);

    item.addEventListener('dragstart', (e) => {
      state.dragIndex = index;
      item.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
    });

    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      state.dragIndex = null;
    });

    item.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
    });

    item.addEventListener('drop', (e) => {
      e.preventDefault();
      if (state.dragIndex === null || state.dragIndex === index) return;
      reorderPlatforms(state.dragIndex, index);
    });

    return item;
  }

  // 重新排序平台
  function reorderPlatforms(fromIndex, toIndex) {
    const platforms = [...state.platforms];
    const [moved] = platforms.splice(fromIndex, 1);
    platforms.splice(toIndex, 0, moved);
    state.platforms = platforms;

    // 同步更新 enabledPlatforms 的顺序
    const enabledIds = state.enabledPlatforms.map(p => p.id);
    state.enabledPlatforms = platforms.filter(p => enabledIds.includes(p.id));

    renderSettingsPlatforms();
    renderTabs();
    renderIframes();
    saveSettings();
  }

  // 主界面卡片拖拽排序：只重排 DOM，不刷新 iframe（保留对话状态）
  function reorderCardsLightweight(draggedId, targetId) {
    const fromIdx = state.platforms.findIndex(p => p.id === draggedId);
    const toIdx = state.platforms.findIndex(p => p.id === targetId);
    if (fromIdx < 0 || toIdx < 0 || fromIdx === toIdx) return;

    // 更新数据顺序
    const platforms = [...state.platforms];
    const [moved] = platforms.splice(fromIdx, 1);
    platforms.splice(toIdx, 0, moved);
    state.platforms = platforms;
    const enabledIds = state.enabledPlatforms.map(p => p.id);
    state.enabledPlatforms = platforms.filter(p => enabledIds.includes(p.id));

    // 重排 DOM 卡片（移动现有元素，不重建 iframe）
    const grid = dom.grid;
    const cards = Array.from(grid.querySelectorAll('.qw-iframe-card'));
    const draggedCard = cards.find(c => c.dataset.platformId === draggedId);
    const targetCard = cards.find(c => c.dataset.platformId === targetId);
    if (draggedCard && targetCard && grid) {
      // 根据方向决定插入位置
      if (fromIdx < toIdx) {
        targetCard.after(draggedCard);
      } else {
        targetCard.before(draggedCard);
      }
    }

    // 更新卡片上的索引数据
    grid.querySelectorAll('.qw-iframe-card').forEach((card, i) => {
      const pid = card.dataset.platformId;
      const idx = state.platforms.findIndex(p => p.id === pid);
      card.dataset.platformIndex = idx;
    });

    // 重排顶部标签（轻量，无 iframe）
    renderTabs();
    saveSettings();
    setStatus(`已将「${moved.name}」移动到第 ${toIdx + 1} 位`);
  }

  // ========== 分组管理 ==========
  async function loadGroups() {
    try {
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(['duodaGroups'], resolve);
      });
      state.groups = result.duodaGroups || [];
      renderGroups();
    } catch (e) {
      console.error('[Duoda] Load groups error:', e);
      state.groups = [];
    }
  }

  async function saveGroupsToStorage() {
    try {
      await new Promise((resolve) => {
        chrome.storage.local.set({ duodaGroups: state.groups }, resolve);
      });
    } catch (e) {
      console.error('[Duoda] Save groups error:', e);
    }
  }

  function renderGroups() {
    if (!dom.groupsList) return;
    dom.groupsList.innerHTML = '';

    if (state.groups.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'qw-groups-empty';
      empty.textContent = '暂无分组，调整平台顺序和启用状态后点击"保存当前为分组"';
      dom.groupsList.appendChild(empty);
      return;
    }

    state.groups.forEach((group, index) => {
      const item = document.createElement('div');
      item.className = 'qw-group-item';

      const info = document.createElement('div');
      info.className = 'qw-group-item-info';

      const name = document.createElement('span');
      name.className = 'qw-group-item-name';
      name.textContent = group.name;
      name.title = `包含 ${group.platforms.length} 个平台`;

      const count = document.createElement('span');
      count.className = 'qw-group-item-count';
      count.textContent = `${group.platforms.length}个平台`;

      info.appendChild(name);
      info.appendChild(count);

      const actions = document.createElement('div');
      actions.className = 'qw-group-item-actions';

      const applyBtn = document.createElement('button');
      applyBtn.className = 'qw-group-item-btn apply';
      applyBtn.textContent = '应用';
      applyBtn.title = '应用此分组';
      applyBtn.addEventListener('click', () => applyGroup(group.id));

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'qw-group-item-btn delete';
      deleteBtn.textContent = '删除';
      deleteBtn.title = '删除此分组';
      deleteBtn.addEventListener('click', () => deleteGroup(group.id));

      actions.appendChild(applyBtn);
      actions.appendChild(deleteBtn);

      item.appendChild(info);
      item.appendChild(actions);
      dom.groupsList.appendChild(item);
    });
  }

  function handleSaveGroup() {
    // 免费版最多 2 个分组
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.isPro() && state.groups.length >= 2) {
      showProGate('无限制分组管理');
      return;
    }
    const name = prompt('请输入分组名称：', `分组 ${state.groups.length + 1}`);
    if (!name || !name.trim()) return;

    const group = {
      id: 'group_' + Date.now(),
      name: name.trim(),
      platforms: state.enabledPlatforms.map(p => p.id),
      order: state.platforms.map(p => p.id),
      createdAt: Date.now()
    };

    state.groups.push(group);
    saveGroupsToStorage();
    renderGroups();
    setStatus(`已保存分组：${group.name}`);
  }

  function applyGroup(groupId) {
    const group = state.groups.find(g => g.id === groupId);
    if (!group) return;

    // 恢复平台顺序
    if (group.order && group.order.length > 0) {
      const ordered = [];
      const remaining = [];
      group.order.forEach(id => {
        const p = state.platforms.find(pl => pl.id === id);
        if (p) ordered.push(p);
      });
      state.platforms.forEach(p => {
        if (!group.order.includes(p.id)) remaining.push(p);
      });
      state.platforms = [...ordered, ...remaining];
    }

    // 恢复启用状态
    state.enabledPlatforms = state.platforms.filter(p => group.platforms.includes(p.id));

    // 重置可见平台
    state.visiblePlatforms.clear();
    state.enabledPlatforms.forEach(p => state.visiblePlatforms.add(p.id));

    // 重新初始化平台状态
    state.platformStatus = {};
    state.enabledPlatforms.forEach(p => {
      state.platformStatus[p.id] = {
        ready: false,
        loggedIn: null,
        injecting: false,
        lastResult: null
      };
    });

    renderTabs();
    renderIframes();
    renderSettingsPlatforms();
    saveSettings();
    closeSettings();
    setStatus(`已应用分组：${group.name}`);
  }

  function deleteGroup(groupId) {
    const group = state.groups.find(g => g.id === groupId);
    if (!group) return;

    if (!confirm(`确定删除分组"${group.name}"吗？`)) return;

    state.groups = state.groups.filter(g => g.id !== groupId);
    saveGroupsToStorage();
    renderGroups();
    setStatus(`已删除分组：${group.name}`);
  }

  // ========== 设置子菜单切换 ==========
  function switchSettingsTab(tabName) {
    // 切换左侧菜单高亮
    document.querySelectorAll('.qw-settings-nav').forEach(nav => {
      nav.classList.toggle('active', nav.dataset.tab === tabName);
    });
    // 切换右侧面板
    document.querySelectorAll('.qw-settings-pane').forEach(pane => {
      pane.classList.toggle('active', pane.dataset.pane === tabName);
    });
    if (tabName === 'prompts') renderPromptsManage();
  }

  // ========== 导入导出 ==========
  async function exportConfig() {
    try {
      // 导出前提醒：配置文件包含加密后的账号密码
      if (!confirm('导出的配置文件包含已加密的平台账号密码（AES-256加密），请妥善保管。\n\n确定导出吗？')) return;

      const result = await new Promise((resolve) => {
        chrome.storage.local.get(null, resolve);
      });

      // 导出全部提示词（内置 + 自定义），保证导出文件自包含
      const allPrompts = state.prompts && state.prompts.length > 0
        ? state.prompts
        : (result.duodaPrompts || []);

      const exportData = {
        version: '1.0.0',
        exportTime: new Date().toISOString(),
        customPlatforms: result.customPlatforms || [],
        duodaGroups: result.duodaGroups || [],
        duodaAccounts: result.duodaAccounts || {},
        duodaVaultMeta: result.duodaVaultMeta || null,
        duodaSelectorOverrides: result.duodaSelectorOverrides || {},
        duodaPrompts: allPrompts,
        duodaHistory: result.duodaHistory || [],
        userSettings: result.userSettings || {}
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `duoda-config-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setStatus('配置已导出');
    } catch (e) {
      alert('导出失败：' + e.message);
    }
  }

  function handleImportFile(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (ev) => {
      try {
        const data = JSON.parse(ev.target.result);

        if (!data.version) {
          alert('无效的配置文件');
          return;
        }

        if (!confirm('导入配置将覆盖当前的自定义平台、分组、提示词和设置，确定继续吗？')) return;

        const saveData = {};
        if (data.customPlatforms) saveData.customPlatforms = data.customPlatforms;
        if (data.duodaGroups) saveData.duodaGroups = data.duodaGroups;
        if (data.duodaAccounts) saveData.duodaAccounts = data.duodaAccounts;
        if (data.duodaVaultMeta) saveData.duodaVaultMeta = data.duodaVaultMeta;
        if (data.duodaSelectorOverrides) saveData.duodaSelectorOverrides = data.duodaSelectorOverrides;
        if (data.duodaPrompts) {
          // 导入时过滤掉内置提示词（避免与硬编码重复），只保存自定义提示词
          const customPrompts = (data.duodaPrompts || []).filter(p => !p.builtin);
          saveData.duodaPrompts = customPrompts;
        }
        if (data.duodaHistory) saveData.duodaHistory = data.duodaHistory;
        if (data.userSettings) saveData.userSettings = data.userSettings;

        await new Promise((resolve) => {
          chrome.storage.local.set(saveData, resolve);
        });

        alert('导入成功，即将刷新页面');
        location.reload();
      } catch (err) {
        alert('导入失败：配置文件格式错误 - ' + err.message);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  }

  async function resetConfig() {
    if (!confirm('确定恢复默认设置吗？这将清除所有自定义平台、分组和设置。')) return;
    await new Promise((resolve) => {
      chrome.storage.local.clear(resolve);
    });
    alert('已恢复默认设置，即将刷新页面');
    location.reload();
  }

  // ========== 账号管理（一键登录） ==========
  // 渲染安全锁（主密码）面板
  async function renderVault() {
    if (!dom.vaultPanel || typeof DuodaVault === 'undefined') return;
    dom.vaultPanel.innerHTML = '';
    const inited = await DuodaVault.isInitialized();
    const unlocked = DuodaVault.isUnlocked();

    const row = document.createElement('div');
    row.className = 'qw-vault-row';
    const status = document.createElement('span');

    if (!inited) {
      // 未设置主密码
      status.className = 'qw-vault-status lock';
      status.textContent = '尚未设置主密码，密码目前以明文保存（不推荐）';
      const p1 = document.createElement('input');
      p1.type = 'password'; p1.className = 'qw-vault-input'; p1.placeholder = '设置主密码（至少4位）';
      const p2 = document.createElement('input');
      p2.type = 'password'; p2.className = 'qw-vault-input'; p2.placeholder = '再次输入主密码';
      const btn = document.createElement('button');
      btn.className = 'qw-btn-save'; btn.textContent = '设置并加密已有密码';
      btn.addEventListener('click', async () => {
        if (!p1.value || p1.value.length < 4) { alert('主密码至少 4 位'); return; }
        if (p1.value !== p2.value) { alert('两次输入的主密码不一致'); return; }
        try {
          await DuodaVault.setupMaster(p1.value);
          await migratePlaintextAccounts(); // 立即把旧明文密码加密
          renderVault(); renderAccounts();
          setStatus('主密码已设置，账号密码已加密保存');
        } catch (e) { alert('设置失败：' + e.message); }
      });
      row.appendChild(status);
      const row2 = document.createElement('div'); row2.className = 'qw-vault-row';
      row2.appendChild(p1); row2.appendChild(p2); row2.appendChild(btn);
      dom.vaultPanel.appendChild(row); dom.vaultPanel.appendChild(row2);
      return;
    }

    if (!unlocked) {
      // 已设置但锁定
      status.className = 'qw-vault-status lock';
      status.textContent = '已加密 · 当前已锁定，自动登录前需解锁';
      const pwd = document.createElement('input');
      pwd.type = 'password'; pwd.className = 'qw-vault-input'; pwd.placeholder = '输入主密码解锁';
      const btn = document.createElement('button');
      btn.className = 'qw-btn-save'; btn.textContent = '解锁';
      const doUnlock = async () => {
        try {
          await DuodaVault.unlock(pwd.value);
          await migratePlaintextAccounts();
          renderVault(); renderAccounts();
          setStatus('保险库已解锁');
        } catch (e) { alert(e.message || '解锁失败'); }
      };
      btn.addEventListener('click', doUnlock);
      pwd.addEventListener('keydown', (e) => { if (e.key === 'Enter') doUnlock(); });
      row.appendChild(status);
      row.appendChild(pwd); row.appendChild(btn);
      dom.vaultPanel.appendChild(row);
      return;
    }

    // 已解锁
    status.className = 'qw-vault-status ok';
    status.textContent = '已解锁 ✓ 密码以密文保存，关闭页面后自动锁定';
    const lockBtn = document.createElement('button');
    lockBtn.className = 'qw-btn-cancel'; lockBtn.textContent = '立即锁定';
    lockBtn.addEventListener('click', () => {
      DuodaVault.lock(); renderVault(); renderAccounts(); setStatus('保险库已锁定');
    });
    const changeBtn = document.createElement('button');
    changeBtn.className = 'qw-btn-cancel'; changeBtn.textContent = '修改主密码';
    changeBtn.addEventListener('click', () => renderChangeMaster());
    row.appendChild(status); row.appendChild(lockBtn); row.appendChild(changeBtn);
    dom.vaultPanel.appendChild(row);
  }

  // 修改主密码：解密全部账号 → 设置新主密码 → 重新加密
  async function renderChangeMaster() {
    const wrap = document.createElement('div');
    wrap.className = 'qw-vault-row';
    const oldP = document.createElement('input'); oldP.type = 'password'; oldP.className = 'qw-vault-input'; oldP.placeholder = '当前主密码';
    const newP = document.createElement('input'); newP.type = 'password'; newP.className = 'qw-vault-input'; newP.placeholder = '新主密码（至少4位）';
    const newP2 = document.createElement('input'); newP2.type = 'password'; newP2.className = 'qw-vault-input'; newP2.placeholder = '确认新主密码';
    const ok = document.createElement('button'); ok.className = 'qw-btn-save'; ok.textContent = '确认修改';
    ok.addEventListener('click', async () => {
      if (!newP.value || newP.value.length < 4) { alert('新主密码至少 4 位'); return; }
      if (newP.value !== newP2.value) { alert('两次新密码不一致'); return; }
      try {
        // 先用当前内存密钥解出全部明文密码
        const plain = {};
        for (const id of Object.keys(state.accounts)) {
          const a = state.accounts[id];
          plain[id] = a.encPassword ? await DuodaVault.decryptText(a.encPassword) : '';
        }
        // 校验旧密码（重新 unlock 一次）
        await DuodaVault.unlock(oldP.value);
        await DuodaVault.setupMaster(newP.value);
        // 用新密钥重新加密
        for (const id of Object.keys(state.accounts)) {
          if (plain[id]) state.accounts[id].encPassword = await DuodaVault.encryptText(plain[id]);
        }
        await saveAccounts();
        renderVault();
        setStatus('主密码已修改');
      } catch (e) { alert('修改失败：' + (e.message || e)); }
    });
    wrap.appendChild(oldP); wrap.appendChild(newP); wrap.appendChild(newP2); wrap.appendChild(ok);
    dom.vaultPanel.appendChild(wrap);
  }

  // 把历史遗留的明文 password 字段迁移为加密的 encPassword
  async function migratePlaintextAccounts() {
    if (!DuodaVault.isUnlocked()) return;
    let changed = false;
    for (const id of Object.keys(state.accounts)) {
      const a = state.accounts[id];
      if (typeof a.password === 'string' && a.password) {
        a.encPassword = await DuodaVault.encryptText(a.password);
        delete a.password;
        changed = true;
      }
    }
    if (changed) await saveAccounts();
  }

  async function loadAccounts() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['duodaAccounts'], (result) => {
        state.accounts = result.duodaAccounts || {};
        resolve(state.accounts);
      });
    });
  }

  async function saveAccounts() {
    return new Promise((resolve) => {
      chrome.storage.local.set({ duodaAccounts: state.accounts }, resolve);
    });
  }

  function renderAccounts() {
    if (!dom.accountsList) return;
    dom.accountsList.innerHTML = '';

    state.platforms.forEach(platform => {
      const acc = state.accounts[platform.id] || {};
      const hasSecret = !!(acc.encPassword || acc.password);
      const saved = !!(acc.username && hasSecret);

      const item = document.createElement('div');
      item.className = 'qw-account-item';
      item.dataset.platformId = platform.id;

      // 头部：名称 + 状态 + 展开
      const head = document.createElement('div');
      head.className = 'qw-account-head';

      const name = document.createElement('span');
      name.className = 'qw-account-name';
      name.textContent = platform.name;

      const badge = document.createElement('span');
      badge.className = 'qw-account-badge' + (saved ? '' : ' empty');
      badge.textContent = saved ? '已保存' : '未设置';

      const toggle = document.createElement('span');
      toggle.className = 'qw-account-toggle';
      toggle.textContent = '编辑 ▾';

      head.appendChild(name);
      head.appendChild(badge);
      head.appendChild(toggle);

      // 主体：表单
      const body = document.createElement('div');
      body.className = 'qw-account-body';

      const userGroup = document.createElement('div');
      userGroup.className = 'qw-form-group';
      const userLabel = document.createElement('label');
      userLabel.textContent = '手机号 / 邮箱 / 账号';
      const userInput = document.createElement('input');
      userInput.type = 'text';
      userInput.placeholder = '登录账号';
      userInput.value = acc.username || '';
      userInput.autocomplete = 'off';
      userGroup.appendChild(userLabel);
      userGroup.appendChild(userInput);

      const passGroup = document.createElement('div');
      passGroup.className = 'qw-form-group';
      const passLabel = document.createElement('label');
      passLabel.textContent = '密码（仅短信验证码的平台留空即可）';
      const passInput = document.createElement('input');
      passInput.type = 'password';
      // 不回显已保存的密码（密文存储，无法也不应还原显示）
      passInput.placeholder = hasSecret ? '已加密保存，留空表示不修改' : '登录密码（设置主密码后加密保存）';
      passInput.value = '';
      passInput.autocomplete = 'new-password';
      passGroup.appendChild(passLabel);
      passGroup.appendChild(passInput);

      // 自动登录开关
      const autoRow = document.createElement('label');
      autoRow.className = 'qw-account-row';
      const autoCheck = document.createElement('input');
      autoCheck.type = 'checkbox';
      autoCheck.checked = acc.autoLogin !== false;
      autoRow.appendChild(autoCheck);
      autoRow.appendChild(document.createTextNode('打开平台时自动填充并登录'));

      // 操作按钮
      const actions = document.createElement('div');
      actions.className = 'qw-account-actions';

      const loginNowBtn = document.createElement('button');
      loginNowBtn.className = 'qw-btn-cancel';
      loginNowBtn.textContent = '立即登录';
      loginNowBtn.addEventListener('click', async () => {
        const ok = await persistAccount();
        if (ok) loginPlatform(platform.id);
      });

      const saveBtn = document.createElement('button');
      saveBtn.className = 'qw-btn-save';
      saveBtn.textContent = '保存';
      saveBtn.addEventListener('click', async () => {
        const ok = await persistAccount();
        if (ok) setStatus(`${platform.name} 账号已保存`);
      });

      const clearBtn = document.createElement('button');
      clearBtn.className = 'qw-btn-cancel';
      clearBtn.textContent = '清除';
      clearBtn.addEventListener('click', async () => {
        delete state.accounts[platform.id];
        await saveAccounts();
        renderAccounts();
      });

      actions.appendChild(clearBtn);
      actions.appendChild(loginNowBtn);
      actions.appendChild(saveBtn);

      body.appendChild(userGroup);
      body.appendChild(passGroup);
      body.appendChild(autoRow);
      body.appendChild(actions);

      const persistAccount = async () => {
        const username = userInput.value.trim();
        const newPassword = passInput.value; // 留空表示不修改已保存密码
        const existing = state.accounts[platform.id] || {};

        if (!username && !newPassword) {
          delete state.accounts[platform.id];
          await saveAccounts();
          badge.className = 'qw-account-badge empty';
          badge.textContent = '未设置';
          return true;
        }

        let encPassword = existing.encPassword || '';
        // 兼容尚未迁移的旧明文
        if (!encPassword && existing.password) encPassword = existing.password;

        if (newPassword) {
          const inited = typeof DuodaVault !== 'undefined' && await DuodaVault.isInitialized();
          if (!inited) {
            alert('请先在上方「安全锁」设置主密码，再保存登录密码（密码将加密存储，不再明文保存）。');
            return false;
          }
          if (!DuodaVault.isUnlocked()) {
            const unlocked = await ensureVaultUnlocked('保存登录密码前需要先解锁保险库');
            if (!unlocked) return false;
          }
          encPassword = await DuodaVault.encryptText(newPassword);
        }

        state.accounts[platform.id] = {
          username,
          encPassword,
          autoLogin: autoCheck.checked
        };
        delete state.accounts[platform.id].password; // 不允许残留明文
        await saveAccounts();
        passInput.value = '';
        const hasSecret = !!encPassword;
        badge.className = 'qw-account-badge' + ((username && hasSecret) ? '' : ' empty');
        badge.textContent = (username && hasSecret) ? '已保存' : (username ? '仅账号' : '未设置');
        return true;
      };

      head.addEventListener('click', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON') return;
        item.classList.toggle('open');
      });

      item.appendChild(head);
      item.appendChild(body);
      dom.accountsList.appendChild(item);
    });
  }

  // 弹出主密码输入框并就地解锁；成功 resolve(true)，取消 resolve(false)
  function promptVaultUnlock(reason) {
    return new Promise((resolve) => {
      const overlay = document.createElement('div');
      overlay.className = 'qw-summary-overlay open';
      overlay.innerHTML = `
        <div class="qw-summary-dialog" style="width:380px;">
          <div class="qw-summary-header"><span>🔒 解锁安全保险库</span></div>
          <div class="qw-summary-tip" style="white-space:normal;line-height:1.6;">
            ${reason || '该操作需要解密已保存的密码'}。请输入主密码，密钥仅保存在本次页面内存中，关闭页面即自动锁定。
          </div>
          <div style="padding:14px 18px 4px;">
            <input type="password" id="vault-unlock-pwd" placeholder="请输入主密码"
              style="width:100%;padding:9px 10px;font-size:13px;border:1px solid var(--border-color);border-radius:8px;box-sizing:border-box;background:var(--bg-primary);color:var(--text-primary);outline:none;"/>
            <div id="vault-unlock-err" style="color:#e5484d;font-size:12px;margin-top:8px;min-height:14px;"></div>
          </div>
          <div class="qw-summary-actions">
            <span></span>
            <div>
              <button class="qw-btn-cancel" data-act="cancel">取消</button>
              <button data-act="ok" style="padding:6px 16px;font-size:12px;border:none;border-radius:6px;background:var(--accent);color:#fff;cursor:pointer;">解锁</button>
            </div>
          </div>
        </div>`;
      document.body.appendChild(overlay);
      const input = overlay.querySelector('#vault-unlock-pwd');
      const err = overlay.querySelector('#vault-unlock-err');
      input.focus();
      const finish = (ok) => { overlay.remove(); resolve(ok); };
      overlay.querySelector('[data-act="cancel"]').onclick = () => finish(false);
      overlay.querySelector('[data-act="ok"]').onclick = async () => {
        const v = input.value;
        if (!v) { err.textContent = '请输入主密码'; return; }
        try {
          await DuodaVault.unlock(v);
          if (typeof renderVault === 'function') renderVault();
          finish(true);
        } catch (e) {
          err.textContent = '主密码错误，请重试';
          input.select();
        }
      };
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') overlay.querySelector('[data-act="ok"]').click();
        if (e.key === 'Escape') finish(false);
      });
    });
  }

  // 确保保险库可用：未设主密码/已解锁直接通过；已锁定则弹窗解锁。返回是否可用
  // 并发调用复用同一个解锁弹窗，避免多个平台同时就绪时弹多次
  let _vaultUnlockChain = null;
  async function ensureVaultUnlocked(reason) {
    if (typeof DuodaVault === 'undefined') return true;
    const inited = await DuodaVault.isInitialized();
    if (!inited || DuodaVault.isUnlocked()) return true;
    if (_vaultUnlockChain) return _vaultUnlockChain;
    _vaultUnlockChain = promptVaultUnlock(reason)
      .then(ok => ok)
      .finally(() => { _vaultUnlockChain = null; });
    return _vaultUnlockChain;
  }

  // 登录单个平台
  // auto=true 表示页面就绪后的自动登录：保险库锁定时不弹窗，只填账号（密码需用户手动或点一键登录）
  async function loginPlatform(platformId, auto) {
    const acc = state.accounts[platformId];
    if (!acc || !acc.username) {
      if (!auto) setStatus('该平台尚未保存账号');
      return;
    }
    let password = '';
    if (acc.encPassword) {
      if (auto) {
        // 自动登录：保险库未解锁则静默跳过密码解密，只填账号
        if (typeof DuodaVault === 'undefined' || !DuodaVault.isUnlocked()) {
          console.log('[Duoda] Auto login: vault locked, fill username only for', platformId);
        } else {
          try { password = await DuodaVault.decryptText(acc.encPassword); } catch (e) {}
        }
      } else {
        // 手动一键登录：保险库锁定时弹窗解锁
        const ok = await ensureVaultUnlocked('一键登录需要解密该平台已保存的密码');
        if (!ok) { setStatus('已取消：保险库未解锁，无法自动登录'); return; }
        try {
          password = await DuodaVault.decryptText(acc.encPassword);
        } catch (e) {
          setStatus('密码解密失败，请重新解锁');
          return;
        }
      }
    } else if (typeof acc.password === 'string') {
      password = acc.password; // 旧明文兼容
    }
    sendToIframe(platformId, {
      type: 'AUTO_LOGIN',
      account: { username: acc.username, password: password || '' }
    });
    if (!auto) setStatus('正在登录...');
  }

  // 一键登录所有已保存账号的平台
  async function loginAllPlatforms() {
    const saved = Object.keys(state.accounts).filter(id => {
      const a = state.accounts[id];
      return a && a.username && state.visiblePlatforms.has(id);
    });
    if (saved.length === 0) {
      setStatus('没有已保存账号的平台，请先在 设置→账号管理 中添加');
      return;
    }
    // 若任一平台存有加密密码，先统一解锁一次（避免逐个弹窗）
    const needUnlock = saved.some(id => state.accounts[id].encPassword);
    if (needUnlock) {
      const ok = await ensureVaultUnlocked('一键登录需要解密各平台已保存的密码');
      if (!ok) { setStatus('已取消：保险库未解锁'); return; }
    }
    saved.forEach(id => loginPlatform(id));
    setStatus(`正在为 ${saved.length} 个平台自动登录...`);
  }

  // ========== 会员中心 ==========
  function renderMembership() {
    if (!dom.msBadge) return;
    const s = DuodaMembership.getStatus();
    if (s.active) {
      dom.msBadge.textContent = '👑 会员版';
      dom.msBadge.classList.add('pro');
      dom.msName.textContent = s.name || '会员用户';
      const left = DuodaMembership.daysLeft();
      const expText = (s.exp === 0 || !s.exp) ? '永久有效' : `到期：${new Date(s.exp).toLocaleDateString('zh-CN')}（剩余 ${left} 天）`;
      dom.msMeta.textContent = expText;
      if (dom.btnMembershipDeactivate) dom.btnMembershipDeactivate.style.display = '';
    } else {
      dom.msBadge.textContent = '免费版';
      dom.msBadge.classList.remove('pro');
      dom.msName.textContent = '未激活会员';
      dom.msMeta.textContent = '升级会员，解锁全部功能';
      if (dom.btnMembershipDeactivate) dom.btnMembershipDeactivate.style.display = 'none';
    }
    if (dom.membershipMsg) dom.membershipMsg.textContent = '';

    // 非会员时，会员功能按钮加半透明标识
    const proEls = [dom.btnVoice, dom.btnAttach, dom.btnSummary, dom.btnExport];
    proEls.forEach(el => {
      if (el) el.classList.toggle('pro-locked', !s.active);
    });
  }

  async function handleMembershipActivate() {
    const raw = dom.membershipInput ? dom.membershipInput.value.trim() : '';
    if (!raw) { setMembershipMsg('请输入激活码'); return; }
    setMembershipMsg('正在验证激活码...');
    const r = await DuodaMembership.activate(raw);
    if (r.success) {
      if (dom.membershipInput) dom.membershipInput.value = '';
      renderMembership();
      updateUsageHint();
      // 注意：必须在 renderMembership() 之后设置，因为 renderMembership 会清空 membershipMsg
      setMembershipMsg('✅ 已激活成功，已解锁全部会员功能');
    } else {
      setMembershipMsg('❌ ' + (r.message || '激活失败'));
    }
  }

  async function handleMembershipDeactivate() {
    if (!confirm('确定取消激活吗？取消后将恢复免费版限制。')) return;
    await DuodaMembership.deactivate();
    renderMembership();
    updateUsageHint();
    setMembershipMsg('已取消激活，恢复免费版');
  }

  function setMembershipMsg(t) { if (dom.membershipMsg) dom.membershipMsg.textContent = t; }

  // 会员功能门槛：未解锁时弹引导，返回是否放行
  function requirePro(feature, featureName) {
    if (DuodaMembership.can(feature)) return true;
    showProGate(featureName || '该功能');
    return false;
  }

  // 会员引导弹窗
  function showProGate(featureName) {
    const overlay = document.createElement('div');
    overlay.className = 'qw-summary-overlay open';
    overlay.innerHTML = `
      <div class="qw-summary-dialog" style="width:440px;">
        <div class="qw-summary-header">
          <span class="qw-progate-title">👑 会员专属功能</span>
          <button class="qw-icon-btn" data-act="close">✕</button>
        </div>
        <div class="qw-summary-tip" style="white-space:normal;line-height:1.7;">
          「${featureName}」是会员专属功能。免费版每天最多 30 次提问、一次最多 3 个 AI 同时回答，会员版无限制，并解锁以下全部能力：
        </div>
        <div class="qw-progate-list">
          <div>✓ 无限制每日提问次数（免费版每天 30 次）</div>
          <div>✓ 无限制同时回答 AI 数量（免费版一次最多 3 个）</div>
          <div>✓ 一键总结（多 AI 回答汇总）</div>
          <div>✓ 对话导出 Markdown</div>
          <div>✓ 语音输入 / 文档文件上传</div>
          <div>✓ 更多分组、自定义平台、历史记录</div>
          <div>✓ 高级选择器热修</div>
        </div>
        <div class="qw-summary-actions">
          <button class="qw-btn-cancel" data-act="close">稍后再说</button>
          <button data-act="go" style="padding:6px 16px;font-size:12px;border:none;border-radius:6px;background:linear-gradient(135deg,#f5a623,#f7c948);color:#fff;cursor:pointer;font-weight:600;">去开通会员 👑</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.querySelectorAll('[data-act="close"]').forEach(b => b.onclick = close);
    overlay.querySelector('[data-act="go"]').onclick = () => {
      close();
      openSettings();
      switchSettingsTab('membership');
    };
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
  }

  // 使用情况提示（免费版显示今日提问次数+当前选中AI数，会员不显示）
  async function updateUsageHint() {
    if (typeof DuodaMembership === 'undefined' || DuodaMembership.isPro()) return;
    const max = DuodaMembership.getMaxConcurrent();
    const visible = state.enabledPlatforms.filter(p => state.visiblePlatforms.has(p.id)).length;
    const used = await DuodaMembership.getDailyQuestionsUsed();
    const limit = DuodaMembership.getFreeLimits().dailyQuestions;
    setStatus(`免费版：今日已提问 ${used}/${limit} 次，当前选中 ${visible}/${max} 个 AI（会员无限制）`);
  }

  // ========== 提示词 ==========
  const DEFAULT_PROMPTS = [
    // 工作类
    { id: 'p_work_1', category: 'work', title: '商务邮件助手', content: '帮我写一封专业的商务邮件，主题是：', builtin: true },
    { id: 'p_work_2', category: 'work', title: '工作汇报分析', content: '请帮我分析以下工作汇报的逻辑和不足之处，并给出改进建议：', builtin: true },
    { id: 'p_work_3', category: 'work', title: '项目计划制定', content: '帮我制定一个详细的项目计划，目标是：', builtin: true },
    { id: 'p_work_4', category: 'work', title: '职场建议', content: '请以职场专家的角度，针对以下问题给我实用建议：', builtin: true },
    // 学习类
    { id: 'p_study_1', category: 'study', title: '概念通俗解释', content: '请用通俗易懂的方式解释以下概念，并举一个生活中的例子：', builtin: true },
    { id: 'p_study_2', category: 'study', title: '练习题生成', content: '请围绕以下知识点出一道练习题，并给出详细答案和解析：', builtin: true },
    { id: 'p_study_3', category: 'study', title: '学习重点总结', content: '请帮我总结以下学习内容的核心重点和知识框架：', builtin: true },
    // 娱乐类
    { id: 'p_fun_1', category: 'fun', title: '故事创作', content: '给我讲一个有趣的故事，主题是：', builtin: true },
    { id: 'p_fun_2', category: 'fun', title: '影视音乐推荐', content: '根据我以下的心情和偏好，推荐几部适合的电影或音乐：', builtin: true },
    { id: 'p_fun_3', category: 'fun', title: '朋友圈文案', content: '帮我写一段幽默有趣的朋友圈文案，主题是：', builtin: true }
  ];
  const CAT_LABELS = { work: '💼 工作', study: '📚 学习', fun: '🎮 娱乐' };
  let promptPickerCat = 'all';
  let promptSearchKeyword = '';
  let editingPromptId = null;

  async function loadPrompts() {
    const result = await new Promise((resolve) => {
      chrome.storage.local.get(['duodaPrompts'], (r) => resolve(r));
    });
    const custom = result.duodaPrompts || [];
    state.prompts = [...DEFAULT_PROMPTS, ...custom];
  }
  async function saveCustomPrompts() {
    const custom = state.prompts.filter(p => !p.builtin);
    await new Promise((resolve) => {
      chrome.storage.local.set({ duodaPrompts: custom }, resolve);
    });
  }

  // 提示词选择面板
  function togglePromptsPanel() {
    if (!dom.promptsPanel) return;
    const show = dom.promptsPanel.style.display === 'none';
    dom.promptsPanel.style.display = show ? 'flex' : 'none';
    dom.btnPrompts.classList.toggle('active', show);
    if (show) {
      promptSearchKeyword = '';
      if (dom.promptsSearchInput) dom.promptsSearchInput.value = '';
      renderPromptPicker();
    }
  }
  function renderPromptPicker() {
    if (!dom.promptsList) return;
    dom.promptsList.innerHTML = '';
    const kw = (promptSearchKeyword || '').trim().toLowerCase();
    let list = promptPickerCat === 'all'
      ? state.prompts
      : state.prompts.filter(p => p.category === promptPickerCat);
    // 模糊搜索：匹配标题、内容、分类名
    if (kw) {
      list = list.filter(p => {
        const hay = (p.title + ' ' + p.content + ' ' + (CAT_LABELS[p.category] || p.category)).toLowerCase();
        return hay.includes(kw);
      });
    }
    if (list.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'qw-history-empty';
      empty.textContent = '该分类暂无提示词';
      empty.style.padding = '16px';
      empty.style.textAlign = 'center';
      empty.style.color = 'var(--text-tertiary)';
      dom.promptsList.appendChild(empty);
      return;
    }
    list.forEach(p => {
      const item = document.createElement('div');
      item.className = 'qw-prompt-item';
      item.innerHTML = `
        <div class="qw-prompt-item-title">
          <span class="qw-prompt-item-cat">${CAT_LABELS[p.category] || p.category}</span>${p.title}
        </div>
        <div class="qw-prompt-item-content">${escapeHtml(p.content)}</div>`;
      item.addEventListener('click', () => {
        // 追加到输入框末尾
        const cur = dom.input.value || '';
        dom.input.value = cur ? (cur.trimEnd() + '\n' + p.content) : p.content;
        dom.input.focus();
        // 光标定位到提示词最后一个字符之后
        const len = dom.input.value.length;
        dom.input.selectionStart = dom.input.selectionEnd = len;
        autoResizeInput();
        togglePromptsPanel();
        setStatus(`已填入提示词：${p.title}`);
      });
      dom.promptsList.appendChild(item);
    });
  }

  // 设置里的提示词管理列表
  function renderPromptsManage() {
    if (!dom.promptsManageList) return;
    dom.promptsManageList.innerHTML = '';
    const customCount = state.prompts.filter(p => !p.builtin).length;
    const max = DuodaMembership.getMaxCustomPrompts();
    if (dom.promptsLimitHint) {
      dom.promptsLimitHint.textContent = `内置 ${DEFAULT_PROMPTS.length} 个常用提示词，已自定义 ${customCount}/${max} 个（${DuodaMembership.isPro() ? '会员版' : '免费版'}）。`;
    }
    state.prompts.forEach(p => {
      const item = document.createElement('div');
      item.className = 'qw-prompt-manage-item' + (p.builtin ? ' builtin' : '');
      item.innerHTML = `
        <div class="info">
          <div class="title"><span class="qw-prompt-item-cat">${CAT_LABELS[p.category] || p.category}</span>${escapeHtml(p.title)}</div>
          <div class="content">${escapeHtml(p.content)}</div>
        </div>
        <div class="actions">
          <button class="edit">编辑</button>
          ${p.builtin ? '' : '<button class="del">删除</button>'}
        </div>`;
      item.querySelector('.edit').addEventListener('click', () => openPromptForm(p));
      const delBtn = item.querySelector('.del');
      if (delBtn) delBtn.addEventListener('click', () => deletePrompt(p.id));
      dom.promptsManageList.appendChild(item);
    });
  }

  function openPromptForm(prompt) {
    editingPromptId = prompt ? prompt.id : null;
    dom.promptFormTitle.textContent = prompt ? '编辑提示词' : '添加提示词';
    dom.promptCategory.value = prompt ? prompt.category : 'work';
    dom.promptTitleInput.value = prompt ? prompt.title : '';
    dom.promptContentInput.value = prompt ? prompt.content : '';
    dom.promptForm.style.display = 'block';
    dom.promptForm.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  function closePromptForm() {
    editingPromptId = null;
    dom.promptForm.style.display = 'none';
  }

  async function savePrompt() {
    const category = dom.promptCategory.value;
    const title = dom.promptTitleInput.value.trim();
    const content = dom.promptContentInput.value.trim();
    if (!title || !content) { alert('请填写标题和内容'); return; }

    if (editingPromptId) {
      // 编辑
      const idx = state.prompts.findIndex(p => p.id === editingPromptId);
      if (idx >= 0) {
        state.prompts[idx] = { ...state.prompts[idx], category, title, content };
      }
    } else {
      // 新增：检查数量限制
      const customCount = state.prompts.filter(p => !p.builtin).length;
      const max = DuodaMembership.getMaxCustomPrompts();
      if (customCount >= max) {
        showProGate('自定义提示词（免费版最多3个，会员版最多200个）');
        return;
      }
      state.prompts.push({
        id: 'p_custom_' + Date.now(),
        category, title, content, builtin: false
      });
    }
    await saveCustomPrompts();
    renderPromptsManage();
    closePromptForm();
    setStatus(editingPromptId ? '提示词已更新' : '提示词已添加');
  }

  async function deletePrompt(id) {
    const p = state.prompts.find(x => x.id === id);
    if (!p || p.builtin) return;
    if (!confirm(`确定删除提示词「${p.title}」吗？`)) return;
    state.prompts = state.prompts.filter(x => x.id !== id);
    await saveCustomPrompts();
    renderPromptsManage();
    setStatus('提示词已删除');
  }

  // ========== 单侧重试 / 运行诊断 ==========
  // 向单个 AI 重发上一条问题（也可指定文本）
  async function retryPlatform(platformId, textOverride) {
    const platform = state.enabledPlatforms.find(p => p.id === platformId);
    if (!platform) { setStatus('该平台未启用'); return; }
    if (!state.visiblePlatforms.has(platformId)) state.visiblePlatforms.add(platformId);

    const text = (textOverride != null ? textOverride : state.lastQuestions[platformId])
      || (dom.input && dom.input.value.trim()) || '';
    if (!text) { setStatus(`${platform.name} 没有可重发的问题`); return; }

    // 免费版：重发也计入每日提问次数
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.isPro()) {
      const remaining = await DuodaMembership.getDailyQuestionsRemaining();
      if (remaining < 1) {
        setStatus('今日免费提问次数已用完，升级会员无限制');
        showProGate('无限制每日提问次数');
        return;
      }
      await DuodaMembership.recordQuestion();
      updateUsageHint();
    }

    state.lastQuestions[platformId] = text;
    const st = state.platformStatus[platformId] || (state.platformStatus[platformId] = {});
    st.injecting = true;
    st.lastError = null;
    setPlatformStatus(platformId, 'injecting', '正在问...');

    const sendId = Utils.generateId('retry');
    sendToIframe(platformId, {
      type: 'INJECT_AND_SEND',
      text,
      sendId,
      files: state.attachments
    });
    setStatus(`正在向 ${platform.name} 重发...`);
  }

  function formatClock(ts) {
    if (!ts) return '—';
    const d = new Date(ts);
    const pad = n => String(n).padStart(2, '0');
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  function openDiagnoseDialog() {
    dom.diagnoseOverlay.classList.add('open');
    renderDiagnose();
  }
  function closeDiagnoseDialog() {
    dom.diagnoseOverlay.classList.remove('open');
  }

  function renderDiagnose() {
    dom.diagnoseList.innerHTML = '';
    const list = state.enabledPlatforms;
    if (list.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'qw-history-empty';
      empty.textContent = '当前没有启用的 AI 平台';
      dom.diagnoseList.appendChild(empty);
      return;
    }

    list.forEach(p => {
      const st = state.platformStatus[p.id] || {};
      const item = document.createElement('div');
      item.className = 'qw-diag-item';

      const head = document.createElement('div');
      head.className = 'qw-diag-head';
      const name = document.createElement('span');
      name.className = 'qw-diag-name';
      name.textContent = p.name;

      const badge = document.createElement('span');
      let badgeText, badgeCls;
      if (st.injecting) { badgeText = '发送中'; badgeCls = 'run'; }
      else if (st.lastError) { badgeText = '失败'; badgeCls = 'err'; }
      else if (st.lastSuccessAt) { badgeText = '正常'; badgeCls = 'ok'; }
      else { badgeText = '未发送'; badgeCls = 'idle'; }
      badge.className = 'qw-diag-badge ' + badgeCls;
      badge.textContent = badgeText;

      const actions = document.createElement('div');
      actions.className = 'qw-diag-actions';
      const retryBtn = document.createElement('button');
      retryBtn.textContent = '重发';
      retryBtn.title = '重发上一条问题';
      retryBtn.addEventListener('click', () => retryPlatform(p.id));
      const reloadBtn = document.createElement('button');
      reloadBtn.textContent = '刷新页面';
      reloadBtn.addEventListener('click', () => reloadIframe(p.id));
      actions.appendChild(retryBtn);
      actions.appendChild(reloadBtn);

      head.appendChild(name);
      head.appendChild(badge);
      head.appendChild(actions);

      const meta = document.createElement('div');
      meta.className = 'qw-diag-meta';
      const lines = [];
      lines.push(`最近成功：${formatClock(st.lastSuccessAt)}`);
      lines.push(`累计发送：${st.sendCount || 0} 次，失败：${st.failCount || 0} 次`);
      if (st.lastError) lines.push(`最近错误：${st.lastError}（${formatClock(st.lastErrorAt)}）`);
      if (st.lastQuestion) lines.push(`上一条问题：${st.lastQuestion.length > 60 ? st.lastQuestion.slice(0, 60) + '…' : st.lastQuestion}`);
      meta.textContent = lines.join('　｜　');

      item.appendChild(head);
      item.appendChild(meta);
      dom.diagnoseList.appendChild(item);
    });
  }

  function retryAllPlatforms() {
    const targets = state.enabledPlatforms.filter(p => state.visiblePlatforms.has(p.id) && state.lastQuestions[p.id]);
    if (targets.length === 0) { setStatus('没有可重发的问题'); return; }
    targets.forEach(p => retryPlatform(p.id));
    setStatus(`已向 ${targets.length} 个 AI 重发上一条问题`);
  }

  // ========== 一键总结 ==========
  // 向所有可见平台请求回答文本，等待收集后弹出选择框
  async function openSummaryDialog() {
    // 免费版每天最多5次总结，会员无限制
    if (typeof DuodaMembership !== 'undefined') {
      const remaining = await DuodaMembership.getDailySummaryRemaining();
      if (remaining < 1) {
        showProGate('一键总结（今日免费次数已用完，会员无限制）');
        return;
      }
    }
    const visible = state.enabledPlatforms.filter(p => state.visiblePlatforms.has(p.id));
    if (visible.length === 0) {
      setStatus('当前没有可见的 AI 平台');
      return;
    }

    state.collectedAnswers = {};
    state.summarySelection.clear();
    dom.summaryOverlay.classList.add('open');
    // 显示今日剩余总结次数（会员无限制）
    let summaryTip = '正在收集各 AI 回答...';
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.isPro()) {
      const used = await DuodaMembership.getDailySummaryUsed();
      summaryTip = `正在收集各 AI 回答...（今日总结已用 ${used}/5 次）`;
    }
    dom.summaryTip.textContent = summaryTip;
    dom.summaryPlatforms.innerHTML = '';

    // 向每个可见 iframe 请求回答
    visible.forEach(p => {
      sendToIframe(p.id, { type: 'GET_ANSWER_TEXT' });
    });

    // 等待收集（最多2.5秒）
    await new Promise(r => setTimeout(r, 2500));

    renderSummaryPlatforms(visible);
  }

  function renderSummaryPlatforms(visible) {
    dom.summaryPlatforms.innerHTML = '';
    let withAnswer = 0;

    visible.forEach(p => {
      const text = state.collectedAnswers[p.id] || '';
      const has = text.length >= 10;
      if (has) withAnswer++;

      const label = document.createElement('label');
      label.className = 'qw-summary-platform' + (has ? '' : ' no-answer');

      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = has; // 有回答的默认选中
      cb.dataset.platformId = p.id;
      if (has) state.summarySelection.add(p.id);
      cb.addEventListener('change', () => {
        if (cb.checked) state.summarySelection.add(p.id);
        else state.summarySelection.delete(p.id);
      });

      const name = document.createElement('span');
      name.textContent = p.name + (has ? '' : '（无回答）');

      label.appendChild(cb);
      label.appendChild(name);
      dom.summaryPlatforms.appendChild(label);
    });

    dom.summaryTip.textContent = `已收集到 ${withAnswer}/${visible.length} 个 AI 的回答，勾选要用于总结的 AI`;
    if (dom.summarySelectAll) {
      dom.summarySelectAll.checked = withAnswer === visible.length;
      dom.summarySelectAll.indeterminate = withAnswer > 0 && withAnswer < visible.length;
    }
  }

  function closeSummaryDialog() {
    dom.summaryOverlay.classList.remove('open');
  }

  // 把收集到的回答组装成总结提示词，发送给选中的目标AI
  function confirmSummary() {
    const targetIds = Array.from(state.summarySelection);
    if (targetIds.length === 0) {
      setStatus('请至少选择一个 AI 进行总结');
      return;
    }

    // 组装各AI回答
    const parts = [];
    state.enabledPlatforms.forEach(p => {
      const text = state.collectedAnswers[p.id];
      if (text && text.length >= 10) {
        parts.push(`【${p.name}的回答】\n${text}`);
      }
    });

    if (parts.length === 0) {
      setStatus('没有收集到可用的回答，请先让 AI 回答后再总结');
      return;
    }

    const prompt = `下面是多个 AI 对同一个问题给出的回答。请你对比、整合这些回答，去重并取长补短，输出一份全面、准确、条理清晰的综合总结（分点呈现，最后给出你的结论或建议）：\n\n${parts.join('\n\n——————\n\n')}`;

    closeSummaryDialog();

    // 只发送给选中的目标AI
    const sendId = Utils.generateId('send');
    state.currentSendId = sendId;
    targetIds.forEach(id => {
      if (state.platformStatus[id]) {
        state.platformStatus[id].injecting = true;
        state.platformStatus[id].lastResult = null;
        setPlatformStatus(id, 'injecting', '正在总结...');
      }
      sendToIframe(id, {
        type: 'INJECT_AND_SEND',
        text: prompt,
        sendId: sendId + '-' + id, // 每个目标独立 sendId，避免被去重拦截
        files: []
      });
    });

    setStatus(`已让 ${targetIds.length} 个 AI 进行综合总结`);

    // 记录一次一键总结使用（免费版每天5次）
    if (typeof DuodaMembership !== 'undefined') {
      DuodaMembership.recordSummary().catch(() => {});
    }
  }

  // ========== 对话导出（Markdown） ==========
  function openExportDialog() {
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.can('exportChat')) {
      showProGate('对话导出 Markdown');
      return;
    }
    const visible = state.enabledPlatforms.filter(p => state.visiblePlatforms.has(p.id));
    if (visible.length === 0) {
      setStatus('当前没有可见的 AI 平台');
      return;
    }
    state.exportSelection = new Set(visible.map(p => p.id));
    state.collectedConversations = {};
    dom.exportOverlay.classList.add('open');
    dom.exportTip.textContent = '勾选要导出对话的 AI：';
    dom.exportPlatforms.innerHTML = '';

    visible.forEach(p => {
      const label = document.createElement('label');
      label.className = 'qw-summary-platform';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = true;
      cb.dataset.platformId = p.id;
      cb.addEventListener('change', () => {
        if (cb.checked) state.exportSelection.add(p.id);
        else state.exportSelection.delete(p.id);
      });
      const name = document.createElement('span');
      name.textContent = p.name;
      label.appendChild(cb);
      label.appendChild(name);
      dom.exportPlatforms.appendChild(label);
    });
    dom.exportSelectAll.checked = true;
    dom.exportSelectAll.indeterminate = false;
  }

  function closeExportDialog() {
    dom.exportOverlay.classList.remove('open');
  }

  // 向选中的 AI 请求完整对话，收集后组装 Markdown 并下载
  async function confirmExport() {
    const targetIds = Array.from(state.exportSelection);
    if (targetIds.length === 0) {
      setStatus('请至少选择一个 AI');
      return;
    }

    dom.exportTip.textContent = '正在收集各 AI 对话内容...';
    dom.btnExportConfirm.disabled = true;
    state.collectedConversations = {};

    targetIds.forEach(id => sendToIframe(id, { type: 'GET_CONVERSATION' }));
    // 等待回传
    await new Promise(r => setTimeout(r, 2500));

    const sections = [];
    let totalTurns = 0;
    targetIds.forEach(id => {
      const p = state.platforms.find(x => x.id === id);
      const name = p ? p.name : id;
      const turns = state.collectedConversations[id];
      if (!turns || turns.length === 0) return;
      totalTurns += turns.length;
      const lines = [`## ${name}`, ''];
      turns.forEach(t => {
        if (t.role === 'user') {
          lines.push('### 🙋 我的提问', '', t.content, '');
        } else {
          lines.push(`### 🤖 ${name}`, '', t.content, '');
        }
        lines.push('---', '');
      });
      sections.push(lines.join('\n'));
    });

    dom.btnExportConfirm.disabled = false;

    if (totalTurns === 0) {
      dom.exportTip.textContent = '暂未收集到对话内容，请先进行问答后再导出';
      setStatus('没有可导出的对话');
      return;
    }

    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
    const header = [
      '# 多答AI 对话导出',
      '',
      `- 导出时间：${now.toLocaleString()}`,
      `- 包含 AI：${targetIds.map(id => { const p = state.platforms.find(x => x.id === id); return p ? p.name : id; }).join('、')}`,
      `- 对话条数：${totalTurns}`,
      '',
      '---',
      ''
    ].join('\n');

    const markdown = header + '\n' + sections.join('\n');
    downloadMarkdown(`多答AI对话-${stamp}.md`, markdown);
    closeExportDialog();
    setStatus(`已导出 ${targetIds.length} 个 AI 的对话（${totalTurns} 条）`);
  }

  function downloadMarkdown(filename, content) {
    const blob = new Blob(['\ufeff' + content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 200);
  }

  // ========== 语音输入 ==========
  function getSpeechRecognitionCtor() {
    return window.SpeechRecognition || window.webkitSpeechRecognition || null;
  }

  function setVoiceBtnUI(listening) {
    if (!dom.btnVoice) return;
    dom.btnVoice.classList.toggle('recording', listening);
    const mic = dom.btnVoice.querySelector('.qw-icon-mic');
    const stop = dom.btnVoice.querySelector('.qw-icon-mic-stop');
    if (mic) mic.style.display = listening ? 'none' : '';
    if (stop) stop.style.display = listening ? '' : 'none';
    dom.btnVoice.title = listening ? '点击结束语音输入并填入文字' : '点击开始语音输入，再次点击结束并填入文字';
  }

  // 把 基础文本 + 已确定文本 + 临时文本 写回输入框
  function composeVoiceInput(interim) {
    let base = state.voiceBaseText || '';
    if (base && !/\s$/.test(base)) base += ' ';
    const final = state.voiceFinalText || '';
    dom.input.value = base + final + (interim || '');
    autoResizeInput();
  }

  function startVoiceInput() {
    const Ctor = getSpeechRecognitionCtor();
    if (!Ctor) {
      alert('当前浏览器不支持语音识别（需 Chrome，并允许使用麦克风与联网识别）');
      return;
    }

    let rec;
    try {
      rec = new Ctor();
    } catch (e) {
      alert('语音识别初始化失败：' + e.message);
      return;
    }
    rec.lang = 'zh-CN';
    rec.continuous = true;
    rec.interimResults = true;

    state.voiceBaseText = dom.input.value || '';
    state.voiceFinalText = '';
    state.voiceListening = true;
    state.recognition = rec;
    setVoiceBtnUI(true);
    setStatus('正在聆听，再次点击麦克风结束...');

    rec.onresult = (event) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) state.voiceFinalText += transcript;
        else interim += transcript;
      }
      composeVoiceInput(interim);
    };

    rec.onerror = (e) => {
      console.warn('[Duoda] Speech error:', e.error);
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        setStatus('麦克风权限被拒绝，请在浏览器设置中允许麦克风');
      } else if (e.error === 'network') {
        setStatus('语音识别需要联网，当前网络不可用');
      } else {
        setStatus('语音识别出错：' + e.error);
      }
      stopVoiceInput(true);
    };

    rec.onend = () => {
      // continuous 模式下 Chrome 有时会自动结束，若用户没主动停则自动续上
      if (state.voiceListening && state.recognition === rec) {
        try { rec.start(); return; } catch (e) { }
      }
      setVoiceBtnUI(false);
    };

    try {
      rec.start();
    } catch (e) {
      state.voiceListening = false;
      setVoiceBtnUI(false);
      alert('无法启动语音识别：' + e.message);
    }
  }

  function stopVoiceInput(silent) {
    state.voiceListening = false;
    const rec = state.recognition;
    if (rec) {
      try { rec.onend = null; rec.stop(); } catch (e) { }
      state.recognition = null;
    }
    setVoiceBtnUI(false);
    // 定稿：保留 基础+已确定文本
    let base = state.voiceBaseText || '';
    if (base && !/\s$/.test(base)) base += ' ';
    dom.input.value = (base + (state.voiceFinalText || '')).replace(/^\s+/, '');
    autoResizeInput();
    if (!silent) setStatus('语音输入已填入');
  }

  function toggleVoiceInput() {
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.can('voice')) {
      showProGate('语音输入');
      return;
    }
    if (state.voiceListening) stopVoiceInput(false);
    else startVoiceInput();
  }

  // ========== 新建对话 ==========
  function startNewChat() {
    const visible = state.enabledPlatforms.filter(p => state.visiblePlatforms.has(p.id));
    if (visible.length === 0) {
      setStatus('当前没有可见的 AI 平台');
      return;
    }
    state.currentConversation = null;
    visible.forEach(p => {
      const iframe = state.iframes[p.id];
      // 统一直接导航到平台入口（打开即新对话，最可靠）；同时通知页面尝试点“新对话”按钮
      if (iframe) {
        setPlatformStatus(p.id, 'loading', '开启新对话...');
        iframe.src = p.url;
      }
      delete state.iframeUrls[p.id];
    });
    // 清空输入框
    if (dom.input) dom.input.value = '';
    state.attachments = [];
    renderAttachments();
    autoResizeInput();
    setStatus(`已为 ${visible.length} 个 AI 开启新对话`);
  }

  // ========== 历史对话 ==========
  function loadHistory() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['duodaHistory'], (result) => {
        state.history = result.duodaHistory || [];
        resolve(state.history);
      });
    });
  }

  function saveHistory() {
    chrome.storage.local.set({ duodaHistory: state.history });
  }

  function formatTime(ts) {
    const d = new Date(ts);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getMonth() + 1}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  async function openHistoryDialog() {
    await loadHistory();
    state.historySearch = '';
    if (dom.historySearchInput) dom.historySearchInput.value = '';
    dom.historyOverlay.classList.add('open');
    renderHistory();
  }

  function closeHistoryDialog() {
    dom.historyOverlay.classList.remove('open');
  }

  function renderHistory() {
    dom.historyList.innerHTML = '';
    if (!state.history || state.history.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'qw-history-empty';
      empty.textContent = '暂无历史对话，发送问题后会自动记录';
      dom.historyList.appendChild(empty);
      return;
    }

    // 搜索过滤：匹配问题内容、标题、平台名
    const kw = (state.historySearch || '').trim().toLowerCase();
    const list = kw
      ? state.history.filter(r => {
        const hay = ((r.question || '') + ' ' + (r.title || '') + ' ' + (r.platformNames || []).join(' ')).toLowerCase();
        return hay.includes(kw);
      })
      : state.history;

    if (list.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'qw-history-empty';
      empty.textContent = `没有匹配「${state.historySearch}」的历史对话`;
      dom.historyList.appendChild(empty);
      return;
    }

    list.forEach(rec => {
      const item = document.createElement('div');
      item.className = 'qw-history-item';

      const title = document.createElement('div');
      title.className = 'qw-history-item-title';
      title.textContent = rec.title || '(无文本)';
      title.title = rec.question || '';

      const meta = document.createElement('div');
      meta.className = 'qw-history-item-meta';

      const left = document.createElement('div');
      left.className = 'qw-history-item-platforms';
      const time = document.createElement('span');
      time.textContent = formatTime(rec.createdAt);
      left.appendChild(time);
      (rec.platformNames || []).slice(0, 6).forEach(n => {
        const tag = document.createElement('span');
        tag.className = 'qw-history-tag';
        tag.textContent = n;
        left.appendChild(tag);
      });

      const del = document.createElement('button');
      del.className = 'qw-history-item-del';
      del.title = '删除该记录';
      del.textContent = '✕';
      del.addEventListener('click', (e) => {
        e.stopPropagation();
        deleteHistoryRecord(rec.id);
      });

      meta.appendChild(left);
      meta.appendChild(del);

      item.appendChild(title);
      item.appendChild(meta);
      item.addEventListener('click', () => loadHistoryRecord(rec));
      dom.historyList.appendChild(item);
    });
  }

  function deleteHistoryRecord(id) {
    state.history = state.history.filter(r => r.id !== id);
    saveHistory();
    renderHistory();
  }

  async function clearHistory() {
    if (!confirm('确定清空全部历史对话记录吗？')) return;
    state.history = [];
    saveHistory();
    renderHistory();
  }

  // 恢复一条历史：启用并显示当时的平台，把各 AI 定位到记录的会话 URL，找不到则开新对话
  function loadHistoryRecord(rec) {
    const ids = rec.platformIds || [];
    if (ids.length === 0) {
      setStatus('该记录没有可用的平台');
      return;
    }

    // 过滤出仍存在的有效平台，保持历史顺序
    const targetPlatforms = ids
      .map(id => Configs.getPlatformById(id))
      .filter(Boolean);
    if (targetPlatforms.length === 0) {
      setStatus('该记录中的 AI 平台均已不存在');
      return;
    }
    const targetIds = targetPlatforms.map(p => p.id);

    // 1. 先清空当前所有 AI（避免历史平台与当前对话平台叠加重复）
    state.enabledPlatforms = [];
    state.visiblePlatforms.clear();
    state.platformStatus = {};
    state.iframes = {};
    state.iframeReady = {};
    state.iframeUrls = {};

    // 2. 精确切换为历史记录里的平台集合（按历史顺序）
    targetPlatforms.forEach(p => {
      state.enabledPlatforms.push(p);
      state.visiblePlatforms.add(p.id);
      state.platformStatus[p.id] = { ready: false, loggedIn: null, injecting: false, lastResult: null };
    });
    saveSettings();

    // 3. 全量重建标签与 iframe（renderIframes 会先清空容器）
    renderTabs();
    renderIframes();
    if (typeof renderSettingsPlatforms === 'function') renderSettingsPlatforms();

    // 4. 逐个导航：有记录的会话 URL 则定位过去，否则用平台入口（新对话兜底）
    targetPlatforms.forEach(p => {
      const savedUrl = rec.urls && rec.urls[p.id];
      const target = savedUrl || p.url;
      const iframe = state.iframes[p.id];
      if (iframe && iframe.src !== target) {
        setPlatformStatus(p.id, 'loading', savedUrl ? '恢复历史会话...' : '未找到原会话，开启新对话...');
        iframe.src = target;
        if (savedUrl) state.iframeUrls[p.id] = savedUrl;
      }
    });

    // 5. 把当时的问题填回输入框，方便查看/追问（不自动发送）
    if (dom.input && rec.question) {
      dom.input.value = rec.question;
      autoResizeInput();
    }

    state.currentConversation = null;
    closeHistoryDialog();
    setStatus(`已切换到历史对话（${targetIds.length} 个 AI），缺失的会话已回退为新对话`);
  }

  // ========== 平台表单 ==========
  function openAddForm() {
    // 免费版最多 2 个自定义平台
    if (typeof DuodaMembership !== 'undefined' && !DuodaMembership.isPro()) {
      const customCount = state.platforms.filter(p => !(Configs.isBuiltinPlatform && Configs.isBuiltinPlatform(p.id))).length;
      if (customCount >= 2) {
        showProGate('自定义添加 AI 平台');
        return;
      }
    }
    editingPlatformId = null;
    dom.formTitle.textContent = '添加平台';
    dom.formName.value = '';
    dom.formUrl.value = '';
    dom.formCategory.value = 'domestic';
    dom.formInputSelector.value = "textarea, div[contenteditable='true'], input[type='text'], input[type='search'], input";
    dom.formTextMethod.value = 'insertText';
    dom.formSendMethod.value = 'enter';
    dom.formSendSelector.value = "button[type='submit'], button[class*='send']";
    if (dom.formSelectorsJson) {
      dom.formSelectorsJson.value = '';
      const grp = dom.formSelectorsJson.closest('.qw-form-group');
      if (grp) grp.style.display = (DuodaMembership && DuodaMembership.isPro()) ? '' : 'none';
    }
    dom.platformForm.style.display = 'block';
  }

  function openEditForm(platformId) {
    const platform = Configs.getPlatformById(platformId);
    if (!platform) return;

    editingPlatformId = platformId;
    dom.formTitle.textContent = '编辑平台: ' + platform.name;
    dom.formName.value = platform.name;
    dom.formUrl.value = platform.url;
    dom.formCategory.value = (platform.category === 'global') ? 'global' : 'domestic';
    dom.formInputSelector.value = platform.findInput ? platform.findInput.selector : '';
    dom.formTextMethod.value = platform.addText ? platform.addText.method : 'insertText';
    dom.formSendMethod.value = platform.send ? platform.send.method : 'enter';
    dom.formSendSelector.value = platform.send ? platform.send.buttonSelector : '';
    // 载入已保存的“选择器覆盖”原始片段（不是合并后的完整配置）
    if (dom.formSelectorsJson) {
      const frag = Configs.getSelectorOverride ? Configs.getSelectorOverride(platformId) : null;
      dom.formSelectorsJson.value = frag ? JSON.stringify(frag, null, 2) : '';
      // 非会员隐藏高级选择器区域
      const grp = dom.formSelectorsJson.closest('.qw-form-group');
      if (grp) grp.style.display = (DuodaMembership && DuodaMembership.isPro()) ? '' : 'none';
    }
    dom.platformForm.style.display = 'block';
  }

  function closeForm() {
    editingPlatformId = null;
    dom.platformForm.style.display = 'none';
  }

  async function saveForm() {
    const name = dom.formName.value.trim();
    const url = dom.formUrl.value.trim();
    const category = (dom.formCategory.value === 'global') ? 'global' : 'domestic';
    const inputSelector = dom.formInputSelector.value.trim();
    const textMethod = dom.formTextMethod.value;
    const sendMethod = dom.formSendMethod.value;
    const sendSelector = dom.formSendSelector.value.trim();

    // 验证
    if (!name) { alert('请输入平台名称'); return; }
    if (!url) { alert('请输入平台网址'); return; }

    let domain;
    try {
      domain = new URL(url).hostname;
    } catch (e) {
      alert('网址格式不正确');
      return;
    }

    // 解析高级选择器覆盖 JSON（会员专属）
    const rawJson = dom.formSelectorsJson ? dom.formSelectorsJson.value.trim() : '';
    if (rawJson && typeof DuodaMembership !== 'undefined' && !DuodaMembership.can('selectorOverride')) {
      showProGate('高级选择器热修');
      return;
    }
    let selectorFrag = null;
    if (rawJson) {
      try {
        selectorFrag = JSON.parse(rawJson);
        if (!selectorFrag || typeof selectorFrag !== 'object' || Array.isArray(selectorFrag)) {
          throw new Error('必须是 JSON 对象');
        }
      } catch (e) {
        alert('选择器覆盖 JSON 格式有误：' + e.message);
        return;
      }
    }

    try {
      let targetId = editingPlatformId;
      if (editingPlatformId) {
        const updates = {
          name,
          url,
          domain,
          category,
          findInput: { selector: inputSelector, waitTimeout: 20000, pollInterval: 300 },
          addText: { method: textMethod, focusFirst: true, clearBefore: true },
          send: { method: sendMethod, buttonSelector: sendSelector }
        };
        if (Configs.isBuiltinPlatform && Configs.isBuiltinPlatform(editingPlatformId)) {
          // 内置平台：保存为自定义覆盖（同 id 覆盖内置，可恢复默认）
          await Configs.overrideBuiltinPlatform(editingPlatformId, updates);
        } else {
          // 纯自定义平台：直接更新
          await Configs.updateCustomPlatform(editingPlatformId, updates);
        }
      } else {
        // 添加新平台
        const id = 'custom_' + Date.now();
        targetId = id;
        await Configs.addCustomPlatform({
          id,
          name,
          url,
          domain,
          category,
          inputSelector,
          textMethod,
          sendMethod,
          sendButtonSelector: sendSelector
        });

        // 默认启用新平台
        if (!state.enabledPlatforms.some(p => p.id === id)) {
          const newPlatform = Configs.getPlatformById(id);
          if (newPlatform) state.enabledPlatforms.push(newPlatform);
        }
        // 新增平台自动可见
        state.visiblePlatforms.add(id);
      }

      // 保存/清除“选择器覆盖层”（独立于整平台配置，改这里即可热修选择器）
      if (Configs.saveSelectorOverride) {
        if (selectorFrag) await Configs.saveSelectorOverride(targetId, selectorFrag);
        else await Configs.clearSelectorOverride(targetId);
      }

      // 刷新状态
      state.platforms = Configs.getAllPlatforms();
      saveSettings();

      // 重新渲染
      renderSettingsPlatforms();
      renderTabs();
      renderIframes();
      closeForm();
      setStatus(editingPlatformId ? '平台已更新' : '平台已添加');

    } catch (e) {
      alert('保存失败: ' + e.message);
    }
  }

  async function deletePlatform(platformId) {
    const platform = Configs.getPlatformById(platformId);
    if (!platform) return;

    if (!confirm(`确定要删除平台「${platform.name}」吗？`)) return;

    try {
      await Configs.deleteCustomPlatform(platformId);
      if (Configs.clearSelectorOverride) await Configs.clearSelectorOverride(platformId);

      // 从启用列表中移除
      state.enabledPlatforms = state.enabledPlatforms.filter(p => p.id !== platformId);
      delete state.platformStatus[platformId];
      delete state.iframes[platformId];
      delete state.iframeReady[platformId];

      // 刷新状态
      state.platforms = Configs.getAllPlatforms();
      saveSettings();

      // 重新渲染
      renderSettingsPlatforms();
      renderTabs();
      renderIframes();
      setStatus('平台已删除');

    } catch (e) {
      alert('删除失败: ' + e.message);
    }
  }

  // 恢复内置平台默认配置（移除自定义覆盖）
  async function resetPlatform(platformId) {
    const platform = Configs.getPlatformById(platformId);
    if (!platform) return;
    if (!confirm(`确定将「${platform.name}」恢复为内置默认配置吗？`)) return;
    try {
      await Configs.resetBuiltinPlatform(platformId);
      if (Configs.clearSelectorOverride) await Configs.clearSelectorOverride(platformId);
      state.platforms = Configs.getAllPlatforms();
      // 用恢复后的内置对象刷新启用列表引用
      const restored = Configs.getPlatformById(platformId);
      const idx = state.enabledPlatforms.findIndex(p => p.id === platformId);
      if (idx >= 0 && restored) state.enabledPlatforms[idx] = restored;
      saveSettings();
      renderSettingsPlatforms();
      renderTabs();
      renderIframes();
      setStatus('已恢复默认配置');
    } catch (e) {
      alert('恢复失败: ' + e.message);
    }
  }

  function togglePlatform(platformId, enabled) {
    const platform = state.platforms.find(p => p.id === platformId);
    if (!platform) return;

    if (enabled) {
      if (!state.enabledPlatforms.some(p => p.id === platformId)) {
        state.enabledPlatforms.push(platform);
        state.platformStatus[platformId] = { ready: false, loggedIn: null, injecting: false, lastResult: null };
      }
      // 启用即在主页自动选中可见，无需再手动点击
      state.visiblePlatforms.add(platformId);
    } else {
      state.enabledPlatforms = state.enabledPlatforms.filter(p => p.id !== platformId);
      state.visiblePlatforms.delete(platformId);
      delete state.platformStatus[platformId];
      delete state.iframes[platformId];
    }

    // 保存设置
    saveSettings();

    // 重新渲染
    renderTabs();
    renderIframes();
  }

  function applySettings() {
    if (dom.settingAutoSend) dom.settingAutoSend.checked = state.settings.autoSend;
    if (dom.settingDarkMode) dom.settingDarkMode.checked = state.settings.darkMode;
    if (dom.settingSendDelay) dom.settingSendDelay.value = state.settings.sendDelay || 200;
    applyTheme(false);
  }

  // 统一的深色模式切换（头部按钮与设置面板共用）
  function applyTheme(notifyIframes) {
    const dark = !!state.settings.darkMode;
    document.body.classList.toggle('dark', dark);

    // 头部图标：浅色显示月亮（可切到深色），深色显示太阳
    const moon = dom.btnTheme && dom.btnTheme.querySelector('.qw-icon-moon');
    const sun = dom.btnTheme && dom.btnTheme.querySelector('.qw-icon-sun');
    if (moon) moon.style.display = dark ? 'none' : '';
    if (sun) sun.style.display = dark ? '' : 'none';

    if (notifyIframes !== false) {
      state.enabledPlatforms.forEach(p => {
        sendToIframe(p.id, { type: 'APPLY_THEME', theme: dark ? 'dark' : 'light' });
      });
    }
  }

  function toggleDarkMode() {
    state.settings.darkMode = !state.settings.darkMode;
    applyTheme(true);
    saveSettings();
    if (dom.settingDarkMode) dom.settingDarkMode.checked = state.settings.darkMode;
  }

  function saveSettings() {
    const settings = {
      ...state.settings,
      enabledPlatforms: state.enabledPlatforms.map(p => p.id)
    };
    Configs.saveUserSettings(settings);
  }

  function openSettings() {
    dom.settingsDrawer.classList.add('open');
    dom.settingsOverlay.classList.add('open');
    renderGroups();
    loadAccounts().then(renderAccounts);
  }

  function closeSettings() {
    dom.settingsDrawer.classList.remove('open');
    dom.settingsOverlay.classList.remove('open');
  }

  // ========== 待发送消息检查 ==========
  async function checkPendingMessage() {
    try {
      const result = await new Promise((resolve) => {
        chrome.storage.local.get(['pendingMessage'], resolve);
      });

      if (result.pendingMessage && result.pendingMessage.text) {
        dom.input.value = result.pendingMessage.text;
        autoResizeInput();
        setStatus('已填入选中文本，点击发送');

        // 清除待发送消息
        chrome.storage.local.set({ pendingMessage: null });

        // 如果开启自动发送，延迟后自动发送
        if (state.settings.autoSend) {
          setTimeout(() => handleSend(), 500);
        }
      }
    } catch (e) {
      console.error('[Duoda Sidepanel] checkPendingMessage error:', e);
    }
  }

  // ========== 输入框自适应 ==========
  function autoResizeInput() {
    dom.input.style.height = 'auto';
    dom.input.style.height = Math.min(dom.input.scrollHeight, 120) + 'px';
  }

  // ========== 事件绑定 ==========
  function bindEvents() {
    // 辅助函数：仅在元素存在时绑定事件
    function on(el, event, handler) {
      if (el) el.addEventListener(event, handler);
      else console.warn('[Duoda Sidepanel] Element not found for event:', event);
    }

    // 窗口尺寸变化时重新计算布局（平分占满 / 横向滚动 自动切换）
    let resizeTimer = null;
    on(window, 'resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        updateGridLayout();
        updateTabsDragState();
      }, 120);
    });

    // 标签栏鼠标按住左右拖拽划动
    initTabsDragScroll();

    // 发送按钮
    on(dom.btnSend, 'click', handleSend);

    // 语音输入：点击开始，再次点击结束并填入
    on(dom.btnVoice, 'click', (e) => { e.preventDefault(); toggleVoiceInput(); });

    // 提示词选择面板
    on(dom.btnPrompts, 'click', (e) => { e.stopPropagation(); togglePromptsPanel(); });
    if (dom.promptsPanel) {
      dom.promptsPanel.querySelectorAll('.qw-prompts-tabs button').forEach(btn => {
        on(btn, 'click', () => {
          dom.promptsPanel.querySelectorAll('.qw-prompts-tabs button').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          promptPickerCat = btn.dataset.cat;
          renderPromptPicker();
        });
      });
      on(dom.promptsPanel, 'click', (e) => e.stopPropagation());
    }
    if (dom.promptsSearchInput) {
      on(dom.promptsSearchInput, 'input', (e) => {
        promptSearchKeyword = e.target.value;
        renderPromptPicker();
      });
      on(dom.promptsSearchInput, 'click', (e) => e.stopPropagation());
    }
    // 点击页面其他区域关闭提示词面板
    on(document, 'click', () => {
      if (dom.promptsPanel && dom.promptsPanel.style.display !== 'none') {
        dom.promptsPanel.style.display = 'none';
        dom.btnPrompts.classList.remove('active');
      }
    });

    // 提示词管理
    if (dom.btnAddPrompt) on(dom.btnAddPrompt, 'click', () => openPromptForm(null));
    if (dom.btnPromptCancel) on(dom.btnPromptCancel, 'click', closePromptForm);
    if (dom.btnPromptSave) on(dom.btnPromptSave, 'click', savePrompt);

    // 输入框回车发送
    on(dom.input, 'keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    });

    // 输入框自适应
    on(dom.input, 'input', autoResizeInput);

    // 附件按钮 - 打开文件选择
    on(dom.btnAttach, 'click', () => {
      if (dom.fileInput) dom.fileInput.click();
    });

    // 文件选择
    on(dom.fileInput, 'change', handleFileSelect);

    // 粘贴图片/文件（输入框和整个页面都支持）
    on(dom.input, 'paste', handlePaste);
    on(document, 'paste', (e) => {
      // 仅当焦点不在输入框时由 document 兜底，避免重复
      if (document.activeElement !== dom.input) handlePaste(e);
    });

    // 拖拽文件到输入区域
    const inputArea = document.querySelector('.qw-input-wrapper');
    if (inputArea) {
      on(inputArea, 'dragover', (e) => { e.preventDefault(); inputArea.classList.add('drag-over'); });
      on(inputArea, 'dragleave', () => inputArea.classList.remove('drag-over'));
      on(inputArea, 'drop', (e) => { inputArea.classList.remove('drag-over'); handleDrop(e); });
    }

    // 设置按钮
    on(dom.btnSettings, 'click', openSettings);
    on(dom.btnCloseSettings, 'click', closeSettings);
    on(dom.settingsOverlay, 'click', closeSettings);

    // 分组管理
    on(dom.btnSaveGroup, 'click', handleSaveGroup);

    // 设置子菜单切换
    document.querySelectorAll('.qw-settings-nav').forEach(nav => {
      on(nav, 'click', () => switchSettingsTab(nav.dataset.tab));
    });

    // 导入导出
    on(dom.btnExportConfig, 'click', exportConfig);
    on(dom.btnImportConfig, 'click', () => dom.importFileInput && dom.importFileInput.click());
    on(dom.importFileInput, 'change', handleImportFile);
    on(dom.btnResetConfig, 'click', resetConfig);

    // 一键登录
    on(dom.btnLoginAll, 'click', loginAllPlatforms);

    // 会员中心
    if (dom.btnMembershipActivate) on(dom.btnMembershipActivate, 'click', handleMembershipActivate);
    if (dom.btnMembershipDeactivate) on(dom.btnMembershipDeactivate, 'click', handleMembershipDeactivate);
    if (dom.membershipInput) on(dom.membershipInput, 'keydown', (e) => { if (e.key === 'Enter') handleMembershipActivate(); });

    // 运行诊断
    on(dom.btnDiagnose, 'click', openDiagnoseDialog);
    on(dom.btnDiagnoseClose, 'click', closeDiagnoseDialog);
    on(dom.btnDiagnoseCancel, 'click', closeDiagnoseDialog);
    on(dom.btnDiagnoseRetryAll, 'click', retryAllPlatforms);
    on(dom.diagnoseOverlay, 'click', (e) => {
      if (e.target === dom.diagnoseOverlay) closeDiagnoseDialog();
    });

    // 一键总结
    on(dom.btnSummary, 'click', openSummaryDialog);
    on(dom.btnSummaryClose, 'click', closeSummaryDialog);
    on(dom.btnSummaryCancel, 'click', closeSummaryDialog);
    on(dom.btnSummaryConfirm, 'click', confirmSummary);
    on(dom.summaryOverlay, 'click', (e) => {
      if (e.target === dom.summaryOverlay) closeSummaryDialog();
    });
    on(dom.summarySelectAll, 'change', (e) => {
      const checked = e.target.checked;
      dom.summaryPlatforms.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        const item = cb.closest('.qw-summary-platform');
        if (item && item.classList.contains('no-answer')) return; // 无回答的不选
        cb.checked = checked;
        const id = cb.dataset.platformId;
        if (checked) state.summarySelection.add(id);
        else state.summarySelection.delete(id);
      });
    });

    // 新建对话
    on(dom.btnNewChat, 'click', startNewChat);

    // 历史对话
    on(dom.btnHistory, 'click', openHistoryDialog);
    on(dom.btnHistoryClose, 'click', closeHistoryDialog);
    on(dom.btnHistoryCancel, 'click', closeHistoryDialog);
    on(dom.btnHistoryClear, 'click', clearHistory);
    if (dom.historySearchInput) on(dom.historySearchInput, 'input', (e) => {
      state.historySearch = e.target.value;
      renderHistory();
    });
    on(dom.historyOverlay, 'click', (e) => {
      if (e.target === dom.historyOverlay) closeHistoryDialog();
    });

    // 导出对话
    on(dom.btnExport, 'click', openExportDialog);
    on(dom.btnExportClose, 'click', closeExportDialog);
    on(dom.btnExportCancel, 'click', closeExportDialog);
    on(dom.btnExportConfirm, 'click', confirmExport);
    on(dom.exportOverlay, 'click', (e) => {
      if (e.target === dom.exportOverlay) closeExportDialog();
    });
    on(dom.exportSelectAll, 'change', (e) => {
      const checked = e.target.checked;
      dom.exportPlatforms.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        cb.checked = checked;
        const id = cb.dataset.platformId;
        if (checked) state.exportSelection.add(id);
        else state.exportSelection.delete(id);
      });
    });

    // 发送延迟设置
    on(dom.settingSendDelay, 'change', (e) => {
      state.settings.sendDelay = parseInt(e.target.value) || 200;
      saveSettings();
    });

    // 平台表单
    on(dom.btnAddPlatform, 'click', openAddForm);
    on(dom.btnFormCancel, 'click', closeForm);
    on(dom.btnFormSave, 'click', saveForm);
    // 填入当前有效配置作为修改模板
    on(dom.btnFillDefault, 'click', () => {
      let tpl = null;
      if (editingPlatformId) {
        const p = Configs.getPlatformById(editingPlatformId);
        if (p) {
          tpl = {};
          ['findInput', 'addText', 'addFile', 'send'].forEach(k => { if (p[k] !== undefined) tpl[k] = p[k]; });
        }
      } else {
        tpl = {
          findInput: { selector: dom.formInputSelector.value || "textarea, div[contenteditable='true']" },
          addText: { method: dom.formTextMethod.value },
          send: { method: dom.formSendMethod.value, buttonSelector: dom.formSendSelector.value }
        };
      }
      if (tpl && dom.formSelectorsJson) dom.formSelectorsJson.value = JSON.stringify(tpl, null, 2);
    });

    // 展开按钮 - 打开独立页面
    on(dom.btnExpand, 'click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('shared/src/html/index.html') });
    });

    // 设置项变化
    on(dom.settingAutoSend, 'change', (e) => {
      state.settings.autoSend = e.target.checked;
      saveSettings();
    });

    on(dom.settingDarkMode, 'change', (e) => {
      state.settings.darkMode = e.target.checked;
      applyTheme(true);
      saveSettings();
    });

    // 头部深色模式快捷切换
    on(dom.btnTheme, 'click', toggleDarkMode);

    // 监听 background 消息（右键菜单/快捷键触发的待发送消息）
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'PENDING_MESSAGE' && message.text && dom.input) {
        dom.input.value = message.text;
        autoResizeInput();
        setStatus('已填入文本，点击发送');
        if (state.settings.autoSend) {
          setTimeout(() => handleSend(), 500);
        }
      }
      sendResponse({ received: true });
      return true;
    });
  }

  // ========== 启动 ==========
  listenIframeMessages();
  init();
})();

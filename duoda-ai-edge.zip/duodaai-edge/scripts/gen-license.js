/**
 * 生成会员激活码（JWT-like，Ed25519 签名）
 * 用法：
 *   node scripts/gen-license.js --name "张三" --days 365
 *   node scripts/gen-license.js --name "张三" --days 30 --level pro
 *   node scripts/gen-license.js --name "张三" --permanent   (永久会员)
 *
 * 激活码格式：headerB64.payloadB64.signatureB64
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function arg(name, def) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : def;
}
const hasFlag = (name) => process.argv.includes('--' + name);

const privPath = path.join(__dirname, '..', 'keys', 'ed25519-private.key');
if (!fs.existsSync(privPath)) {
  console.error('未找到私钥，请先运行 node scripts/gen-keys.js');
  process.exit(1);
}
const privB64 = fs.readFileSync(privPath, 'utf8').trim();
const privateKey = crypto.createPrivateKey({
  key: Buffer.from(privB64, 'base64'),
  format: 'der',
  type: 'pkcs8'
});

const name = arg('name', 'VIP用户');
const level = arg('level', 'pro');
const now = Date.now();
let exp = 0;
if (hasFlag('permanent')) {
  exp = 0; // 0 表示永久
} else {
  const days = parseInt(arg('days', '365'), 10);
  exp = now + days * 86400000;
}
const device = arg('device', ''); // 可选绑定设备指纹，空则不绑定

const payload = {
  v: 1,
  lic: crypto.randomUUID(),
  name,
  level,
  exp,
  iat: now
};
if (device) payload.dev = device;

const header = { alg: 'EdDSA', typ: 'duoda-license' };
const hB64 = Buffer.from(JSON.stringify(header)).toString('base64url');
const pB64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
const data = hB64 + '.' + pB64;
const sig = crypto.sign(null, Buffer.from(data), privateKey).toString('base64url');
const license = data + '.' + sig;

console.log('=== 会员激活码（复制给用户）===');
console.log(license);
console.log('\n=== 信息 ===');
console.log('用户:', name);
console.log('等级:', level);
console.log('到期:', exp === 0 ? '永久' : new Date(exp).toLocaleString('zh-CN'));
console.log('设备绑定:', device || '不绑定');
console.log('License ID:', payload.lic);

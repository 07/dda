/**
 * 生成 Ed25519 密钥对（仅运行一次）
 * - 公钥（spki base64）输出到控制台，需硬编码进 shared/src/js/util/membership.js 的 PUBLIC_KEY
 * - 私钥（pkcs8 base64）保存到 keys/ed25519-private.key（务必保密，不要提交到扩展/仓库）
 */
const fs = require('fs');
const path = require('path');
const { generateKeyPairSync } = require('crypto');

const { publicKey, privateKey } = generateKeyPairSync('ed25519');
const pubSpki = publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
const privPkcs8 = privateKey.export({ type: 'pkcs8', format: 'der' }).toString('base64');

const keysDir = path.join(__dirname, '..', 'keys');
if (!fs.existsSync(keysDir)) fs.mkdirSync(keysDir, { recursive: true });
fs.writeFileSync(path.join(keysDir, 'ed25519-private.key'), privPkcs8, 'utf8');
fs.writeFileSync(path.join(keysDir, 'ed25519-public.key'), pubSpki, 'utf8');

console.log('=== 公钥（复制到 membership.js 的 PUBLIC_KEY）===');
console.log(pubSpki);
console.log('\n=== 私钥已保存到 keys/ed25519-private.key（保密！）===');
console.log('公钥也已保存到 keys/ed25519-public.key');

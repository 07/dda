/**
 * 多答AI Duoda - 核心注入引擎
 * 挂载到全局 window.DuodaInjector
 * 依赖: DuodaUtils
 *
 * 负责: 定位输入框、文本注入、文件上传、发送触发
 */
(function (global) {
  'use strict';

  // 容错：如果 Utils 未加载，使用简单的 console 替代
  const Utils = global.DuodaUtils || {
    log: {
      info: (...args) => console.log('[Duoda Injector]', ...args),
      warn: (...args) => console.warn('[Duoda Injector]', ...args),
      error: (...args) => console.error('[Duoda Injector]', ...args)
    },
    waitForAnySelector: async (selectors, timeout, interval) => {
      const startTime = Date.now();
      while (Date.now() - startTime < timeout) {
        for (const sel of selectors) {
          try {
            const el = document.querySelector(sel);
            if (el) return el;
          } catch (e) {}
        }
        await new Promise(r => setTimeout(r, interval || 200));
      }
      throw new Error('Selector timeout');
    },
    sleep: (ms) => new Promise(r => setTimeout(r, ms))
  };

  const Injector = {
    _currentPlatform: null,
    _sendId: null,
    _isInjecting: false,

    /**
     * 设置当前平台配置
     */
    setPlatform(platformConfig) {
      this._currentPlatform = platformConfig;
      Utils.log.info('Injector platform set:', platformConfig.id);
    },

    /**
     * 完整的注入+发送流程
     * @param {Object} params - { text, files, sendId, platform }
     * @returns {Promise<Object>} - 执行结果
     */
    async injectAndSend(params) {
      const { text, files = [], sendId, platform } = params;

      if (platform) {
        this.setPlatform(platform);
      }

      if (!this._currentPlatform) {
        return { success: false, error: 'No platform config', sendId };
      }

      if (this._isInjecting) {
        Utils.log.warn('Injector is busy, skipping');
        return { success: false, error: 'Injector busy', sendId };
      }

      this._isInjecting = true;
      this._sendId = sendId || Utils.generateId('send');

      try {
        Utils.log.info(`Injecting to ${this._currentPlatform.id}, sendId=${this._sendId}`);

        // 1. 定位输入框
        const inputEl = await this._findInput();
        if (!inputEl) {
          return { success: false, error: 'Input not found', sendId: this._sendId };
        }

        // 2. 注入文本
        if (text) {
          const textResult = await this._injectText(inputEl, text);
          if (!textResult) {
            return { success: false, error: 'Text inject failed', sendId: this._sendId };
          }
        }

        // 3. 注入文件（如果有）
        if (files && files.length > 0) {
          const fileResult = await this._injectFiles(files, inputEl);
          if (!fileResult) {
            Utils.log.warn('File inject failed, but continuing with text');
          }
        }

        // 4. 等待一下确保输入完成（使用平台配置的延迟，默认200ms）
        const sendDelay = (this._currentPlatform.send && this._currentPlatform.send.delay) || 200;
        await Utils.sleep(sendDelay);

        // 5. 触发发送
        const sendResult = await this._triggerSend(inputEl);
        if (!sendResult) {
          return { success: false, error: 'Send trigger failed', sendId: this._sendId };
        }

        Utils.log.info(`Inject and send success: ${this._sendId}`);
        return {
          success: true,
          sendId: this._sendId,
          platformId: this._currentPlatform.id,
          timestamp: Date.now()
        };
      } catch (e) {
        Utils.log.error('InjectAndSend error:', e);
        return { success: false, error: e.message, sendId: this._sendId };
      } finally {
        this._isInjecting = false;
      }
    },

    /**
     * 仅注入文本，不发送
     */
    async injectTextOnly(text) {
      if (!this._currentPlatform) {
        return { success: false, error: 'No platform config' };
      }
      try {
        const inputEl = await this._findInput();
        if (!inputEl) return { success: false, error: 'Input not found' };
        const result = await this._injectText(inputEl, text);
        return { success: result };
      } catch (e) {
        return { success: false, error: e.message };
      }
    },

    /**
     * 定位输入框（先同步查找，找不到再异步等待）
     */
    async _findInput() {
      const config = this._currentPlatform.findInput || {};
      const selector = config.selector;
      const timeout = config.waitTimeout || 5000;
      const interval = config.pollInterval || 150;

      // 0. 先同步查找一次（最快路径）
      if (selector) {
        const selectors = selector.split(',').map(s => s.trim());
        for (const sel of selectors) {
          try {
            const el = document.querySelector(sel);
            if (el && el.offsetParent !== null) {
              Utils.log.info('Input found instantly (config):', el.tagName);
              return el;
            }
          } catch (e) {}
        }
      }

      // 同步查找通用选择器
      const genericSelectors = [
        'textarea',
        'div[contenteditable="true"]',
        'div[contenteditable=""]',
        '[role="textbox"]',
        'input[type="text"]',
        '.ProseMirror',
        '[data-testid*="input" i]'
      ];

      for (const sel of genericSelectors) {
        try {
          const el = document.querySelector(sel);
          if (el && el.offsetParent !== null) {
            Utils.log.info('Input found instantly (generic):', el.tagName);
            return el;
          }
        } catch (e) {}
      }

      // 1. 同步没找到，再异步等待配置选择器（最多2秒）
      if (selector) {
        const selectors = selector.split(',').map(s => s.trim());
        try {
          const el = await Utils.waitForAnySelector(selectors, 2000, interval);
          if (el) {
            Utils.log.info('Input found after wait (config):', el.tagName);
            return el;
          }
        } catch (e) {
          Utils.log.warn('Config selector timeout');
        }
      }

      // 2. Fallback: 异步等待通用选择器（最多2秒）
      try {
        const el = await Utils.waitForAnySelector(genericSelectors, 2000, interval);
        if (el) {
          Utils.log.info('Input found after wait (generic):', el.tagName);
          return el;
        }
      } catch (e) {
        Utils.log.error('All input selectors failed');
      }

      return null;
    },

    /**
     * 注入文本
     */
    async _injectText(inputEl, text) {
      const config = this._currentPlatform.addText || {};
      const method = config.method || 'insertText';
      const focusFirst = config.focusFirst !== false;
      const clearBefore = config.clearBefore !== false;

      if (focusFirst) {
        inputEl.focus();
        await Utils.sleep(100);
      }

      // 清空现有内容
      if (clearBefore) {
        this._clearInput(inputEl);
        await Utils.sleep(100);
      }

      Utils.log.info(`Injecting text via ${method}, length=${text.length}`);

      // 按优先级尝试注入方式
      const methods = [method, 'insertText', 'paste', 'execCommand'];
      const tried = new Set();

      for (const m of methods) {
        if (tried.has(m)) continue;
        tried.add(m);

        let result = false;
        switch (m) {
          case 'insertText':
            result = this._injectByInsertText(inputEl, text);
            break;
          case 'paste':
            result = this._injectByPaste(inputEl, text);
            break;
          case 'slate':
            result = await this._injectBySlate(inputEl, text);
            break;
          case 'draft':
            result = await this._injectByDraft(inputEl, text);
            break;
          case 'execCommand':
            result = this._injectByExecCommand(inputEl, text);
            break;
          default:
            continue;
        }

        if (result) {
          // 验证注入是否成功
          await Utils.sleep(150);
          const verified = this._verifyInjectedText(inputEl, text);
          if (verified) {
            // 清除任何残留选区，把光标收到输入框末尾（防止页面文字被全选导致无法发送）
            this._collapseSelection(inputEl);
            Utils.log.info(`Text injected successfully via ${m}`);
            return true;
          } else {
            Utils.log.warn(`Method ${m} reported success but verification failed, trying next...`);
          }
        } else {
          Utils.log.warn(`Method ${m} failed, trying next...`);
        }
      }

      Utils.log.error('All injection methods failed');
      return false;
    },

    /**
     * 读取输入框当前文本
     */
    _readInputValue(inputEl) {
      try {
        if (!inputEl) return '';
        if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
          return inputEl.value || '';
        }
        if (inputEl.isContentEditable) {
          return inputEl.innerText || inputEl.textContent || '';
        }
      } catch (e) {}
      return '';
    },

    /**
     * 验证注入的文本是否真的在输入框中
     */
    _verifyInjectedText(inputEl, text) {
      try {
        const currentValue = this._readInputValue(inputEl);
        // 检查是否包含文本的前20个字符（避免空白差异）
        const checkText = text.substring(0, Math.min(20, text.length)).trim();
        return currentValue.trim().includes(checkText);
      } catch (e) {
        Utils.log.error('Verify error:', e);
        return false;
      }
    },

    /**
     * execCommand 方式（最基础的 fallback）
     */
    _injectByExecCommand(inputEl, text) {
      try {
        if (inputEl.isContentEditable) {
          this._placeCaretAtEnd(inputEl);
          document.execCommand('insertText', false, text);
          this._collapseSelection(inputEl);
          return true;
        }
        if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
          const proto = inputEl.tagName === 'TEXTAREA'
            ? window.HTMLTextAreaElement.prototype
            : window.HTMLInputElement.prototype;
          Object.getOwnPropertyDescriptor(proto, 'value').set.call(inputEl, text);
          inputEl.dispatchEvent(new Event('input', { bubbles: true }));
          return true;
        }
        return false;
      } catch (e) {
        Utils.log.error('execCommand method error:', e);
        return false;
      }
    },

    /**
     * 清空输入框
     */
    _clearInput(inputEl) {
      try {
        if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
          const proto = inputEl.tagName === 'TEXTAREA'
            ? window.HTMLTextAreaElement.prototype
            : window.HTMLInputElement.prototype;
          const nativeSetter = Object.getOwnPropertyDescriptor(proto, 'value').set;
          nativeSetter.call(inputEl, '');
          inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        } else if (inputEl.isContentEditable) {
          // 精确选中"输入框内部"内容并删除（绝不用全局全选命令，那会选中整个页面）
          const sel = window.getSelection();
          sel.removeAllRanges();
          const range = document.createRange();
          range.selectNodeContents(inputEl);
          sel.addRange(range);
          document.execCommand('delete', false, null);
          sel.removeAllRanges();
        }
      } catch (e) {
        Utils.log.error('Clear input error:', e);
      }
    },

    /**
     * 把光标安全地放到 contenteditable 输入框内部末尾（不影响页面其他内容）
     */
    _placeCaretAtEnd(inputEl) {
      try {
        inputEl.focus();
        if (!inputEl.isContentEditable) return;
        const sel = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(inputEl);
        range.collapse(false); // 折叠到末尾
        sel.removeAllRanges();
        sel.addRange(range);
      } catch (e) {}
    },

    /**
     * 清除可能残留的选区，把光标折叠到输入框末尾（避免页面文字被全选）
     */
    _collapseSelection(inputEl) {
      try {
        if (inputEl && inputEl.isContentEditable) {
          this._placeCaretAtEnd(inputEl);
        } else {
          window.getSelection().removeAllRanges();
        }
      } catch (e) {}
    },

    /**
     * insertText 方式：模拟原生输入
     */
    _injectByInsertText(inputEl, text) {
      try {
        if (inputEl.tagName === 'TEXTAREA' || inputEl.tagName === 'INPUT') {
          inputEl.focus();

          // 使用原生 setter 触发 React 等框架的状态更新
          const proto = inputEl.tagName === 'TEXTAREA'
            ? window.HTMLTextAreaElement.prototype
            : window.HTMLInputElement.prototype;
          const nativeSetter = Object.getOwnPropertyDescriptor(proto, 'value').set;

          // 模拟键盘事件序列
          inputEl.dispatchEvent(new KeyboardEvent('keydown', {
            key: 'a', code: 'KeyA', keyCode: 65, which: 65, bubbles: true, cancelable: true
          }));

          nativeSetter.call(inputEl, text);

          // 触发完整的事件序列
          inputEl.dispatchEvent(new Event('input', { bubbles: true }));
          inputEl.dispatchEvent(new Event('change', { bubbles: true }));
          inputEl.dispatchEvent(new KeyboardEvent('keyup', {
            key: 'a', code: 'KeyA', keyCode: 65, which: 65, bubbles: true, cancelable: true
          }));

          return true;
        }

        if (inputEl.isContentEditable) {
          this._placeCaretAtEnd(inputEl);

          // 模拟 beforeinput + input 事件序列
          inputEl.dispatchEvent(new InputEvent('beforeinput', {
            bubbles: true, cancelable: true, data: text, inputType: 'insertText'
          }));

          document.execCommand('insertText', false, text);

          inputEl.dispatchEvent(new InputEvent('input', {
            bubbles: true, cancelable: true, data: text, inputType: 'insertText'
          }));

          this._collapseSelection(inputEl);
          return true;
        }

        return false;
      } catch (e) {
        Utils.log.error('insertText method error:', e);
        return false;
      }
    },

    /**
     * paste 方式：模拟粘贴事件
     */
    _injectByPaste(inputEl, text) {
      try {
        this._placeCaretAtEnd(inputEl);

        // 创建剪贴板数据
        const dataTransfer = new DataTransfer();
        dataTransfer.setData('text/plain', text);

        // 触发 paste 事件
        const pasteEvent = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: dataTransfer
        });

        const cancelled = !inputEl.dispatchEvent(pasteEvent);
        if (cancelled) {
          // 如果页面阻止了默认行为，手动插入
          if (inputEl.isContentEditable) {
            document.execCommand('insertText', false, text);
          } else {
            const proto = inputEl.tagName === 'TEXTAREA'
              ? window.HTMLTextAreaElement.prototype
              : window.HTMLInputElement.prototype;
            Object.getOwnPropertyDescriptor(proto, 'value').set.call(inputEl, text);
            inputEl.dispatchEvent(new Event('input', { bubbles: true }));
          }
        }
        this._collapseSelection(inputEl);

        return true;
      } catch (e) {
        Utils.log.error('paste method error:', e);
        // fallback
        return this._injectByInsertText(inputEl, text);
      }
    },

    /**
     * Slate.js 编辑器注入
     */
    async _injectBySlate(inputEl, text) {
      try {
        this._placeCaretAtEnd(inputEl);
        await Utils.sleep(100);

        // Slate.js 通常用 contenteditable + data-slate-editor 属性
        document.execCommand('insertText', false, text);

        // 触发 Slate 的内部事件
        inputEl.dispatchEvent(new InputEvent('beforeinput', {
          bubbles: true,
          cancelable: true,
          data: text,
          inputType: 'insertText'
        }));
        inputEl.dispatchEvent(new InputEvent('input', {
          bubbles: true,
          cancelable: true,
          data: text,
          inputType: 'insertText'
        }));
        this._collapseSelection(inputEl);

        return true;
      } catch (e) {
        Utils.log.error('slate method error:', e);
        return this._injectByInsertText(inputEl, text);
      }
    },

    /**
     * Draft.js 编辑器注入
     */
    async _injectByDraft(inputEl, text) {
      try {
        inputEl.focus();
        await Utils.sleep(100);

        // Draft.js 使用 contenteditable + DraftEditor-root
        // 尝试通过 React 内部属性设置
        const reactKey = Object.keys(inputEl).find(k => k.startsWith('__reactInternalInstance') || k.startsWith('__reactFiber'));

        if (reactKey) {
          // 找到 React fiber，尝试调用 onChange
          Utils.log.info('Found React fiber, trying React prop injection');
        }

        // fallback: 使用 paste 事件（Draft.js 对 paste 处理较好）
        return this._injectByPaste(inputEl, text);
      } catch (e) {
        Utils.log.error('draft method error:', e);
        return this._injectByPaste(inputEl, text);
      }
    },

    /**
     * 把 postMessage 传来的 dataUrl 普通对象还原为真正的 File
     * （postMessage 无法跨 frame 传递 File 对象）
     */
    _toFile(item) {
      try {
        if (!item) return null;
        // 已经是 File
        if (item instanceof File) return item;
        // Blob 包装为 File
        if (item instanceof Blob) return new File([item], item.name || 'pasted-file', { type: item.type });

        const dataUrl = item.dataUrl || item.data;
        if (!dataUrl || typeof dataUrl !== 'string') return null;

        // 解析 dataURL: data:<mime>;base64,<data>
        const commaIdx = dataUrl.indexOf(',');
        const header = dataUrl.slice(0, commaIdx);
        const body = dataUrl.slice(commaIdx + 1);
        const mimeMatch = header.match(/:(.*?)(;|$)/);
        const mime = (mimeMatch ? mimeMatch[1] : item.type) || 'application/octet-stream';

        let blob;
        if (header.includes(';base64')) {
          const bstr = atob(body);
          const len = bstr.length;
          const u8 = new Uint8Array(len);
          for (let i = 0; i < len; i++) u8[i] = bstr.charCodeAt(i);
          blob = new Blob([u8], { type: mime });
        } else {
          blob = new Blob([decodeURIComponent(body)], { type: mime });
        }
        return new File([blob], item.name || `file-${Date.now()}`, { type: mime });
      } catch (e) {
        Utils.log.error('_toFile error:', e);
        return null;
      }
    },

    /**
     * 注入文件（按文件类型智能选择方式，自动 fallback）
     * 图片：富文本编辑器普遍支持粘贴 -> paste 优先
     * 文档：依赖文件选择框 -> fileInput 优先
     */
    async _injectFiles(files, inputEl) {
      if (!files || files.length === 0) return false;

      // 1. 全部还原为真正的 File 对象
      const realFiles = files.map(f => this._toFile(f)).filter(Boolean);
      if (realFiles.length === 0) {
        Utils.log.warn('No valid files after conversion');
        return false;
      }
      Utils.log.info(`Injecting ${realFiles.length} file(s):`, realFiles.map(f => `${f.name}(${f.type})`));

      const config = this._currentPlatform.addFile || {};
      const preferred = config.method && config.method !== 'auto' ? config.method : null;
      const allImages = realFiles.every(f => (f.type || '').startsWith('image/'));

      // 2. 决定尝试顺序
      let order;
      if (preferred) {
        order = [preferred, ...['paste', 'fileInput', 'drop'].filter(m => m !== preferred)];
      } else if (allImages) {
        order = ['paste', 'fileInput', 'drop']; // 图片优先粘贴
      } else {
        order = ['fileInput', 'drop', 'paste']; // 文档优先文件框
      }

      for (const method of order) {
        try {
          let ok = false;
          if (method === 'fileInput') ok = await this._injectFileByInput(realFiles, config);
          else if (method === 'paste') ok = await this._injectFileByPaste(realFiles, inputEl);
          else if (method === 'drop') ok = await this._injectFileByDrop(realFiles, config);

          if (ok) {
            // 等待附件渲染，检测是否真的上传成功
            await Utils.sleep(400);
            if (this._hasAttachmentUI()) {
              Utils.log.info(`File injected & confirmed via ${method}`);
              return true;
            }
            // 没检测到附件UI：可能确实成功了但无明显标识，图片继续尝试下一种方式；
            // 为避免重复，若当前是 fileInput 且确实设置了 files，也视为成功
            if (method === 'fileInput') {
              Utils.log.info(`File set via fileInput (no visible preview)`);
              return true;
            }
            Utils.log.warn(`Method ${method} no visible attachment, trying next`);
          }
        } catch (e) {
          Utils.log.warn(`File inject via ${method} failed:`, e.message);
        }
      }
      Utils.log.error('All file inject methods failed');
      return false;
    },

    /**
     * 检测页面是否出现了附件/图片预览 UI（上传成功的迹象）
     */
    _hasAttachmentUI() {
      const selectors = [
        '[class*="upload" i] [class*="file" i]',
        '[class*="attach" i]',
        '[class*="attachment" i]',
        '[class*="preview" i] img',
        '[class*="thumb" i]',
        '[class*="image-item" i]',
        '[class*="file-item" i]',
        '.ci-file-container',
        'img[src^="blob:"]'
      ];
      for (const sel of selectors) {
        try {
          const el = document.querySelector(sel);
          if (el && el.offsetParent !== null) return true;
        } catch (e) {}
      }
      return false;
    },

    /**
     * 从页面所有 file input 中挑选最合适的（匹配 accept、优先 multiple）
     */
    _pickBestFileInput(files, selector) {
      let inputs = Array.from(document.querySelectorAll("input[type='file']"));
      if (inputs.length === 0) return null;

      // 配置指定选择器优先
      if (selector) {
        const specified = document.querySelector(selector);
        if (specified) return specified;
      }

      // 过滤：accept 匹配文件类型
      const firstType = files[0]?.type || '';
      const scored = inputs.map(inp => {
        let score = 0;
        const accept = (inp.accept || '').toLowerCase();
        if (accept) {
          if (firstType && accept.includes(firstType)) score += 10;
          if (firstType.startsWith('image/') && accept.includes('image')) score += 5;
          if (accept.includes('*') || accept.length === 0) score += 2;
        } else {
          score += 1; // 无 accept 限制，通用
        }
        if (inp.multiple) score += 2;
        if (inp.disabled) score -= 20;
        return { inp, score };
      }).sort((a, b) => b.score - a.score);

      return scored[0].inp;
    },

    /**
     * fileInput 方式：直接设置文件输入
     */
    async _injectFileByInput(files, config) {
      const isImage = files.every(f => (f.type || '').startsWith('image/'));
      // 字段可能是字符串，或 {image, file} 按本次文件类型选择
      const byType = (field) => {
        if (!field) return null;
        if (typeof field === 'string') return field;
        const v = isImage ? field.image : field.file;
        return v || field.image || field.file || null;
      };
      // 在逗号分隔的多个候选选择器中找第一个命中的元素
      const queryFirstOf = (selStr) => {
        if (!selStr) return null;
        for (const s of selStr.split(',').map(x => x.trim()).filter(Boolean)) {
          let el = null;
          try { el = document.querySelector(s); } catch (e) {}
          if (el) return el;
        }
        return null;
      };

      // 多步 preClick：部分平台（如元宝）需先点“+”展开菜单、再点具体的“上传图片/文件”菜单项，
      // 对应的 file input 才会挂载。step.selectors 可按 image/file 区分。
      if (config && config.preClick) {
        const steps = Array.isArray(config.preClick) ? config.preClick : [{ selector: config.preClick }];
        for (const step of steps) {
          // 若目标类型的文件框已存在，则无需再点
          const wantedInput = byType(config.fileInputSelector);
          if (wantedInput && queryFirstOf(wantedInput)) break;

          const selStr = byType(step.selector || step.selectors);
          const preBtn = queryFirstOf(selStr);
          if (!preBtn) continue;

          // 点击菜单项可能触发 input.click() 弹出系统文件选择框；按需在捕获阶段拦截，避免弹窗
          let blocker = null;
          if (step.suppressFilePicker) {
            blocker = (e) => {
              const t = e.target;
              if (t && t.tagName === 'INPUT' && (t.type || '').toLowerCase() === 'file') {
                e.preventDefault();
                e.stopPropagation();
              }
            };
            document.addEventListener('click', blocker, true);
          }
          try { (Utils.simulateClick || (el => el.click()))(preBtn); } catch (e) {}

          // 轮询等待：优先等 waitFor 选择器，否则等目标文件框出现
          const waitSel = step.waitFor || wantedInput || "input[type='file']";
          const timeout = step.waitForTimeout || 4000;
          const t0 = Date.now();
          while (Date.now() - t0 < timeout) {
            if (queryFirstOf(waitSel)) break;
            await Utils.sleep(120);
          }
          if (blocker) setTimeout(() => document.removeEventListener('click', blocker, true), 1200);
        }
      }

      const selectorStr = byType(config && config.fileInputSelector);
      const fileInput = this._pickBestFileInput(files, selectorStr);
      if (!fileInput) return false;

      try {
        const dataTransfer = new DataTransfer();
        for (const file of files) dataTransfer.items.add(file);
        fileInput.files = dataTransfer.files;
        fileInput.dispatchEvent(new Event('input', { bubbles: true }));
        fileInput.dispatchEvent(new Event('change', { bubbles: true }));
        // 部分框架还监听 React 合成事件，补派发
        fileInput.dispatchEvent(new Event('blur', { bubbles: true }));
        await Utils.sleep(300);
        return fileInput.files && fileInput.files.length > 0;
      } catch (e) {
        Utils.log.error('fileInput set error:', e);
        return false;
      }
    },

    /**
     * paste 方式：模拟剪贴板粘贴图片（多层级派发，事件独立创建）
     */
    async _injectFileByPaste(files, inputEl) {
      const buildEvent = () => {
        const dt = new DataTransfer();
        for (const file of files) dt.items.add(file);
        let ev;
        try {
          ev = new ClipboardEvent('paste', { bubbles: true, cancelable: true, composed: true });
          Object.defineProperty(ev, 'clipboardData', { value: dt });
        } catch (e) {
          ev = new Event('paste', { bubbles: true, cancelable: true, composed: true });
          Object.defineProperty(ev, 'clipboardData', { value: dt });
        }
        return ev;
      };

      // 目标层级：输入框 -> 最近的富文本编辑器容器 -> document
      const targets = [];
      if (inputEl) {
        try { inputEl.focus && inputEl.focus(); } catch (e) {}
        targets.push(inputEl);
        // 向上找 contenteditable 容器
        let p = inputEl.parentElement;
        for (let i = 0; i < 4 && p; i++) {
          if (p.isContentEditable || p.getAttribute && p.getAttribute('contenteditable') === 'true') {
            targets.push(p);
            break;
          }
          p = p.parentElement;
        }
      }
      const editor = document.querySelector('.ProseMirror, [contenteditable="true"], [role="textbox"]');
      if (editor && !targets.includes(editor)) targets.push(editor);

      await Utils.sleep(80);
      targets.forEach(t => { try { t.dispatchEvent(buildEvent()); } catch (e) {} });
      try { document.dispatchEvent(buildEvent()); } catch (e) {}
      await Utils.sleep(300);
      return true;
    },

    /**
     * drop 方式：模拟拖放
     */
    async _injectFileByDrop(files, config) {
      const selector = (config && config.dropTargetSelector) || null;
      const target = (selector && document.querySelector(selector)) ||
        document.querySelector('.ProseMirror') ||
        document.querySelector("div[contenteditable='true']") ||
        document.querySelector('textarea') || document.body;

      const buildEvent = (type, dt) => {
        try {
          return new DragEvent(type, { bubbles: true, cancelable: true, composed: true, dataTransfer: dt });
        } catch (e) {
          const ev = new Event(type, { bubbles: true, cancelable: true });
          Object.defineProperty(ev, 'dataTransfer', { value: dt });
          return ev;
        }
      };

      const dt = new DataTransfer();
      for (const file of files) dt.items.add(file);

      ['dragenter', 'dragover', 'drop'].forEach(type => {
        try { target.dispatchEvent(buildEvent(type, dt)); } catch (e) {}
      });
      await Utils.sleep(300);
      return true;
    },

    /**
     * 触发发送
     */
    async _triggerSend(inputEl) {
      const config = this._currentPlatform.send || {};
      const method = config.method || 'enter';
      const buttonSelector = config.buttonSelector;

      Utils.log.info(`Triggering send via ${method}`);

      // 发送前确保光标在输入框末尾、没有全选残留（否则 Enter 会删掉选中内容而非发送）
      this._collapseSelection(inputEl);

      // 发送前记录输入框内容，用于发送后检测是否已清空（发送成功的硬证据）
      const beforeValue = this._readInputValue(inputEl);

      // 框架发送后可能重建输入框 DOM，原节点脱离文档时按选择器重新拿到“活着的”输入框
      const liveInput = () => {
        if (inputEl && document.contains(inputEl)) return inputEl;
        const sel = this._currentPlatform.findInput && this._currentPlatform.findInput.selector;
        if (sel) {
          const found = document.querySelector(sel);
          if (found) { inputEl = found; return found; }
        }
        return inputEl;
      };

      // 判断输入框是否已因发送而清空
      const isClearedAfterSend = () => {
        const el = liveInput();
        const after = this._readInputValue(el).trim();
        if (!after) return true;
        // 内容明显变短（残留占位/换行也算发送）
        if (beforeValue && after.length < beforeValue.trim().length * 0.3) return true;
        return false;
      };

      // 轮询等待清空：首次加载时页面响应可能较慢，固定短等待会误判失败从而重复发送
      const waitCleared = async (maxMs) => {
        const limit = maxMs || 700;
        const t0 = Date.now();
        while (Date.now() - t0 < limit) {
          if (isClearedAfterSend()) return true;
          await Utils.sleep(100);
        }
        return isClearedAfterSend();
      };

      // 按优先级尝试所有发送方式；每尝试一种都检测输入框是否清空，
      // 一旦清空立即判定成功并返回，绝不再用下一种方式重复发送
      const attempts = [];
      if (method === 'enter') {
        attempts.push({ type: 'enter' });
        attempts.push({ type: 'click', selector: buttonSelector, primary: false });
      } else if (method === 'click') {
        attempts.push({ type: 'click', selector: buttonSelector, primary: true });
        attempts.push({ type: 'enter' });
      } else {
        attempts.push({ type: 'enter' });
        attempts.push({ type: 'click', selector: buttonSelector, primary: false });
      }

      let dispatched = false; // 是否已实际派发过发送动作
      for (const attempt of attempts) {
        if (attempt.type === 'enter') {
          if (this._sendByEnter(inputEl)) dispatched = true;
        } else if (attempt.type === 'click') {
          if (await this._sendByClick(attempt.selector, attempt.primary)) dispatched = true;
        }

        // 轮询等待框架响应、输入框清空
        if (await waitCleared(700)) {
          Utils.log.info(`Send confirmed via ${attempt.type} (input cleared)`);
          return true;
        }
        // 输入框仍有内容，说明该方式未生效，才尝试下一种
      }

      // 最后尝试：通用发送按钮查找
      Utils.log.warn('Configured send methods failed, trying generic send button...');
      if (await this._sendByGenericButton()) dispatched = true;
      if (await waitCleared(500)) return true;

      // 防重复关键：只要已实际派发过发送动作（回车/点击），就乐观视为成功。
      // 首次加载时清空回调可能偏慢，但消息多半已发出；此时再重试会造成同问题多发，
      // 重复发送的危害大于偶发未发送，故不再尝试、也不让外层整体重试。
      if (dispatched) {
        Utils.log.warn('Send dispatched but clear not confirmed in time; treat as success to avoid duplicate');
        return true;
      }

      Utils.log.error('All send methods failed (nothing dispatched)');
      return false;
    },

    /**
     * 通用发送按钮查找
     */
    async _sendByGenericButton() {
      const genericSelectors = [
        'button[type="submit"]',
        'button[aria-label*="发送" i]',
        'button[aria-label*="send" i]',
        'button[class*="send" i]',
        'button[class*="submit" i]',
        '[data-testid*="send" i]',
        '[class*="send-btn" i]',
        'button svg + span',
        '.input-area button:last-child',
        '.composer button:last-child'
      ];

      for (const selector of genericSelectors) {
        const btn = document.querySelector(selector);
        if (btn && !btn.disabled && btn.offsetParent !== null) {
          Utils.log.info('Found generic send button:', selector);
          Utils.simulateClick(btn);
          return true;
        }
      }
      return false;
    },

    /**
     * 回车发送
     */
    _sendByEnter(inputEl) {
      try {
        inputEl.focus();

        const isContentEditable = inputEl.getAttribute &&
          (inputEl.isContentEditable || inputEl.getAttribute('contenteditable') === 'true');

        const baseOpts = {
          key: 'Enter',
          code: 'Enter',
          keyCode: 13,
          which: 13,
          charCode: 13,
          bubbles: true,
          cancelable: true,
          composed: true
        };

        // 完整事件序列：keydown -> keypress -> (input) -> keyup
        const keydownEvent = new KeyboardEvent('keydown', baseOpts);
        inputEl.dispatchEvent(keydownEvent);

        const keypressEvent = new KeyboardEvent('keypress', baseOpts);
        inputEl.dispatchEvent(keypressEvent);

        inputEl.dispatchEvent(new KeyboardEvent('keyup', baseOpts));

        // contenteditable 富文本编辑器（React/Lexical/Slate/Draft）：
        // 框架通常在 keydown 拦截并 preventDefault 后自行发送，
        // defaultPrevented=true 恰恰说明它接管了，应视为已触发。
        if (isContentEditable) {
          return true;
        }

        // 原生 textarea/input：未被拦截说明回车已生效
        // 若被拦截（Shift+Enter 换行场景），返回 false 让上层尝试按钮
        if (keydownEvent.defaultPrevented) {
          // 再补一次：某些 textarea 监听 keypress
          return false;
        }
        return true;
      } catch (e) {
        Utils.log.error('sendByEnter error:', e);
        return false;
      }
    },

    /**
     * 点击发送按钮
     */
    async _sendByClick(buttonSelector, isPrimary) {
      try {
        if (!buttonSelector) return false;

        const selectors = buttonSelector.split(',').map(s => s.trim());
        const btn = Utils.queryFirst(selectors);

        if (!btn) {
          // 仅当 click 是首选发送方式时才告警；作为 enter 兜底时找不到按钮属正常
          if (isPrimary) Utils.log.warn('Send button not found:', buttonSelector);
          return false;
        }

        // 检查按钮是否禁用
        if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') {
          Utils.log.warn('Send button is disabled');
          return false;
        }

        Utils.simulateClick(btn);
        return true;
      } catch (e) {
        Utils.log.error('sendByClick error:', e);
        return false;
      }
    },

    /**
     * React 内部属性发送
     */
    _sendByReactProp(inputEl) {
      try {
        // 尝试找到 React fiber 并调用内部方法
        const fiberKey = Object.keys(inputEl).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
        if (!fiberKey) {
          Utils.log.warn('No React fiber found');
          return this._sendByEnter(inputEl);
        }

        // 复杂的 React 内部调用，MVP 先用 enter 替代
        return this._sendByEnter(inputEl);
      } catch (e) {
        Utils.log.error('sendByReactProp error:', e);
        return this._sendByEnter(inputEl);
      }
    },

    /**
     * 检查是否已登录
     */
    checkLoginStatus() {
      if (!this._currentPlatform || !this._currentPlatform.login) {
        return { loggedIn: true, needLogin: false };
      }

      const config = this._currentPlatform.login;

      // 检查登录态指示器
      if (config.loggedInIndicator) {
        const indicators = config.loggedInIndicator.split(',').map(s => s.trim());
        const found = Utils.queryFirst(indicators);
        if (found) {
          return { loggedIn: true, needLogin: false };
        }
      }

      // 检查登录按钮
      if (config.detectSelector) {
        const selectors = config.detectSelector.split(',').map(s => s.trim());
        const loginBtn = Utils.queryFirst(selectors);
        if (loginBtn) {
          return { loggedIn: false, needLogin: true, loginElement: loginBtn };
        }
      }

      // 默认认为已登录
      return { loggedIn: true, needLogin: false };
    },

    /**
     * 应用主题
     */
    applyTheme(themeMode) {
      if (!this._currentPlatform || !this._currentPlatform.theme) return;

      const theme = this._currentPlatform.theme;
      const mode = themeMode || 'light';

      try {
        switch (theme.mode) {
          case 'filter':
            if (mode === 'dark') {
              document.documentElement.classList.add('duoda-dark');
              if (theme.filterCss) {
                this._injectStyle('duoda-theme-filter', theme.filterCss);
              }
            } else {
              document.documentElement.classList.remove('duoda-dark');
            }
            break;
          case 'attr':
            if (theme.attrName && theme.darkValue) {
              const target = theme.target === 'html' ? document.documentElement : document.body;
              if (mode === 'dark') {
                target.setAttribute(theme.attrName, theme.darkValue);
              } else {
                target.removeAttribute(theme.attrName);
              }
            }
            break;
          case 'reload':
            // reload 模式需要通过 URL 参数控制，这里只记录
            Utils.log.info('Theme reload mode, URL should include theme param');
            break;
          default:
            break;
        }
      } catch (e) {
        Utils.log.error('applyTheme error:', e);
      }
    },

    /**
     * 注入样式
     */
    _injectStyle(id, css) {
      let styleEl = document.getElementById(id);
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = id;
        document.head.appendChild(styleEl);
      }
      styleEl.textContent = css;
    },

    /**
     * 获取当前注入状态
     */
    getStatus() {
      return {
        platform: this._currentPlatform ? this._currentPlatform.id : null,
        isInjecting: this._isInjecting,
        sendId: this._sendId
      };
    }
  };

  global.DuodaInjector = Injector;
})(typeof window !== 'undefined' ? window : globalThis);

/**
 * 多答AI Duoda - 通用工具函数
 * 挂载到全局 window.DuodaUtils
 */
(function (global) {
  'use strict';

  const Utils = {
    /**
     * 延时等待
     */
    sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    },

    /**
     * 生成唯一 ID
     */
    generateId(prefix = 'qw') {
      return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    },

    /**
     * 轮询等待元素出现
     * @param {string} selector - CSS 选择器
     * @param {number} timeout - 超时时间(ms)
     * @param {number} interval - 轮询间隔(ms)
     * @param {Document|Element} root - 查找根节点
     * @returns {Promise<Element>}
     */
    async waitForElement(selector, timeout = 15000, interval = 300, root = document) {
      return new Promise((resolve, reject) => {
        const startTime = Date.now();

        const check = () => {
          const el = root.querySelector(selector);
          if (el) {
            resolve(el);
            return;
          }
          if (Date.now() - startTime >= timeout) {
            reject(new Error(`waitForElement timeout: ${selector}`));
            return;
          }
          setTimeout(check, interval);
        };

        check();
      });
    },

    /**
     * 等待多个选择器中的任意一个出现
     */
    async waitForAnySelector(selectors, timeout = 15000, interval = 300, root = document) {
      for (const selector of selectors) {
        try {
          const el = await this.waitForElement(selector, Math.min(timeout, 2000), interval, root);
          if (el) return el;
        } catch (e) {
          // 继续试下一个
        }
      }
      // 最后一次完整超时等待
      const startTime = Date.now();
      return new Promise((resolve, reject) => {
        const check = () => {
          for (const selector of selectors) {
            const el = root.querySelector(selector);
            if (el) { resolve(el); return; }
          }
          if (Date.now() - startTime >= timeout) {
            reject(new Error(`waitForAnySelector timeout: ${selectors.join(', ')}`));
            return;
          }
          setTimeout(check, interval);
        };
        check();
      });
    },

    /**
     * 防抖
     */
    debounce(fn, delay = 300) {
      let timer = null;
      return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delay);
      };
    },

    /**
     * 节流
     */
    throttle(fn, limit = 300) {
      let inThrottle = false;
      return function (...args) {
        if (!inThrottle) {
          fn.apply(this, args);
          inThrottle = true;
          setTimeout(() => { inThrottle = false; }, limit);
        }
      };
    },

    /**
     * 日志工具
     */
    log: {
      _enabled: true,
      enable() { this._enabled = true; },
      disable() { this._enabled = false; },
      info(...args) { if (this._enabled) console.log('[Duoda]', ...args); },
      warn(...args) { if (this._enabled) console.warn('[Duoda]', ...args); },
      error(...args) { if (this._enabled) console.error('[Duoda]', ...args); },
      debug(...args) { if (this._enabled) console.debug('[Duoda]', ...args); }
    },

    /**
     * 安全执行函数，捕获异常
     */
    safeExecute(fn, ...args) {
      try {
        return fn(...args);
      } catch (e) {
        this.log.error('safeExecute error:', e);
        return null;
      }
    },

    /**
     * 模拟原生输入事件（用于 insertText 方式）
     */
    simulateTextInput(element, text) {
      try {
        // 聚焦元素
        element.focus();

        // 对于 textarea/input，直接设置 value 并触发 input 事件
        if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
          const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
            window.HTMLTextAreaElement.prototype || window.HTMLInputElement.prototype,
            'value'
          ).set;
          nativeInputValueSetter.call(element, text);
          element.dispatchEvent(new Event('input', { bubbles: true }));
          element.dispatchEvent(new Event('change', { bubbles: true }));
          return true;
        }

        // 对于 contenteditable 元素，使用 document.execCommand
        if (element.isContentEditable) {
          // 清空现有内容
          if (element.innerHTML) {
            element.innerHTML = '';
          }
          document.execCommand('insertText', false, text);
          element.dispatchEvent(new InputEvent('input', {
            bubbles: true,
            cancelable: true,
            data: text,
            inputType: 'insertText'
          }));
          return true;
        }

        return false;
      } catch (e) {
        this.log.error('simulateTextInput error:', e);
        return false;
      }
    },

    /**
     * 模拟粘贴事件
     */
    simulatePaste(element, text) {
      try {
        element.focus();
        const clipboardData = new DataTransfer();
        clipboardData.setData('text/plain', text);
        const pasteEvent = new ClipboardEvent('paste', {
          bubbles: true,
          cancelable: true,
          clipboardData: clipboardData
        });
        element.dispatchEvent(pasteEvent);
        return true;
      } catch (e) {
        this.log.error('simulatePaste error:', e);
        return false;
      }
    },

    /**
     * 模拟回车键
     */
    simulateEnter(element) {
      try {
        element.focus();
        const enterEvent = new KeyboardEvent('keydown', {
          key: 'Enter',
          code: 'Enter',
          keyCode: 13,
          which: 13,
          bubbles: true,
          cancelable: true
        });
        element.dispatchEvent(enterEvent);

        const keyupEvent = new KeyboardEvent('keyup', {
          key: 'Enter',
          code: 'Enter',
          keyCode: 13,
          which: 13,
          bubbles: true,
          cancelable: true
        });
        element.dispatchEvent(keyupEvent);
        return true;
      } catch (e) {
        this.log.error('simulateEnter error:', e);
        return false;
      }
    },

    /**
     * 模拟点击
     */
    simulateClick(element) {
      try {
        element.focus();
        const events = ['mousedown', 'mouseup', 'click'];
        for (const type of events) {
          element.dispatchEvent(new MouseEvent(type, {
            bubbles: true,
            cancelable: true,
            view: window
          }));
        }
        return true;
      } catch (e) {
        this.log.error('simulateClick error:', e);
        return false;
      }
    },

    /**
     * 从多个选择器中查找第一个存在的元素
     */
    queryFirst(selectors, root = document) {
      if (!Array.isArray(selectors)) selectors = [selectors];
      for (const selector of selectors) {
        const el = root.querySelector(selector);
        if (el) return el;
      }
      return null;
    },

    /**
     * 深拷贝
     */
    deepClone(obj) {
      if (obj === null || typeof obj !== 'object') return obj;
      if (obj instanceof Date) return new Date(obj.getTime());
      if (obj instanceof Array) return obj.map(item => this.deepClone(item));
      const result = {};
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          result[key] = this.deepClone(obj[key]);
        }
      }
      return result;
    }
  };

  global.DuodaUtils = Utils;
})(typeof window !== 'undefined' ? window : globalThis);

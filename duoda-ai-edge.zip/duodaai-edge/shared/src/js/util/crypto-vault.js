/**
 * DuodaVault —— 账号密码本地加密保险库
 * 方案：主密码经 PBKDF2(SHA-256, 15 万次迭代) 派生 AES-GCM 256 密钥；
 *       密钥只存在于页面内存，不落盘、不导出；锁定/关闭页面后即清空。
 * 存储：duodaVaultMeta = { salt, verifier, verifierIv, iter }（仅校验用，不含任何密码）
 * 账号密码在 sidepanel 中通过 encryptText/decryptText 加解密后存取。
 */
(function (global) {
  const META_KEY = 'duodaVaultMeta';
  const ITERATIONS = 150000;
  let _key = null; // 内存中的 AES-GCM CryptoKey

  const encoder = new TextEncoder();
  const decoder = new TextDecoder();

  function toBase64(buf) {
    const bytes = new Uint8Array(buf);
    let bin = '';
    for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }
  function fromBase64(s) {
    const bin = atob(s);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  function getMeta() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get([META_KEY], (r) => resolve((r && r[META_KEY]) || null));
      } catch (e) { resolve(null); }
    });
  }
  function setMeta(meta) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [META_KEY]: meta }, resolve);
    });
  }

  // 由主密码 + salt 派生 AES-GCM 密钥（不可导出）
  async function deriveKey(password, saltBuf) {
    const baseKey = await crypto.subtle.importKey(
      'raw', encoder.encode(password), 'PBKDF2', false, ['deriveKey']
    );
    return crypto.subtle.deriveKey(
      { name: 'PBKDF2', salt: saltBuf, iterations: ITERATIONS, hash: 'SHA-256' },
      baseKey,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  async function encryptWith(key, plain) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoder.encode(plain));
    return { iv: toBase64(iv), data: toBase64(ct) };
  }
  async function decryptWith(key, ivB64, dataB64) {
    const pt = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: fromBase64(ivB64) }, key, fromBase64(dataB64)
    );
    return decoder.decode(pt);
  }

  // 是否已设置过主密码
  async function isInitialized() {
    const m = await getMeta();
    return !!m;
  }
  // 当前是否已解锁（内存中是否有密钥）
  function isUnlocked() { return !!_key; }
  // 锁定：清空内存密钥
  function lock() { _key = null; }

  // 首次设置主密码
  async function setupMaster(password) {
    if (!password || password.length < 4) throw new Error('主密码至少需要 4 位');
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const key = await deriveKey(password, salt);
    const verifier = await encryptWith(key, 'duoda-vault-ok');
    await setMeta({
      salt: toBase64(salt),
      iter: ITERATIONS,
      verifier: verifier.data,
      verifierIv: verifier.iv,
      createdAt: Date.now()
    });
    _key = key;
    return true;
  }

  // 用主密码解锁（通过解密校验串验证密码正误）
  async function unlock(password) {
    const meta = await getMeta();
    if (!meta) throw new Error('尚未设置主密码');
    const key = await deriveKey(password, fromBase64(meta.salt));
    try {
      await decryptWith(key, meta.verifierIv, meta.verifier);
    } catch (e) {
      throw new Error('主密码错误');
    }
    _key = key;
    return true;
  }

  // 加密明文，返回可存储的 JSON 字符串 {iv,data}
  async function encryptText(plain) {
    if (!_key) throw new Error('保险库已锁定，请先解锁');
    if (plain === '' || plain == null) return '';
    const v = await encryptWith(_key, String(plain));
    return JSON.stringify(v);
  }

  // 解密 encryptText 产出的 JSON 字符串
  async function decryptText(payload) {
    if (!payload) return '';
    if (!_key) throw new Error('保险库已锁定，请先解锁');
    const obj = typeof payload === 'string' ? JSON.parse(payload) : payload;
    return decryptWith(_key, obj.iv, obj.data);
  }

  global.DuodaVault = {
    isInitialized, isUnlocked, lock,
    setupMaster, unlock,
    encryptText, decryptText
  };
})(typeof window !== 'undefined' ? window : globalThis);

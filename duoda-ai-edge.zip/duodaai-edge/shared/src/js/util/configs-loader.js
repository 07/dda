/**
 * 多答AI Duoda - 平台配置加载器
 * 挂载到全局 window.DuodaConfigs
 * 依赖: DuodaUtils
 *
 * 支持内置平台 + 用户自定义平台
 */
(function (global) {
  'use strict';

  // 容错：如果 Utils 未加载，使用简单的 console 替代
  const Utils = global.DuodaUtils || {
    log: {
      info: (...args) => console.log('[Duoda Configs]', ...args),
      warn: (...args) => console.warn('[Duoda Configs]', ...args),
      error: (...args) => console.error('[Duoda Configs]', ...args)
    },
    generateId: (prefix) => prefix + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8)
  };

  const Configs = {
    _platforms: [],
    _domestic: [],
    _global: [],
    _customPlatforms: [],
    _selectorOverrides: {}, // platformId -> 仅包含需覆盖字段的片段（选择器与代码解耦层）
    _defaultSettings: null,
    _loaded: false,

    /**
     * 深度合并：对象递归合并，数组/基本类型以覆盖值为准；始终返回新对象，不污染入参
     */
    deepMerge(base, over) {
      const isPlain = v => v && typeof v === 'object' && !Array.isArray(v);
      if (!isPlain(over)) return over;
      const out = isPlain(base) ? { ...base } : {};
      Object.keys(over).forEach(k => {
        const bv = out[k], ov = over[k];
        if (isPlain(ov) && isPlain(bv)) out[k] = this.deepMerge(bv, ov);
        else out[k] = ov;
      });
      return out;
    },

    /**
     * 初始化加载所有配置（内置 + 自定义）
     */
    async init() {
      if (this._loaded) return this._platforms;

      try {
        // 加载国内平台配置
        const domesticRes = await fetch(chrome.runtime.getURL('shared/res/domestic.json'));
        const domesticData = await domesticRes.json();
        this._domestic = domesticData.platforms || [];

        // 加载国际平台配置
        const globalRes = await fetch(chrome.runtime.getURL('shared/res/global.json'));
        const globalData = await globalRes.json();
        this._global = globalData.platforms || [];

        // 加载默认设置
        const defaultRes = await fetch(chrome.runtime.getURL('shared/res/default.json'));
        this._defaultSettings = await defaultRes.json();

        // 加载用户自定义平台
        await this._loadCustomPlatforms();

        // 加载选择器覆盖层（热修选择器，无需改代码）
        await this._loadSelectorOverrides();

        // 合并平台列表（内置 + 自定义，自定义同 id 覆盖内置）
        this._rebuildPlatforms();

        this._loaded = true;
        Utils.log.info(`Configs loaded: ${this._platforms.length} platforms (${this._domestic.length} domestic, ${this._global.length} global, ${this._customPlatforms.length} custom)`);

        return this._platforms;
      } catch (e) {
        Utils.log.error('Configs init error:', e);
        throw e;
      }
    },

    /**
     * 从 storage 加载用户自定义平台
     */
    async _loadCustomPlatforms() {
      return new Promise((resolve) => {
        chrome.storage.local.get(['customPlatforms'], (result) => {
          this._customPlatforms = result.customPlatforms || [];
          resolve();
        });
      });
    },

    /**
     * 保存自定义平台到 storage
     */
    async _saveCustomPlatforms() {
      return new Promise((resolve) => {
        chrome.storage.local.set({ customPlatforms: this._customPlatforms }, () => {
          resolve(true);
        });
      });
    },

    /**
     * 重新合并平台列表（自定义平台同 id 时覆盖内置平台，用于"编辑内置平台"）
     */
    _rebuildPlatforms() {
      const customById = new Map(this._customPlatforms.map(p => [p.id, p]));
      const merged = [];
      // 内置平台：若存在同 id 的自定义覆盖，则用覆盖版
      [...this._domestic, ...this._global].forEach(p => {
        merged.push(customById.has(p.id) ? customById.get(p.id) : p);
        customById.delete(p.id);
      });
      // 剩余的是纯新增自定义平台
      customById.forEach(p => merged.push(p));

      // 最后统一叠加“选择器覆盖层”（深度合并，优先级最高，且不污染原始配置）
      this._platforms = merged.map(p => {
        const frag = this._selectorOverrides[p.id];
        return frag && typeof frag === 'object' ? this.deepMerge(p, frag) : p;
      });
    },

    /**
     * 从 storage 加载选择器覆盖
     */
    async _loadSelectorOverrides() {
      return new Promise((resolve) => {
        chrome.storage.local.get(['duodaSelectorOverrides'], (result) => {
          this._selectorOverrides = (result && result.duodaSelectorOverrides) || {};
          resolve();
        });
      });
    },

    async _saveSelectorOverrides() {
      return new Promise((resolve) => {
        chrome.storage.local.set({ duodaSelectorOverrides: this._selectorOverrides }, () => resolve(true));
      });
    },

    /** 取某平台的选择器覆盖片段（无则 null） */
    getSelectorOverride(platformId) {
      const f = this._selectorOverrides[platformId];
      return f && typeof f === 'object' ? JSON.parse(JSON.stringify(f)) : null;
    },

    /** 保存（合并）某平台的选择器覆盖片段并即时重建 */
    async saveSelectorOverride(platformId, fragment) {
      if (!fragment || typeof fragment !== 'object') throw new Error('覆盖配置必须是对象');
      this._selectorOverrides[platformId] = fragment;
      await this._saveSelectorOverrides();
      this._rebuildPlatforms();
      return this.getPlatformById(platformId);
    },

    /** 清除某平台的选择器覆盖，恢复内置/自定义默认 */
    async clearSelectorOverride(platformId) {
      if (this._selectorOverrides[platformId] === undefined) return false;
      delete this._selectorOverrides[platformId];
      await this._saveSelectorOverrides();
      this._rebuildPlatforms();
      return true;
    },

    /**
     * 获取所有平台
     */
    getAllPlatforms() {
      return this._platforms;
    },

    /**
     * 获取已启用的平台
     */
    getEnabledPlatforms() {
      return this._platforms.filter(p => p.enabled !== false);
    },

    /**
     * 获取用户自定义平台
     */
    getCustomPlatforms() {
      return this._customPlatforms;
    },

    /**
     * 判断是否为自定义平台（纯新增 或 覆盖了内置）
     */
    isCustomPlatform(platformId) {
      return this._customPlatforms.some(p => p.id === platformId);
    },

    /**
     * 判断是否为内置平台
     */
    isBuiltinPlatform(platformId) {
      return [...this._domestic, ...this._global].some(p => p.id === platformId);
    },

    /**
     * 取得内置平台原始配置
     */
    getBuiltinPlatform(platformId) {
      return [...this._domestic, ...this._global].find(p => p.id === platformId) || null;
    },

    /**
     * 覆盖（编辑）内置平台：把修改后的完整配置作为自定义覆盖保存，同 id 覆盖内置
     */
    async overrideBuiltinPlatform(builtinId, overrides) {
      const builtin = this.getBuiltinPlatform(builtinId);
      if (!builtin) throw new Error(`非内置平台，无法覆盖: ${builtinId}`);

      // 以内置为底，合并用户修改，标记来源
      const merged = {
        ...builtin,
        ...overrides,
        id: builtinId,
        builtinOverride: true
      };

      const idx = this._customPlatforms.findIndex(p => p.id === builtinId);
      if (idx >= 0) this._customPlatforms[idx] = merged;
      else this._customPlatforms.push(merged);

      this._rebuildPlatforms();
      await this._saveCustomPlatforms();
      Utils.log.info('Builtin platform overridden:', builtinId);
      return merged;
    },

    /**
     * 恢复内置平台默认（移除其自定义覆盖）；返回是否进行了恢复
     */
    async resetBuiltinPlatform(builtinId) {
      const before = this._customPlatforms.length;
      this._customPlatforms = this._customPlatforms.filter(p => p.id !== builtinId);
      const changed = this._customPlatforms.length !== before;
      if (changed) {
        this._rebuildPlatforms();
        await this._saveCustomPlatforms();
        Utils.log.info('Builtin platform reset:', builtinId);
      }
      return changed;
    },

    /**
     * 添加自定义平台
     */
    async addCustomPlatform(platform) {
      // 验证必要字段
      if (!platform.id || !platform.name || !platform.url || !platform.domain) {
        throw new Error('平台配置缺少必要字段: id, name, url, domain');
      }

      // 检查 ID 是否重复
      if (this.getPlatformById(platform.id)) {
        throw new Error(`平台 ID 已存在: ${platform.id}`);
      }

      // 补全默认配置
      const newPlatform = {
        id: platform.id,
        name: platform.name,
        nameEn: platform.nameEn || platform.name,
        url: platform.url,
        domain: platform.domain,
        logo: platform.logo || null,
        enabled: platform.enabled !== false,
        // 分类由表单选择：国内 domestic / 国际 global；兼容旧数据，非法值归入国内
        category: (platform.category === 'global' || platform.category === 'domestic')
          ? platform.category
          : 'domestic',
        findInput: platform.findInput || {
          selector: platform.inputSelector || "textarea, div[contenteditable='true'], input[type='text']",
          waitTimeout: 20000,
          pollInterval: 300
        },
        addText: platform.addText || {
          method: platform.textMethod || 'insertText',
          focusFirst: true,
          clearBefore: true
        },
        addFile: platform.addFile || {
          method: 'fileInput',
          fileInputSelector: "input[type='file']"
        },
        send: platform.send || {
          method: platform.sendMethod || 'enter',
          buttonSelector: platform.sendButtonSelector || "button[type='submit'], button[class*='send']"
        },
        hideInput: platform.hideInput || null,
        theme: platform.theme || { mode: null },
        login: platform.login || {
          detectSelector: "a[href*='login'], button[class*='login']",
          loggedInIndicator: "textarea, div[contenteditable='true']"
        },
        answer: platform.answer || {
          containerSelector: "div[class*='message'], div[class*='response']",
          contentSelector: "div[class*='markdown'], div[class*='message-content']",
          streamingIndicator: "div[class*='cursor'], div[class*='typing']"
        }
      };

      this._customPlatforms.push(newPlatform);
      this._rebuildPlatforms();
      await this._saveCustomPlatforms();

      Utils.log.info('Custom platform added:', newPlatform.id);
      return newPlatform;
    },

    /**
     * 更新自定义平台
     */
    async updateCustomPlatform(platformId, updates) {
      const index = this._customPlatforms.findIndex(p => p.id === platformId);
      if (index === -1) {
        throw new Error(`未找到自定义平台: ${platformId}`);
      }

      this._customPlatforms[index] = {
        ...this._customPlatforms[index],
        ...updates,
        id: platformId // ID 不可修改
      };

      this._rebuildPlatforms();
      await this._saveCustomPlatforms();

      Utils.log.info('Custom platform updated:', platformId);
      return this._customPlatforms[index];
    },

    /**
     * 删除自定义平台
     */
    async deleteCustomPlatform(platformId) {
      const index = this._customPlatforms.findIndex(p => p.id === platformId);
      if (index === -1) {
        throw new Error(`未找到自定义平台: ${platformId}`);
      }

      this._customPlatforms.splice(index, 1);
      this._rebuildPlatforms();
      await this._saveCustomPlatforms();

      Utils.log.info('Custom platform deleted:', platformId);
      return true;
    },

    /**
     * 根据 ID 获取平台配置
     */
    getPlatformById(id) {
      return this._platforms.find(p => p.id === id);
    },

    /**
     * 根据域名获取平台配置
     */
    getPlatformByDomain(domain) {
      return this._platforms.find(p => p.domain === domain);
    },

    /**
     * 根据 URL 获取平台配置
     */
    getPlatformByUrl(url) {
      try {
        const hostname = new URL(url).hostname;
        return this._platforms.find(p => p.domain === hostname);
      } catch (e) {
        return null;
      }
    },

    /**
     * 获取默认设置
     */
    getDefaultSettings() {
      return this._defaultSettings;
    },

    /**
     * 获取用户设置
     */
    async getUserSettings() {
      const defaults = this._defaultSettings || {};
      return new Promise((resolve) => {
        chrome.storage.local.get(['userSettings'], (result) => {
          const userSettings = result.userSettings || {};
          resolve({ ...defaults, ...userSettings });
        });
      });
    },

    /**
     * 保存用户设置
     */
    async saveUserSettings(settings) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ userSettings: settings }, () => {
          resolve(true);
        });
      });
    },

    /**
     * 获取平台 Logo URL
     */
    getLogoUrl(platformId) {
      const platform = this.getPlatformById(platformId);
      if (!platform || !platform.logo) return null;
      return chrome.runtime.getURL(`shared/res/logos/${platform.logo}`);
    },

    /**
     * 检查配置是否已加载
     */
    isLoaded() {
      return this._loaded;
    },

    /**
     * 重新加载配置
     */
    async reload() {
      this._loaded = false;
      this._platforms = [];
      this._domestic = [];
      this._global = [];
      this._customPlatforms = [];
      return this.init();
    }
  };

  global.DuodaConfigs = Configs;
})(typeof window !== 'undefined' ? window : globalThis);

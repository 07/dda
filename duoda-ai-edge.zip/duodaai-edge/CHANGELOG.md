# 更新日志

本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/) 规范。

## [1.0.0] - 2026-09-06

### 新增

- 多 AI 平台聚合：一次提问，多平台同时回答
- 内置 19 个 AI 平台（国内 11 个 + 国际 8 个）
- 智能注入引擎：支持 insertText / paste / slate / draft 多种注入方式
- 手动添加自定义平台，支持编辑和删除
- 快捷键：Alt+Q 打开页面，Alt+V 发送选中文本
- 右键菜单：选中文本后"添加到多答AI对话"
- 平台切换：全部 / 单平台视图
- 深色模式支持
- 账号保险库：AES-GCM 256 加密存储账号密码，支持自动登录
- 会员授权系统：Ed25519 数字签名激活码，免费版/会员版功能区分
- 一键总结：汇总多个 AI 回答（会员功能）
- 对话导出 Markdown（会员功能）
- 8 种语言国际化（zh_CN, zh_TW, en, ja, es, fr, ru, hi）
- DNR 规则：移除 iframe 嵌入安全限制
- Service Worker 禁用：确保 iframe 内页面实时响应

### 技术

- Manifest V3
- Service Worker 后台架构
- chrome.storage.local 本地持久化
- window.postMessage 跨域通信（双向来源校验）
- PBKDF2 + AES-GCM 账号加密
- Ed25519 激活码验签（支持 Web Crypto 和纯 JS 降级）

### 安全与合规

- 移除未使用的 optional_permissions（cookies / browsingData / contentSettings）
- 隐私政策页面
